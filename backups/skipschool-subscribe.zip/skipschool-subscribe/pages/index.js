export default function SubscribePage() {
  return null;
}

export async function getServerSideProps({ res }) {
  const html = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Skip School — The AI Playbook for Homeschool Parents</title>
    <meta name="description" content="Skip the classroom. Use AI to personalize how your kids learn. Give them a five-year head start. Free weekly newsletter.">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,400;0,9..40,500;0,9..40,600;0,9..40,700;1,9..40,400&family=DM+Serif+Display&display=swap" rel="stylesheet">
    <style>
        :root {
            --yellow: #fbc926;
            --yellow-hover: #e5b820;
            --navy: #0d203b;
            --navy-light: #1a3358;
            --bg: #f0f4f8;
            --white: #ffffff;
            --gray-200: #e2e8f0;
            --gray-400: #94a3b8;
            --gray-600: #64748b;
            --gray-800: #1e293b;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        html, body {
            height: 100%;
        }

        body {
            font-family: 'DM Sans', -apple-system, BlinkMacSystemFont, sans-serif;
            background: var(--bg);
            color: var(--navy);
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }

        .page {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 40px 24px;
        }

        .container {
            max-width: 1120px;
            width: 100%;
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 60px;
            align-items: center;
        }

        /* LEFT COLUMN */
        .content {
            max-width: 520px;
        }

        .logo {
            margin-bottom: 32px;
        }

        .logo-img {
            height: auto;
            width: 300px;
            max-width: 100%;
            display: block;
        }

        .nl-logo-img {
            height: auto;
            width: 140px;
            display: block;
            margin: 0 auto;
        }

        .stars {
            display: flex;
            gap: 3px;
            margin-bottom: 16px;
        }

        .star {
            color: var(--yellow);
            font-size: 20px;
        }

        h1 {
            font-family: 'DM Serif Display', serif;
            font-size: clamp(32px, 4vw, 46px);
            line-height: 1.12;
            color: var(--navy);
            margin-bottom: 20px;
            letter-spacing: -0.5px;
        }

        h1 .highlight {
            color: var(--yellow);
            position: relative;
            text-shadow: 
                1px 1px 0 rgba(13, 32, 59, 0.12),
                -1px -1px 0 rgba(13, 32, 59, 0.06);
            text-decoration: underline;
            text-decoration-color: var(--yellow);
            text-underline-offset: 4px;
            text-decoration-thickness: 3px;
        }

        .description {
            font-size: 17px;
            line-height: 1.65;
            color: var(--gray-600);
            margin-bottom: 12px;
        }

        .description strong {
            color: var(--navy);
            font-weight: 600;
        }

        .description u {
            text-decoration-color: var(--yellow);
            text-underline-offset: 3px;
            text-decoration-thickness: 2px;
        }

        .frequency {
            font-size: 16px;
            line-height: 1.6;
            color: var(--gray-600);
            margin-bottom: 28px;
        }

        .frequency strong {
            color: var(--navy);
            font-weight: 700;
        }

        /* EMAIL FORM */
        .form-row {
            display: flex;
            gap: 12px;
            margin-bottom: 20px;
        }

        .email-input {
            flex: 1;
            padding: 14px 18px;
            border: 2px solid var(--gray-200);
            border-radius: 10px;
            font-size: 16px;
            font-family: 'DM Sans', sans-serif;
            color: var(--navy);
            background: var(--white);
            transition: border-color 0.2s ease, box-shadow 0.2s ease;
            outline: none;
        }

        .email-input::placeholder {
            color: var(--gray-400);
        }

        .email-input:focus {
            border-color: var(--yellow);
            box-shadow: 0 0 0 3px rgba(251, 201, 38, 0.15);
        }

        .cta-btn {
            padding: 14px 28px;
            background: var(--yellow);
            color: var(--navy);
            border: none;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 700;
            font-family: 'DM Sans', sans-serif;
            cursor: pointer;
            transition: all 0.2s ease;
            white-space: nowrap;
            letter-spacing: 0.2px;
        }

        .cta-btn:hover {
            background: var(--yellow-hover);
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(251, 201, 38, 0.35);
        }

        .cta-btn:active {
            transform: translateY(0);
        }

        /* SOCIAL PROOF */
        .social-proof {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .avatars {
            display: flex;
        }

        .avatar {
            width: 38px;
            height: 38px;
            border-radius: 50%;
            border: 2.5px solid var(--bg);
            margin-left: -10px;
            object-fit: cover;
        }

        .avatar:first-child {
            margin-left: 0;
        }

        .social-proof-text {
            font-size: 14px;
            color: var(--gray-600);
        }

        .social-proof-text strong {
            color: var(--navy);
            font-weight: 700;
        }

        /* RIGHT COLUMN — PHONE MOCKUP */
        .phone-col {
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .phone-frame {
            width: 320px;
            background: var(--white);
            border-radius: 40px;
            padding: 14px;
            box-shadow:
                0 25px 60px rgba(13, 32, 59, 0.15),
                0 8px 20px rgba(13, 32, 59, 0.08);
            position: relative;
        }

        .phone-notch {
            width: 120px;
            height: 28px;
            background: var(--white);
            border-radius: 0 0 18px 18px;
            position: absolute;
            top: 0;
            left: 50%;
            transform: translateX(-50%);
            z-index: 2;
        }

        .phone-screen {
            background: var(--white);
            border-radius: 28px;
            overflow: hidden;
            border: 1px solid var(--gray-200);
        }

        /* Newsletter preview inside phone */
        .nl-preview {
            padding: 24px 20px 20px;
        }

        .nl-header {
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 16px;
            padding-bottom: 14px;
            border-bottom: 2px solid var(--gray-200);
        }



        .nl-greeting {
            font-size: 14px;
            color: var(--navy);
            margin-bottom: 14px;
            line-height: 1.5;
        }

        .nl-greeting strong {
            font-weight: 700;
        }

        .nl-article {
            background: linear-gradient(135deg, #f8fafc, #f0f4f8);
            border-radius: 12px;
            padding: 16px;
            margin-bottom: 14px;
            border-left: 3px solid var(--yellow);
        }

        .nl-article-label {
            font-size: 10px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.8px;
            color: var(--yellow);
            margin-bottom: 6px;
        }

        .nl-article-title {
            font-family: 'DM Serif Display', serif;
            font-size: 15px;
            color: var(--navy);
            line-height: 1.3;
            margin-bottom: 6px;
        }

        .nl-article-desc {
            font-size: 12px;
            color: var(--gray-600);
            line-height: 1.5;
        }

        .nl-prompt-box {
            background: var(--navy);
            border-radius: 10px;
            padding: 14px;
            margin-bottom: 14px;
        }

        .nl-prompt-label {
            font-size: 10px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.8px;
            color: var(--yellow);
            margin-bottom: 6px;
        }

        .nl-prompt-text {
            font-size: 12px;
            color: rgba(255,255,255,0.85);
            line-height: 1.5;
            font-style: italic;
        }

        .nl-quick-hits {
            display: flex;
            gap: 8px;
        }

        .nl-quick-hit {
            flex: 1;
            background: var(--white);
            border: 1px solid var(--gray-200);
            border-radius: 8px;
            padding: 10px;
            text-align: center;
        }

        .nl-qh-emoji {
            font-size: 18px;
            margin-bottom: 4px;
        }

        .nl-qh-text {
            font-size: 10px;
            color: var(--gray-600);
            line-height: 1.3;
            font-weight: 500;
        }

        /* MOBILE */
        @media (max-width: 900px) {
            .container {
                grid-template-columns: 1fr;
                gap: 40px;
                justify-items: center;
            }

            .content {
                text-align: center;
                max-width: 480px;
            }

            .logo {
                display: flex;
                justify-content: center;
            }

            .logo-img {
                width: 260px;
            }

            .stars {
                justify-content: center;
            }

            .form-row {
                flex-direction: column;
            }

            .cta-btn {
                width: 100%;
                padding: 16px;
            }

            .social-proof {
                justify-content: center;
            }

            .phone-frame {
                width: 280px;
            }
        }

        @media (max-width: 480px) {
            .page {
                padding: 32px 16px;
            }

            h1 {
                font-size: 28px;
            }

            .description {
                font-size: 15px;
            }
        }

        /* Subtle entrance animation */
        .content {
            animation: fadeInUp 0.6s ease-out;
        }

        .phone-col {
            animation: fadeInUp 0.6s ease-out 0.15s both;
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
</head>
<body>

<div class="page">
    <div class="container">

        <!-- LEFT COLUMN -->
        <div class="content">
            <div class="logo">
                <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAd0AAACXCAYAAABQiYHQAABn6klEQVR4nO2dZ5QUxRaAv+pJG2YTObPkoGSJC0pQVExgREXMWcw54jNnRH3PrKggqIhgQEAkSJQMCpJ3yXl32TSx6/2YsDMbZ3pmo/2dMwdmp7v6VvftulW3bt0CHR0dHR0dHR0dHR0dHZ3ahKiQUlv3SkqQMY2kVBuB0khCYwViVeQhKcUhUA8J4TqYl77qUIVcX0cnCkgpk4BGAZ/GQCxwKOBzUAhRLfVYShmPR+bAOiQCRwiWf3+VCfkvJUTdOiSEOFhlQoZAbalHZRIVo5vQtE9d1Wg4WxHiLCk5SwjRNJTzpJQFCP6Qkrm45dy8fcs3RSpLXMu0cxUh+0ZaDkBu+rLxWs6Lbz5guDAwIBoyqKq6RlGUXtEoy6UqX9j2LNkV+Ddry36dEMoV0Si/GFK4ERwVqIdcKIekdB62Zfy5u0KuFQWklHWBs4GzvJ+Q9BgoAP4A5gJzhRAR67EWpJQJwJkUyt82xFOdwAo88s8DVgkh1CjIczvQMNJygD1CiE9DvGZT4OYoXBNgoxDi+0gL8T6XvkU+DUI83QGsB1b6PkKIHZHKpIXqWA8pZSzwSKTleFkshPg9SmWVSkRGNz51wPWKFHcgOK3ob4oiaZyikhAribVIDArYHIICOxzKUsizKcXKk5JjAvVLaTe+lHvoj6NaZLKmDnhbIO7Wcm5RctKXaro/1pZp+4WgScQCSDKlKu8QBvF1xGUBqsrwvD1L5wX+zdoy7WIhmB6N8kNGyp0SsRIpV7oV8WdBeuZa2OyoVBmCxJHXA3dAcT12u90cPHyMnNx88gtsuFWV2BgLsTEWGjWoizU+rqQijwFfAi8JITTpcThIKS8B7gZOL/qbqqocPnqC7JM5FNjsOF1uYixmYmMs1K+XQnJiQklFngSmAy9G0jBKKTcCXbSeH8AyIURaiNfsg6dRjwZThBBXaz1ZStkYeBa4HjAW/V2jboHHeD0mhPhVq2zhUJ3rIaWsAxzXen4RXhRCPBGlskql2A0sn8HGhBaO6xHiUaC1z2x3SXUytLuD09q66JLqomkdNwZD6TYrM1ewbZ+BNTtNLN1sZMEGMzanUg+U+4hRb7emDvhQlfaX8zPWaHJLxMeonNrSHfZ5J3IE2w9ouC1eElr2vwGvwe3T3oEQ4dnto9mCXYe81xe8hiL8xqh3OweKEl55Tjes3WEq9XeBKkHRXH5ZSCmxOwUFdsGJPMGxbAUQIEQbAW0Q4iojkJCakiPlgIm5UnmDPUsyoyZA2bIZ8TQiHj32snHzdn5btIJV6zez8e9t7D94FFUtfdCXnJhAx3ap9OrWiYH9ejB0UB9iYyz1gPuA26WUHwIvR9u9JqVUgCuBx4BTfH/fvmsPcxYsZ/X6v1m/aSt79h/C5Sr9PbDGx9GudQt6du1I/95dGT6kP8mJCYl47s21UsrvgOc1jt4lwIFDR8nYG371W6c2pWH9uv5ywrkmwPq/tlJQYA/7up06tPJ1RsK5bqEAUibjeS7j8LhaAVi36R/mL/6T1Rs2s2nz9pB0q0PblvTs1okBvbsx7PQ+PgPWHZgtpVwKPCCEiFYnoybWw/+M/tm+m8ysnLAL6N6lA7ExlqCyKpKwWti45mlNFEX+JIToAZAcrzL2zAKuO9NGaoPIvFH5dpi1wsL7v8SyMd1jJKSU+SrisvyMpb+EWo5vpNu9tZPfX8oKW47vl1m46e1EQNtIN6HlgO0I0fas7namPXYy7Otf/VoCs1fHAGTl5NLCGs9ZvpHo3klHiY8Jr7wjWYKOt9YDyh/paik/HBxO2HNUYVO6iXU7jfy23sw/+wI7ODJbIt/OpeAt0tdnVZQcUsomwE9AD4DM7Bw+/3omn06eSca+yGxjbIyFi84dzJ03XkG3U9r7/pwPXCaECFmPy8LrBp8FnimM3Lx8Jn83m4+/msHWHekRlW0wGDjrjL7cdt1lDB3U239J4CkhxAthyrkR6PL2h1N46qX/hi3LW88/yI1XjwSNI91ew65i+649YV93+uevc9YZ/UDDSFdK2QP4Fa/b9fDR43wy+Qe+mPYTBw5F5vQwm02cM3QAt113KQP79gj86TkhxNMRFV6EmlKPwJHuZTc8xJwFy8OWZ/Vvk2nfpiVU0ki3uI+3FOJa9O2lKKwWQvQwGlTuPD+f9e8eZ/xV+REbXIA4C4w+w87CV7L4/L5smtd3IYSIMwh+Tkjt/2jIBcloBof1Kn2IWALW1AGjEaItwP2j8sO+2qYMI7NXWwCQyLc5tjT8bls1xmyCtk1URg2w859r8lj2Riar3z7O3RfmUcfqBkSSQHnaKuP+im/Wt2tFyCCl7AWsBno4nS4mfvQ1pw68hGdeeT9igwtQYLMzdcYcBp1/A2Nuf4I9+w8BxAE/SylD1+NSkFJ2AdYAA1RV5dMpP3DqoMt4aPxbERtc8LgKf/19GSPH3sewi29lzYYt4OmcPy+lnCalrMBuWc1GSnkVsBZokJObz/hXP+DUQZfx8tufRWyoABwOJ7N+XcSI0eM4+/I7WLfpH99PT0kpZ0gpS/XjhkNtqUd1JSSja20x4FKDYlwtBI2b13fx63+yee6aPBIr6NZc2M/B0tcyGTXA5hPzJWvLtK9COllE00WwxhnW4VI8CTCgs4O+HV1hX+2N6bGAAEleLvkTwOf+jRbuYmVFt/zwad1IZfzV+ax7J5N7L8rHbJIIIZoKg2F5QuqAi6J5LSnlpXgMbuM9+w9x1qW38eSL75GTG34HKRRm/bqIvsOvYfpP831/eklKGZoel4CU8gJgOdDy0JFjjLhyHPc+8TonMrOjIW4xVq37m6GjbuGFtz72uQ8vB5Z4PQUhiRwlUTS5lyvzulLKV4HJACvX/kW/c67hzf99id1eMaEKy1dtZPBFN/PCWx/jdrsBRgLLpJTNIym3BtajSp53JJRrdK2p/QYLRXwLnnnb31/Momfb8A1KuFhj4ZN7cnjg4jwAhODq+JZpH5d7YhWNdBOap10ohGdu7YGR4Tfi/+xTmLUyYJTrda9KojjJShmT7FVMQpzk6avymPdCFu2aeLwcIH6Ibzng/miUL6UcDHwLnnnb0y+4kbUb/yn7pCiQl1/A9eOe4dV3Pvf96WopZfl6XAQpZRoel3L8lm27GXj+DSz7c0MUJS31urwy8XOuvOUx7A4HQC9gXogj3mjpWzjlRFPHQypLSvk88BDA5OmzOefyO9m7/3AUxSj1urwy8XMuveEh8gtsAN2ABd4oYy3l1cR6VPrzjpSyjW6LgSlg+BqgYzMXM57Mpm5i5Q6Mnrgin3tGegyvIrgxrkW/CypVgBCRinwGoHtrJ0O6hTdABnhjejwgkFIW5Ir816ItX2lE16hHTpeWLua9kEnfDp6etSLEG3EtB5wXSZlSyhTga4At23ZzwVV3V9josDSef/Nj3vzfl76vN3pHrSHhDWiZCrB1Rzrnjr6LI0dPRF/IMpg9fymjb37UF5TVGZhQqQJUU7yduccBPpsyk9sffME3Yqs05i/+k5Fj76fAZgdoA0wKt4zaUo+aQJlGN0GoXwpolBin8sUD2dRJqBpP5NOj8xjewxOFaBCGSXEtezWuEkFKIb5F/2FCiJ4AD1wc/ih3+wGF75d7RrkC8W5FBhHVBBLjYPoT2fRs6+m8GBBfxqf2bhRBkV8CjbJzcrnq1sfIzK6aqfLxr37Ar78v832d5F2KEQqTgWaZ2TlccdMjld5h8DF/8Z88+txE39dbpZQRdYZqOlLKhsB3gPht8Urue+qNKpNlxeqN3PbgC0gpAUZJKe8I9dzaUo+aQqlG17P0RZwH8OJ1ubRtEnmwlFaEELx3R44n2EaQoghLVNatRgshxOPg8QaMOC38JQpvzYhHSs8oF6ft1agLWAOJs8CXD5ykQbLnmQtM0wgj8M+HlPIG4DyAR559m53p+6Italjc9uALPqPpH32XhZTyNmAEwP1Pvc6ujKpNHvXhF9P55bclvq9fSikj6QzVWLxLtmYAdY8cO8FN9zxb5rKZymDGz7/z0Zf+XB5vSSm7l3dObalHTaKURqyXSaK8AtCvo4OrzgjfkESbuomS8WO887uIM+Japp1bxSIBENeyX08hxFCAe0fmh70ud/dhhW+XeEa5CPFBzoE1x6IuZA2lcR2V12/0jEoF4vT4lv1Hh3O+lNIEvAKw7M8NTJk+O/pChsmJzOzA5TNnSClL1WMppQWv/L8tXsn0H+eXdmilcv9Tb5CXXwCejsNzVSxOVXEl0B/ggaff5ERW+MsDK4JnXnnfNw9rBt4M4ZTaUo8aQ4lG19oy5gIhqAfwxBV5lStRGVx5uo3WjTxBXEr0Ur1FhAHlWYDUBm4u8Udbh85bM+JwqwKJdKhSH+UW5fw+Ts7u6en0CSEeCvP0C8Cjx8+9+VGUJdPO5OmzA0fcZenxaDy5khn/yvsVLVbIHDh0lI++nOH7eqU3x/O/jTsAVq3/m5mzF1axKIXk5Rfw8tv+jJlDpJTlpQKtLfWoMZRodAXyBoBebZ2kda74SOVQMRgEd53vmTMVglHWRoPqV6U81hZppyDE+QB3X5hXZgaukthzVGHqYu8oV4qPtGbfqu08fKnfw9Hd2nxAsVSHZXADeBqUpSvXV4Bk2lBVlbc/nOL7OkpKWZoe3wwwd+EKNm7eXimyhcrEj6bgcDgB4oExVSxOpSKl7IY3McnLEz6rYmmKM+X7XwPXnI8r7bjaUo+aRjGjG9eyV2MJ5wJcPaSg8iUqh1FpdixmT0CXiHHfUKXCKPIpgEYpKlcODn+UO2FmHC63gpS4VGxhZfv5N9GjjZu0U7zrBA3cF8o53iClcwG++jYqiaCiyvc/zcdWuPaxmB57e/ZpAF9M+7ESJQuNY8ezmD1/qe/rnVUpSxVwJ8De/Yf5bXGFZGCMCLfbzRfTfvJ9vamMZBO1pR41imJJhg3EnIdAURTJhX0jWxB9NEswb4OZzRlGsnMF1jhJuyZuhnZ3aM5ilRQHw7vb+fHPGJDiArxzXpWNpVnfdkguQ8BdF+RjMYU3yj1wXDB5gXepo5Cf5qfro9yyGH26jaV/m0FyIamDY0hfWF4v5zxAcbvd/PBzZBuH1KubzPDB/TmlYxuSkxLIyc1j+849/LZopeYsVidz8pjz+zIuOncweNzgRfX4ct9xAcZNE8mJCQw9vTfdT+1I3ZRE8vJt7Nl3kN+XrGLz1l3lF1AKU3+Y45O/i5SyuRBib0SC1hxGAUyd8asvylYzPbp05IwBPWnWpCExFgvHTmSyev0WFixZ5Zs318SU6bN56oGbwZMN7SxgZgmH1ZZ61CiKGV2J7CsQ9Gjt0rxESFUlL30bz7s/xWF3FDdGiiK56gwbL1+fS5wl/PKHdHXw458xSGRPPKP1Sg+3MxsMjyKEUsfq5tph4SvV27PicLoEUuJyOcPLaRtNAjc80MLJfHh8krXE3xQg2Spp28TN0G52mtXT/mKf38fOPR9IVFUo8aptYB78Vs4pfQHWbvpH8xIhIQRP3Hcjd99yFTEWc7Hf3W43k7+bzUPj3/KtLQyL+X/86TNaPaWUSpHt9PoDLF6+BqdT2xSPEIL7bx/D/bdfQ4K15EHC/MV/Mu6xV9h3IPwkCIuWrsHlcmM0GgD6AbXe6EopO+CNE5hTuPwrbDq0TeWdlx+hX6+SN2E6kZnN829+zMdfzSjx9/LYf/AIf/+zk1M6tgGPxyTIWNWWetREim+nI0RvgIGnah/l3vHfBL75w78pBVLKfUKIfSAbgUhVVcFXC2LZfsDIT89khj0XOvAUp1dUERufOqBrXvqy9ZqF1YDHBS/GCuC2EQVhbxJwOEvwxe+e+yOQX9oOLAs/K3uUkChhxlsHY3MIpiyMLfc4g2Ll6iE2XrxWW0crKQ56tHaxZocJIQynU77R7Q3wx/K14V/MywdvPMnoUWcH/mmf99MISDUYDIy94nzatW7BuaPvCnupRYBssUBXPFud+egLsHDpGm3CAx+++RRXjBwe+KeDwG6gPtAOYNjpfVg86xOGjLw57FF7bl4+azZuoW/PU33yfqtZ2JpDP/B4IFZ78lKHTbdT2vPL1HcDO0L5QAaQjWfHqwZ1UpJ487kHSG3RhCdffE/TdX5fsspnrPqX8HNtqUeNI3iI06x/LJ6E6nTVsC0ewC+rzIUGV8plTiFTczOWNc9JX9o/J31ZK5zOesCPACu3mnh/dvhu+jaN3cTHeBo4oco+mgSNAIWYx4XAmBCrctM54Y9y35nl8QBIKVWnU4yPvoShE83cyxI2SuQi3wfJUukd/bhVwRfzYxn9chKqxksO6OT0CT2oTDk8G1t3Adjwt7YApBFnDQw0uMuAVCFEcyFEfyFEKzyjhB8B+vfuyh3XXxb2NXam7yM3z59Mxa/HUsrWeAwjG/7aqkn+K0YODzS4fwBthBBNhBBpQoj2eJZiPAs469VN5sM3n9J0nQD5+mkqoOaRBrDh762a1rMqisKnE8f7DFUenn2QrUKIzl7daoinA7YJ4O6br2RwWrFtnkNiXWGa077e5XO1sR41jiCjm6AovYQQCkCnFuGnMgT4ZK532CfliRy3PNO2e1lG4O85+/88npO+9EIp+Rvgs3nhb1oihKBjM0+nQAqlUo1uQpNe9RDyFoAbzi4gOczFEseyhb/OAqbYDiytslFutJGq+4Hc9GWDfZ+cjKUDc9OXtpA2pYEv3/CSzWam/aFto5pOzf1u1vIa+F54dVvrnOXNYy72/fcEcKYQIkiPhRDHhRAXgkePbxwzStN1tmzf7ftvoB739f1n8zZt8t954xW+/+4RQpwuhAgqSAjhFEKMB14AT8ehZ9eOYV/nr392+v7bU5OgNY/+AJu27NB08tlD+tOudQvf13uFEO8IIYJ6od69iwcCJyHoWYZFgIwmij+f2lKPGkeQ0VVR/Zt5t6wffu/H6YI//vZ0RFQpPmDf8lKHgQLeAth1yMjuw+HPKbZs4PaWI1uFfXIEqGbLgwJhjjGp3HFu+KPcd3+OpcChIKVUHW75bAWIGBaVsaFC7qE/juZmLLsZ2AoweaE2o9vRa3QFxFia9mlfxqF+Pc7YeyDs6xiNBk7v73+3PxBClPWg3wJok9qM1Oahbr5TSMDm7oF63AY8EcJadkBqWL8u3U/t4Pta3trviUABwNlDB4R9rfQ9/vsbK6VsGXYBNY92ALs1ZgY7p/AeHwS+KO04IcRJ4H8AQwf2xmQqPhNYHunBut+uyM+1pR41jiBrJwQJAIlxKrEa5t227jPgcnuKFIp7blnHupwO/+9/ZxjCvlbDZK/R9cpcKaR2T1akuBPgmmE26ieH5yY9kSP4ZI7X9S741r5vubZuZrWl+NaBgUipvgOwdrtRk4u5aZ3CjqBiUlLKODQBIDsnN3BZTsh0aJsa2DiUqceBv5/aKfz1+4eOHPf9N1CPEwEOHtGWnKz7qUH9kZ/LOlYIkQmsAM8cXbgcPBwkY+W9i1WAN2WiBeDAIW3PplthZ2iuEKI85fwFwGQy0rl963IOLY7d7gjM053o+09tqUdNpYjRFVaAeonagoEPZRUW53SqZQ4xCg6oh6Q3Tv1wZvhGt36Sp9GWlfiiW2X8OARWo0Fl3AXhj0D+90sseTYFKaVEdf+nAkSsYsqOiFMR6QA2p0LG0fCfeb0kFYPiXaMtDXXLONQKnpGiFho3rBf4tbyh8iG8+3A2alCWSCVz9Him77+BepwAcKzwt7Bo3Cgo10YoyaYPQLF6h8TRYBlrfINYDv4HfFTjs2nSyH+PQxli+nVPy7OBIDkDn01tqUeNJMjoSul52WPM2gJdcgsK21y73VROKOQaJ0IcA8i1he/h9MsoK8noNusfKwT3A4weFP7yl6w8+OhXX5SvmJG7Z+XmaItY3ZFuedT3/6zc8J+5EIKkOG8AnZR1yjg0AcCmYRkPgDU+KLivTD0WQjiBYwDWUpbllEWAjMVGulqWIQEkWv2BBseEEKGsN9oPkJhQ8tKvsihyj2v1SJeABr+gIPxkOAAJhc8mlHkPfxyBlmcD+PanBUgK+HNtqUeNJHgy1euqNYfvdi9Ooq3ciVohyQWwObUb3cpyL8cbxB1AshCSuy8Kf5T74ew4TuZ7b4l0aQsVrQCiGb1crnvZKI/4/p+noaMFYPHGLgpPsv3SSACwO7QFAxYhlICDXKDEtbzlEeD+LmZ0HRrlN5v9AZ6hKmo2RCw/1IJRSDn4G3ytumUx++9xuc/G26FzAlg0PBsAm83/fAKfTW2pR40k2L0MNgCtyUkS4gpPtDotzUM4RXODb/DH/4hKeAidzQLxKMCo/vawtznMyRe8/4t/LeuP1WmUW5mb2Ctug//NcauRGV0QZRldG4CisWo5uUGbfFSoHns3hYfgxkQBcEW+iXiocmmWv8hyEw2RIDUK/5xIFDZ4D/WeR7RExuX2OzoCn01tqUeNJDh6WXrcvfklZJEKhQYBgUWqQiiRjBE3+BIZWa7KELCmptzg23XpnpHhRyx/PCeWrDzPrXZL9ZnoSledCDPLiQYU75wuilrWpPAxgLhYbVHSh4+eCPxaKXoMBOpxtO5jqOVU9vVqKtGsX6hlRcVdU+R6taUeNZKi7uUjAPkaXX/tmzj9gS6KEKGMEGoAg40C+SjAOb3sdGkZXkq+PBu897N/lPtrfsbydVEWUKc4R0C70d22MyNwBFpL9FhHR6c6UGT2Vj0ECsdyFKSUYW/IbjEJuqS6WL/LBMizgfI2AZUAs1aY2b4/vGjW3Yc9xwuEtkmCEIlv4bgSREvwbFIfLp/OjeFEjqdv45KyFkYsV0sOAdSrW5YHunQcDicbN2/3JYsIWY9HnjuE9m3CW6raqkVT338rVI91dHSqB0FGV6rqMRQFu0NwKNNA4zrhLx26oI/DY3QlF8W0GNjatmdJWSl1BMCWvSa27NXm8q9Y9/Iap6IMeApg0Cl2+rQPb5RbYId3f/JEtEop5xdkLFsefRl1SuAYeAKDGjWoxyEN611n/brIZ3QvklK2LprRqQgCoHOH1nTuEP46RC8VPk2io6NT9QQbXTeHfQ7n9MOKJqN7yUAbL34Th1sVwoj6AGXstSmRK4AI0yCWuzBbM9YWaZfjzYBy/6jw53InzY/haLZ3BC/kc9GUTadM/FvmtGrZRJPR/XbWXJ68/yaMRoMAytRjPMklIk3nqRtdHZ1/AUFGt2D/yv3W1LSjAuqv322if6fwtxRrUV9l9CAbkxfFAuLW2Gb9JxXsW/5nScfmZiy7SpvYZSCiuM2fwuMAPds6OaNLeHEAdqdk4izPWjaJ/CM3ffmiqMmlUx77gaNA/R5dOrJ81cawC9i7/zBfz/iVay47D+BWKeUkIUSJeiyEiLYeR2sZV4VHL1dQOTo6tZaiaxClgNkAy7doj/B+9Io8EuNUhMBgNIjJ0Lny5qtkBJvDFkFAN4AHNMzlfvV7LIcyPaJIVdXncisRb+L12QADenfTXM4Lb35Mdk4ueJZYTJZSVpYe69HLOjq1lOKb2KvyR6GIscu2mHC7Zdh73QI0rSt5fmwud7+fCEK0TUhNfi4nnUeiInEl06m5k3NOsxNOe+J0wYSZ/rncdXl7VpS396tO9PkRGJvWpxuKomjavuzAoaM89p+J/Pe1xwHaAs9BjdLjsEaeCdZ4HrxzbKVdT0fn30gxo5trtM+zumPcJ3IUw8K/zAzrpm151Zghdn5cYWfeegtS8lB8av/f89KXz4lY4krmvlH5YUdxT1kYw/7jnrlcFfFERcilUy7zAHfdOsmGIQNPY/7iEj3D5fLVd79w0YghnD2kP8BDUsrfhRA1RY/DUtzEhHiefvCWSruejs6/keKu2F1rshFyCcA3i7Wtc/Qx4dZcGiS7EUIIRSrfWVv07RxRgZVMq4YuRvULL/+tywUTfigc5eZnLJ1dEbLplI0QIhtYAjB61DkRlTXu0Vc4fPQ4eIzKd1LKGqXHOjo61YcS5z8lYibADyss7D2qfYq0cR2Vrx/OJs6igsCKYvw1oUkvbdtMVAH3XFQQtnt92hKLfwcdoYrxFSCWTujMBBg1YgjNmjTUXMihI8e47IaHycsvAM8ORr9KKWuMHpeHEOJFER2+rOq66OhUd0q0qHl5mR8BWU6X4I0Z4e+cEkiPNm4+uvskiiIR0FyaYhbSYqC2rAWVSJM6bkafHt4OHG63ZMIM3yiXzTl7l86qCNn+zfgSRQnvxuvl8BGQZTabePiuayO67vq/tnLD3eN9uWqbAwullNVej3V0dKoXJQ9jj27ORfIawOQFMew6FFlA8LmnOXn1+lwAhOAUq5B/VPcR77gL8jGHGcA9fVkMOw/5psnl01EXqobjli7/fmAxJm0xN74dqSSUuxGoECIXPHo85rLzaNWiiaZr+pg9fykPPvOW7+spwB+1acSro6NT8ZRqTXPyMydKyTG3Knjtu8hGuwA3DLfx8nU5gMfwYo5ZEt+qr3afXwVSN1HlmmHhjXJVVfLm94Wj3NyMZd9XhGw1GbNi9D/v+BiNRte3GYeqhLr79kTgmNFo4NF7btB0zUA+mfwDD40PMrxLpJTVUo+rAdGKZj5VSrkwlA/wvyhdE/RobJ0KoPQh7NHNuRL5EsA3S2JYtzPyTXZvOdfGGzfl4NXlDopqWBKT2i814oKjzB0jCogLcwOpmSti2HbAe4882af0F7YIUhQap0Yp4S/hsTulf09iKWVWKOd4R7svAVwxcjg9unQM+7pF+WDSdO598nWkZw/MDngMb2rEBdc+ohXNnAicEeKnZ5SuCXo0tk4FUKYlzcvIetfaMuVGEJ1vfSeBha9khm2MinL9WTYMCtz3kRWJaGtEWRnfrP+ZefuWb4qsZC8iMmOXGKdyw9nhRSxLKXljhmcnIYn8Jzd92dRIZKjFnA1QP8lNvaTwH9PhrMJNMUJxLwfwLnCjoiidP57wNAPPu54CW3jPuCifTv4Bl8vFxBcfRlGUtsBKKeWZQojo6LEOf6xYG7jbU9hkncyJVAS946wTdcoZvm52qLLvWIMwrt5x0Mjjk6xMuCU34ouOHWYjMU7l1ncTcbpEA2EUS62p/S7MTV+xMOLCI3xRhnZ1hL35+c+rzGze45kAliovRHL9ykagyrIcHuHhLvXex7Qa0FJIcTPA2T20pRnOOFxodPOFsiPU84QQDinlWGB1u9YtePmpu7nnidc0yRDIF9N+4mROHh+/9TRms6kBsFRKeaEQYmHEhevw/U+/8/1Pv1elCPpIVyfqlNva5u9ZuUZK+QLAF/Njmb0qOpnwRvZ3MPXhbOJjVIAEUObGtRxwXlQKj4BwDS5AxpGAvovirFHZpyQaKhwqzfrHxrfod6Y1Ne0tkxTpAAZFcuM54W8eAbB5j9foSrmDPUvCGekihFgDng7R9VddxIgzB2qSoSg//LKAy258mNy8fIAEYK6Ussr1WEdHp3oS0hAnN8M8Xko2A4x738qOA9EZGQ3p5uSHJ7OoY3UjECYF8UNCy/6jIiy20nuno0+3YTJ6BnkKxusq+/qR4BnpRgdFMcxLSE2T/o9RyVcUwzwB9wIIIXlhbC7dWmlzGW7K8HRuJCVvPBAC48Gjx/999THapDbTWEwwC5as4oKr7+FEZjaACfhBShmpHuvo6NRCQrSeC10q6hiAE7kGLn8pmSNZ0bFtvdq5mfl0NvWT3AiBEaF8H98y7WrNBcrKN7p1EyXn9fbNEYrbqEFuqQod6XoxGlQGd3Hw0zNZ3HJueFHhgSz+y+NlkYJVWs4XQriAMQB1UpL4ftKb1K8XnaW2azZsYcSV4zhy7AR4pm2+l1Jq12MdHZ1aScghyfkZy9dZW6ZdIgTT048YuOLlJH58JgtrbORCnNLSzU/jsxn5nyQOZhpQBF9ZW6YV5GYsrTHLbsYOLeCH5TGAaBnfov/QvD3L51e1TKEQ6ZxuilXy4zMle3oVAYlxklaN3BEH4G3dp7DvmDeftZQrtZYjhFgnpbwEmN6qRRO++/Q1Rowe58s2FRGbt+7i3Cvu4sfJb9OkUX2Ar6SUBUKIGqPHOjo6FUtYrW1uxtLvpVTvAtiw28S1bybi0LYfQjHaNXHz07NZNK/v3cNXyK8TWqRFZ+KtEjiji5PUBh63qVCUiLLGVyaRjnRNRkjr7Crx07+Ti1NaRm5wAb5dEuOVVx4uyFim2egCeI3gXQA9unTkq/+9gMkU+ZI4gO279nDO5XeyZ/8h35++llLWGD3W0dGpWMIe4uRmLH8P5KsACzZaGPN6IjZtwajFaNVQLXQ1I8wo/GJtPuDU6JResQghGDPUN1qSo6p7xq2ahNMFUxd5N9+Q4j0g/EW+RRBCvAe8CjDs9D58/eHLWCzRCRJM33uA80b7Xc1m4BcpZY3QYx0dnYpFk18xJ33ZI1LyLsBv6y1c8XIiedqn6oJIbaAy9ZGAqGYDv1XHBBolcdVgGwZFIhAm1WSJLNmvjp+pi2M4cMKAlLik4vowWuUKIR7Bs4aX4YP78d2nrxEXG9nOWj4y9h3k0usfCoxq/k1PoKGjo6N5Mi83Y+k4n+H9428Ll76YxMn86AjVo42bz+8/6TNgDY0os6BzdIYhFUijFMnwnp6AKkVwaxWLUyvIs8Fr031pSOW3ebtXHo5m+UKIcXgN7xkDevHDF2+SYI087Sl4Nkm45o4nfQkeGgKzpJTVXo91dHQqjojW/uRmLB2H5HWAlVvNXPSfZI5GKap5WDcnb93izdWM6GJNTX41pBMjzEgVKdcM9Q35RbuaMCcdzSVDFcHzU+PZd8yAlLLAheuJiriG1/C+DtDvtK78/PU71KubHJWy5y/+k3se96tuF7wu7X8J1Vq3QqCmy69TDYl4wW1OxtKHJPJZ8ARXjXgmmT0R7MEbyJghdq490zNPKhD3xDcfMLzck6pgyVAgZ3V30KSOb/85We0DqipjyZBWflxp5oPZ3vSaQj5my/hzd0VdSwjxEPAsQPdTOzD32//RvGl09jH48tuf+XTKD76v90gpy9fj2kG11a0Qqeny61RDomIdc9OXjZeScVJKufOQkXOfSmbLXkP5J4bAy9flcEoLT4i0MIivrI0G1Y9KwRWEwSC4arBntCuFuJzWvZKqWKQayYotJm5/LwEQIFmal758YkVfUwgxHhgHyLatmjPvu/fp2K5VVMp++Nm3+WuLP3PlV1LKaq3HOjo6FUN01kkAuRlL37WmDjgmJV8ezDQYz38mie+fytacfciHxSR4944cznw8Bbcq6kuL+wWgWo8gxwy18caMOJDCYnVZxubCO1UtU01izloTN7yVSIFDQYLNpcirqSRXnxDiXSnlMeDLJo3qG3/95j0uvPoeNm7eHlG5DoeT2x58gYUzP8ZoNNTHk5KyWutxFIjomT1451hGjhii+fyrbn2MPfsOlX9g6ejuZZ2oEzWjC5CbvmxqfGr/TFB+yMwzxIx6LpnpT2TRo01khrdbKzd3XpDPxJnxCCFujknt96ItfUV6iQdX8ZwuQIv6KkO6Ovh9gwUEt1CNjW50NzyIDJsDXvomnnd+jMXr2csSbi607V2WUZlyCCGmSikzgR/qJCfG/DhlIheNuZf1f22NqNyNm7fzzsdfc99tYwBullK+KIQnJ3UtJSL3bNPGDejauZ3m8y3miGPWdPeyTtSJqtEFyEtfPie2Zf9hRpQ5WXmK9eIXkpn+eDY927oiKveBkQVMWRjDsWwDJqk8ZYMboyRymbjdEoMh/Hdv7FAbv2+wIIQ4NbZZ/z4F+5ZrzRdc63G6YPpSCy9+E+/POgVsdbjlefa9y3ZWhUxCiDlSymHAnJSkBOusyRMYec19rN34T0TlvvbuF4y59Dxf+smnKFmPo9VxDKkcKWULoHUUrrdFCBHV6HIve4FPQzy2KXBTlK5b5R14ndpH1I0uQEHG8mVxzQcMNRj4LTtPSbz4hSRmPZNF11TtI96EOMkjl+Tz0KcJSMTYmCZpz9oOLN0TRbFL5LN5sfTu4AzbTX7uaQ7qJbk5lm3AYBA3A9XS6EoUURXdeSkla3cY+XlVDFMWWTgStFeuXJR70n0hJ1aerALR/AghlkkphwK/JScmJM78agIjRt/Fps0h7ypYjNy8fF56+1PefO4BgLFSymeFEEX1OFqPJNRyxkBUtqQcC3wZhXKKstc7314uUso+RM/o6iNdnahTYX7F/L3LVrmlOgRk9sl8hcteTGLnwcguN2ZoAQ2TPRsjmMz8p8SDohi9nGeD12fEMXlB+AmmTUa46gxPQJVAXEnDrvHRkiuaRLpkyO2WbD9gKPGzdZ/CxnQDf24zMmetic9/szB+ShyXvphIu5vqctaTdZgwM85vcCVskKq8LDd92eCqNrg+hBCrgCFAdlKClRmT3qR1y6YRlfnFNz9x6Mgx8HR6S9ZjHR2dWkmFjHR95GesWGtN7X8RMO9otsF01WtJzH0+kySNuQcsJsEd5+XzzOQEpGQMTXrdwYE1UUrJUZwPZsdyJMvAd0ssPHdNDhZTePZ8zBAbE2fFgyDeaom/Oheilk2punA8R6HvfXUiKkNKFqjwWn7G0tlREiuqCCHWSikvAuY1qFfH9M0nrzJ01C2czMnTVJ7D4eTdj6fx/ON3AoyRUt4hhKgwPQ6Vw0ePc/oF4c/abF3xQ/SF0dGppVR4BE1u+vJFEnktwPb9Rm57JzGi8q4eYsdklAiBwWo0V9hm4SdyBBNneXoHWXkKP68KPz1g2yYqaad4ElMLodwcVQGjRFWs05VS/iVhgltyXk5BjjU3Y+nQ6mpwfQghFgHXArRv05KP3no6ovK+/OYnHJ7dQgxAtdj03uVyc/DwsbA/Ojo6oVMpYat56cu/Bh4HmLPWwoeztee3rZMgOauHz5CJC6MiYAm8PTOOk/mFt2fyAm1b5Yz1bYIgOC2+Wf8u0ZAtmkQzI5Uq5YMS95DCjzrY7aY3qJ1cTlfzHPJSctKXityMZV1y05fel5+x9BcOb9Q2XKwChBB+PT53WBq3XnuJ5rIys3OYu3C572tF6XFlBwLpgUc6OuUQ5F62thzwBAJTJAVKRFZe+tIJRf+ek770JWvLAcOEEMPGT47nrJ4OWjXUtlnMyP42flllAUTxEYKIfAeaA8cFH/3q29VGHkeIugs3mdl7VKF5/fCKv7CvnUc/dZOZZ0AYxG3AnZHKF02iGkglxcbcjBULo1WcZjGkfAIi02MgSwgxoegfhRAveaOah/3n0TuY8/ty0vce0HSB73/6nfOHnw4VN9KtbC+GHniko1MORed0nxCISLel3wNMKOkHl1RuMQq52eZULA9+bGX6E9piZdI6+fbcJSWhRdrAnD1Ll/h/lCiRvvqvTo/H5vQkZkC6TxfC+LeUgqmLYnjo0vCm3iwmweWn2/lgdhwCcS1t297Pjh32yCTUKYcngArTYzxJLTbHxlgsbz3/IKOuvV/TBZasXO/7b4qUcqAQYkkZh+vo6NQCihpdCdCyvpv6yeGN6A4cVzhwwoBAlupisu1ZssuaOuAlEOMXbLSwdLORtM7hr99tXEelVUMXuw8bURV5PlDYWEWYHGPnQYXJCzyjXCF5J2fPys3W1LRvBVw2ZWEMD16ShwhzbDh2mI0PZseBID7eUf+KPHZ8EYmMOuUiwbOv7ZFjmWGd2LRRfZo2buAvoySEELuklC8B44ed3oe0vt1ZWmhAQ+bQkWPsytjvi4YO1mMdHZ1aSVGjKwDuGZnHdWeGNxh74/tYXphmRVK2RcotyH09ISbhIQTxE2bGkdZZ22i3cws3uw8bEdCjyE8RGd0Nu024VW8VXM5XPAWqnwiUyzKOGvjjbzOnn+oMq8xOzd2c1s7J6u0mX0CVbnQrFgHw1vuT+WzKzLBOfPDOsTz94C3+MsrgdeAhIP7+28doMroAf/+zw2d0i+qxjo5OLaTy8/8d3pgnkV8ALNho5vhJbb7g1IbeZBVS1A36QUavTjn73ScB8tKXz5WSA4B/FBwuY4d5d0sSDLQ066s9t51OtUAIkYe38zR0YG/qpGjb12L3Hv98cN2yjtPR0akdFDVQEUcfluVeLryKeA9AVQVz12nLj9qyvtt7PSJbJBoaEuSnALP+tJClId52VH87CbEel73JaKhWwVS1kGhE0YZSxnsABoOBs4f013SRjL0Hff+tDD3W0dGpYooa3YijD8tzLwPk7ln6t5QcA9iUri0/R3KCd85ZyEoZIbiE+omUUtodghnLwh/txsfAxWkel72A66BXpNG1OqUTjSjacssQQvwNHj3uekp7TRfJzPJPr+gjXR2dfwFVtr2MEHI3wD97tRndeP8AWSRSCfXw7GokFgJ8pdXF7Fuzi0iKb2m+LDqS6VQxuwE6adx3N7/A5vtvopSyemz3pKOjU2EEveQCoQJIqX2gEJJ7GZCwCyAzV9u14mIKL2NtNKhSRgkSPgFYt9PE3xmG8g4vRo82brqmeoKwqmuGqlqCCoQdZV6EUF3UuwDqpGjLtJaXXxD41afH0ZAfQq9DtJJaRLxGvppTWL/IfSmh3vOIPGIBOhT4bGpLPWokQUZXCnIAXBFsfxuKexlAQAZAToG2p64G3Ppch6NS1r3mCdN0kNkAkxdqDajybYLA4JhWA1pGTzqdAHIAjIbwO0YBhKqYGQAJVm37WShK0Cvo0+NoyA+h10Fz02s0BsmYo7WcGoK/fpX4bCLCaPR7EgOfTW2pR42kyEiXbPBsJh4ucV4bJGRoASESYgAsJm2dbJt31Y6UUlbajjTpC21SMgXgmz9icIS3cgiASwfaiDV7A6okd0RVPh0f2QAxlvCD9ALcvaEGNsUA2O0aXhqCZJRCCJ8eZwNYNMgPmupQF4qNukMixhKUHjUr7AJqFlm+/xSpd8jkFfjvcbnPRkqZ4D8vX9t+GLExfjkDF6xn+f5Tw+tRIyk6h5QJkO8If2rJF5mLwBpakJBo7DlPm9HNtwvv5TihqQCNqNL9CcCJHIVf14TfKCbGwagBngGNlOIGPaCqQsgEiIsL3xuRU7hzkFVKGcqzaQxwMldbCukAGQP1OBMgXoP8EEEdNOyaVOQeV+q7WAUc9f0nPl5bwrOAZ9MkhMP9e0jm5GgzVnGx/udzPODPtaUeNZJg6yo9L/uRrPA9BqkNCn3SluaWFuUdL6TnYbVqqM2XfSTb7xap1J5P/p6VayRsBO1rdq8Z6nUxC+pZW1guip50Ol4yARrUC38Vzu7gPMrl6jHeRmd3xv6wrwXQsL4/HCFQjzXLDxHUYU/4dWhYP0jGGj8KKQshhArkQbF6h0xAnu7GIRzuN2hang1Aowb1fP/1d4hqSz1qKsFzusgsgEOZ4fv5u7ZyIYRn1GpUGFnWsfGt+jaUQvYB6N46/DSQAIdOeEUXVfAQVPkJwPyNZg4cD7+D0reDiw5NvfVW0AOqok8WQJOG9cM+ccNfW1ELAwZGlnWslLIh0Adg3aZ/wr4WlNqYZAE01iA/aKpDX4B1G8OvQ+NC+aEWNIghcAK06RbA2sJ7fLaUsrxAgFEAObn57EzfF/a1rPFxJFj9m5cXfTa1pR41juCRrmAbwM4D4RvdxDgY7t1yT0E8YW00qNSnqaiG1wTCZFAkF/bTNhe246BXdOmRuTLJNdonSaRTVQXTFmtzz4w90zvvJjlLD6iKOtsA2rRqFvaJObn5zFng33LvCSllWa3Sa4DJ5XLzwy8Lw74WQLvWzX3/DdTjbQCJCfHUq5scdplh1uElIMbtdjPjlwVhX6tta/9A+oAQIvxJ4ZrHVvDsqayFGT//7vtvHeCZ0o6TUrYH7vKdI0NbFBJE+zZBTo6tRX6uLfWocRQd6a4A2HHIoCmY6oGL8zAoEgQpxKh/x7foP9aX8jCueVqThOZpg6ypaQsQ4hqAa88soHEdbRHgmzNMQTJXKrvWZIOYATB5obZAhCsG2TCbJEIIYVS5Kary6awAaNuquaZgpNfenYTLE8KfAvwtpRwrpWwHIKVsIqUcJKVcAFwD8NnXMzl0RNtm7qd0bBMks5eVvv+c2rGtpnJLqMM13gYQKWVjKeUAKeXvwPUAX0z7if0Hj0Qi/zJNgtY8lgOc2knbc1mzYQvzF//p+/qQlPIHKWUfKaVnlw0pO0kp7wPWANjsDiZ+9LWmawXIeEAIkVHk59pSj2ju4fy4rDgu9V0kyOjmqYaV4EnPuGF3+EkrTmvnZsKtOZiMEgH1FUWZZDYatyWkpkmDgf0YWCxgMMBZ3e28MDZX0505li3IOOoRXZVq5RtdQLo9LuZdh4ws2xz+vaqTILmgt2+FiLiRKkxUUgtZCZ70jN01ZIpavX4z4x57GYcnPL0+MAnYJj3d9P3AYrx6PGfBch57/h1NQtatk0zLZv4pMb8ee0eMGwBO695ZU9kl1OELYKu3DgeApcAQgN8Wr+SR/7yt6TqndfPLVyXvYRWwFODUTm0CI2rD4pYHnuOf7bt9Xy/Co6+Hvc9mM/AmYHU6Xdzx0Its21nUzoRGnx6nBslchNpSj5qyh7NfzmBrsWdJJqlp24D2izaZ6dsh/PnWqwfb6ZLq4rXv4pm33ozDGXxPOjZzcduIAq4ZWqB58f+iv0x403C48vfEbtBUSITk7V02z9oy7YAQNJm8MJYBncNfPnbNMBvTl8UgBI3jWvQ7L3/Pih8rQNR/HUKITCnlNqD94IGnsXLtX2GXMfm72WzcvJ1H776e4UP6YzEHj5i3bNvNe59O44tpP2mWc3BaL9874MJrZANYCXQbMvA0Xn9P26ZUk7+bzYa/C+tQdAnVP9t389/PvmXS1B81uf0a1q9Lp/b+TFwryzq2FrEcwGI2M7BvD+YtCr+vcfRYJkNG3sIjd1/PjVePDJyv9LN4+Vqefvm/gXOnYTN0UO8gmYtQW+oRMc+98RGJCdaol2syGZnw/IO+r/4XrKQh2gqg/Zy1Zh4Oc8N2H11T3Xz54ElsDth2wEBWrkKsRdKivpuGyb5ra++gzF1r8ZWwEhZqi8SKHIlQPwbl6R+Wm3n5OkFCXHgN16BTHLRu5GLXISMGxXAzoBvd6LECaH/O0DRemfi5pgI2bd7B1bc9gcVipn2bFqQkJVJgs5Ox7yBHjkYez3HO0DTff1cKIYrq8Qrglr49u5CcmEDWSW05Af7asoMxt1dMHc4e6t/kQQVWR1RYDUEIcVJK+Rdw6nnDB2oyVuBZE/30y//luTc+pFe3zjRv0hCL2cTxzGxWb9jM0TD3gS5Kl85tadakoe9rsRFibalHNJg5e2FFFIvZbAo0uqWMdAG36v7OoBjGrttpYtt+A+2bak9PFWP2GGCIIMVVEXIL4Kc/PT12VfBd1ArWgOpWPlAU+VSBQxEzllv82aZCRQjBmCE2/vO1FSnleXEtezXOz1hzsPwzdULgO2Bsr26daNemBdt37tFckN3uYNPmHdGTDIiPi+WCs0/3fS1Jj2cCdrPZZLnkgmF8MvmHiK5XEXW46uJzff/9UQgRnvLXbL4BTr3kgjN59D8TsWlMjALgdLpYsXpj1H3z11x2vu+/uym9Q1Qb6hHNOd2KxC9nsXnE/D0rfkTKnQCTftPm669IvvkjhgKHApK8vFxPLuSqIn/v0gMg5gNMXqDtXl052IZBkQghFIUYPaAqSgghfgR2Alx/ZfVbCj161Nm+Bf95UFyPhRAnwJP97Pqrqp/8Hdqm0r93V9/Xt6pSlirgv4AtKcHK5SOHV7UsxUiwxjH64rN9Xyd41+WWRG2oR42b0y0xeEcV8h2Az3+L5Vh29amT0wUTZnrmDSTyU44trfI8nFKonwKs2m5m677wY6EaJkvO6eXpYQohb6TmKFFN4B2AG666iLp1kqtYlEKMRgP3336N7+unQojS9Ph1gK6d23HO0AGVIluoPDzuWt989BYhxKKqlqcyEUIcxxOYxkN3XVs0/3SVc+eNV5CcmACePMUflXZcbalHTaNEK5F3Uv1MSplf4FB44Rttidwrgg9mx7DvmAEppXRJZUJVywOQh2WGbxOEKQs1rtn1u6VFy/jU/tWvy1lz+QzIj4uN4akHqo8T4fbrLqN504bgcTlNKO04IcRmYBHAs4/cXm0axV7dOnHJ+cN8X9+oSlmqkAmAbNmsMXfdNLqqZfHTrElDxt10pe/r+yGsnZ5A7ahHjaHkodmJlSeRPAow6bcYVmyp+vTAuw8rvOTrAAgm2vYs2VW1EnlJX2iTUnwFMHWxBZeGsK5h3ew0q+eZ9xZS6BmqooR3A4FHweNi7nda13LOqHhSmzfhifv9HYCJQojy9Ph+gE7tW/HAHdeUc2jFYzIZeeelR3y7I60WQlTpFE9VIYTYgsc9y+P33qg5yUS0eeelR3xRxIeAF8s7vrbUoyZRqj80d8+ydyRyLghufDuBwxryMUeLfDtc92YiBQ4FKeVfuelZD1eZMCWgon4CcDTbwNx14SdjUBTB1UO8o13BhQlNetUr+wydUBFCvAPMFULw+TvP0kBjrtloEBtj4av3X/DN5f4FlKvHQoi1eDsOj959PYPTTqtYIcvh9fH3+ZIV5AGXV6kwVc+DwM4Yi5mvP3zJ5wqtMp564GaGnd7H93W0ECIrxFNrSz1qBGVPQtoMY5BkHsw0cOUrSWRp20glIhxOuHliIpvSTUikw+lyXQKbtYfZVQD5GcvX+TdB0LjP7tWDCxBCIhAmzJYboyqgzhggs0mj+nzz8askJUZ/TV55mExGPpv4LF07twNwAJcIIULV41eBRQaDgUnvPUeXztqyCEXKfbePCQzqulcIsbus42s73ojtKwC1XesWTPv4FazxxdeqVgY3jRnFQ3dd6/v6Xjjz7LWlHjWFMo1u7qE/jrqR1wCs32Vi1HPJmnYg0kpuAVzzeiKzV/sig8U99v1/Vnqu5ZCQnon+uWvNmrwCzepJzuzmb4Nvj6Jk/3qEEEfxpmzs2bUjs76aQP16KZV2/fi4WKZ88BIjzhro+9M9QoiQ9Vh4dhK5GjiWkpTAT1PeoW/PU8s7Lao8du8NPPvwbb6v3wkhPq5UAaopQog1wH8A+vfuyk9TJla6N+XBO8fy5nMP+L7uwjNyDYvaUo+aQLnhtvkZy352S3m+lLJgw24Tpz+SwqJNFT/HuynDyLDHU5i33mtwVXlLbvrS98s9UURz3daakLepzxV5XwG4VcG0xdpGu/5NEBAtran9zwAQqFGsj7tYWRVdfnVBCPEzcD5Q0KNLR5b98jlnDOhV4dc9tVNbFv/4CWcP8SeSuEUIUb4eF0EIsR/PbkDbUpIS+GXqu9x14xWas7qFSp2UJKZ9/AqP3XOD70+ThBCXhXh6tPQhnHKiqYMhlSWEeBbP5hf07NqR5b9M4swz+kZRjJKpWyeZaR+/wtMP3uL701/AYK1rpmtoPaptm1OE0tfplkR+xrKfpWCAhENHsgyMej6Zm95OIP1I9NMFH8sWPPJZPEMeTWb7ASNAjuqWZ+fsWRZayLiM5pKbMDaYT1+fJaX8GrS7mM/u4aBBsjeRiBS3AkiUKNbHUKysii6/OuE1vAOAQw3r1+XHyW/z6cTxgfmPo0bdOsm8+sy9/PHjJ7Tz7MSTA5wthNC89MEbdNUP+MNkMvLik+NYNOtj0vp2j47QAZjNJm677lLWLZjKucP8mbOeFEJcF0Yx0dKHcMqJpg6GXJYQ4mHgOoD69VL4/vM3mPLBi7QL3iEnKsRYzIy7aTTrFwY9m1+A/kKIvZGUXQPrUa3bnABKz0hVGnnpy9bHNut/msGgzBWCzt8vi+GHFRZGnObg6iEFDO7iwGLSVn+3W7Jyq4mpi2L4dlkMdoenHCnlfqR7eN7elZtDLkygbduiEgl9pOvlY+DK7fuNrNxqDDt3tdEIV51hZ8LMOIQQV9Ks/11hXl+nHIQQ66WUpwFzgc6XXnAmo0YM4ed5S/jym59YsHS1b5OAsFEUhX6ndeHqS87lsouGB+Y63g8M9y4BilT+TCnlMDzrK0d3P7UDs6e+y5oNW/h08g/8PO8PTmSd1Fx+h7apXHbhmdxw1cjAbQUdwJVCiO8jlb82I4SYJKXcDswC6p4//HTOO2sQ8xat5ItpP/LbopXkF2hP3NW1czsuvfAsxl5xPnWSEwN/egt4sIwkGGFRW+pRXdFgJTubE1qmjEXwEODfwiU+RmVARyc927k4taWLZvXcNElRscZKYswSIQQ2B+TbBQdPKOw9pvDPXiNrd5pYttnIidzCNYhSckDChLz8zP9xdHNYWxFZUwdMEIh7wq9XcXLSl4Z9fxJSB+wGkRqN66uo9wqp7BWC6VEpT2V43p6l8wL/Zm2ZdnFFll9dkVKagbEQrMe5efks/XMDazZsZtOWHezdd4gDh4+Sm5vvT5NnsZiJj42hUcN6tGjaiE4dWtOraycG9u1OnZSkwMscwLMO8n9CCG1bapVdh7PwRDYP9f3N7Xazat3frFq/mQ1/bSN9z372HTxCVnYONrsDVVUxGg3ExcZQv24KzZo0pH2blvTo2pEBvbvRumXTwEvk48mW9aoQIuzdx6WUG4EuEVYTYJkQIq38w0BK2Yfobb4wRQhxdbgnSSmTgQeAcYBfIWx2B8tXbWDNhi1s3LydPfsOsv/gUU7m5GKzO5BSYjIZiY+NpUH9OjRv2pAObVPp6X02ATmIffwCPCOEqJC81zWhHlLKOsBx7bWsNC4XQnwLkQ3NhbVl2igh5CMg+pR/uAzlcluRvJ6TYZukYZQJgLXlgIlCiHFazi1KTrrNHK4c1tQBzwjE+GhcH+R2KcWjutGtOKSUAhgFPAKUq8dSylDmUbfiySY1SQihbdgcBlLKHsATeOpR5pxPiPKfAN7Fk3pPc8b6f6vRDZAlAY/Bug8odxlgiM9GAjOA8UKITVplC4fqXI9/m9H1E9u0bzNhULorCr0FSg+k7IQQ5axrkBkgtqiwXki52qmy3r532c5IZbE069/WZJTNIi0HIDd9xcKwT0rtnmwlpns0rg8gHM6/pNkUlVDVXNW4gT1LghrRhCa96lVk+TUJKWUzoDvQG+gBdALKW5+TAWwB1uNJyL5eCBGxHmtBSpkI9PJ+euKRvyNQVpDBETydhI3AWmCdEGJdlOQ5DYjG+qzsUGXyGohoRcgd9iaPiAgppRHP80gDBuKJK2gU4ul2PHq11PtZ4s3LXelU13pIKQdHo5wK5m/vKoqKnYS2NOvf1ihEa6GI9hJpkYgtBqHuyklfrn1zRR2dSkZK2RZojccNbcFjZHcJIWqEHkspm+DpPLTDM1LZjWcziH+EEFWw+l5HSpmEx2A1Ahp7/43Fk4HpAJ7O0EEhxKEqEzIEaks9dHR0dHR0dHR0dHR0dHR0dHR0dHR0dHR0dHR0dHR0dHR0dHR0dHR0dHR0dHRqH6UuGbrjiqRbt+x03nXwmLP5P+nOpNKO09HR0dHR+TcTFyNkm2amE03qG3ee1tbywAtfZi4Jq4BLh8WvwpMxRP/oH/2jf/SP/tE/IX5iLELedXnSe5RCsZHu5Wda13zzW25PgDfvq8/ZA+Jp38Jc/EwdHR0dHR0d8m0qO/c5+eLnk0yYkgnAnZclffjet9m3Fj02yOjee2XiGxO+Pnl/rEXw+/vNOa2zti3qdHR0dHR0/o1Mm3uSMU95EnC9fFfKiEffzZwd+HtQcvSflxaMA/jk6Ua6wdXR0dHR0QmTK4Yncv/VKQD8sd5ezM3sN7ofPELS9j1OU5P6Ri47M6ESRdTR0dHR0ak9+Izu0vW2VkV/8xtdu4xNAOjSVp+/1dHR0dHR0UrDukbqJCpk5ar0aEv9wN/8RteRJw0A9ZMNRc/X0dHR0dHRCYMWjUwAuA3B21uWueG1jo6Ojo6OTvTQja6Ojo6Ojk4loRtdHR0dHR2dSsJYWRfatt/A/A2FQVp92jno1c5dWZevsUxbbOFEbmHf6Jaz8zEYSs3eGVV+WG7mYGbhHP/1ZxYQU83i7KSUvD87zv+9jlXlitPtEZfrdkt+WW1h4SYThzINWEyS009xcN1ZkZetUz3JLYAvF8T6vzer6+aCvo4qlKhkbA747LdCORsmq1w8QNfLmkLIRvfvDAPrd2u30SdzBU98WTif/PjlufRqV6C5vGihqpJpf8SgSs/3OvGSc3uX/qJt2G3gr4zC+9C9lYtTWpbeeZi3zsyR7JKNpBCQEq/SKEVyaksXphJu79sz4/hnX+EP159ZgKGSYt0+mB3Lyq2FVvbygTZizLJyLh4ibrfgiUmFetWxmStio3skS3Dlq8ms22kK/nu2UqlG91CmCOqoNklRGdLNWerxG9MNbEov1JUuqS66puod21DJzg/WpdNPdVRLo5tnC5azV1tnmUY30jZIJ7qEfIvnrTPzn6+t5R9YCreem6f53Ipk8V8m7vxvov+7QZH8/b/jNEgu2bj8uNLCmzPi/d+fvjKXU1qW3nl4c0aw4SqN5HiVi/rbefKKPOomVi/D9m/jlncSixlcAGMlT8b8s9fAuP8V6ubQbvYyje4vqyy8+l2hbj58aR5dU/MrVEad6o/eBlUv/vVzulMXB2fecquCb/6wVLocWXkKk36Lpd8DdVi7Q+9uVhWbMows/quwgRJCMvp0Gy9cm8tVg21VKJmOTsVSm9ugN76PJfX6uv7P7FVVN08W8p1Ntqq0augq9vdjJxVyCgptd70kNwkxxXtJlmrmlgTPHM6PK4sb2KmLY7jrgoppYJvUcWMxFd6LgycUbM7C+3f8pMKY15NY9PIJ6pcy2tapONZuD34lxgwp4O1bq6eXRkdHC//GNqjAITiZX1hHRxXOuoRsdK870851ZxafN7j7fStfBQQfPHNVHlcPLn7ctMWVP3osjx9WWChwFB/sb95jYt1OAz3aRP/JfHb/SXq3K+y8uN2SX9dauPt/VjLzPJO1hzIVPpoTy+NX6K7ByiY7L3juq0eb4h1NHZ2ajN4GVS1V7kOYu9bMgo0msvMUGqS4Obeng74dS27oVFUyf4OFVduMHDihEGOWdGrm5tzT7DSpG36P7OtFha7llHg3mXkKvo2Xpi6OoUebih/hGAyC83o7yMnP446AueXvl1lCUvjjJwVz1pn5O93AiRyF2Bjo1MzFiN52mnrvyfYDCsu3FLpTGtdROatHcICIywVfL45BBtxGWcIt3ZhuYOZyCwdPGEi2qgzq7OTsXnYUpeRAjZP5MHNFDNv3Gzh2UiEpXqV7axfnnGYnKa7EUwDIOKLw058WMo4YyLMJGqS46d/BxbBu9rCit6WUfLfUQoG9sHPVrJ6boUXmRldsMbHtgIHVO4LncldtM6MIz/WG97TTKKXwpqzebmDhRjP7jhuQUtKivsqQrk56tg3W34MnFOatK7z/Azo5aFxHZfKCGDbtNtK6scp9oyqncXO5YO46M+t2GTl4QsFiknRo6ubsXg5aNlCDjv11jYkjWZ5GOCle5aJ+Do5lC2Yst/D3HiOqCu2burh8kN0fA5FbALP+tLBuh4k8m6BpPTcX9LWXGtCl5Z3+K93Ab+vN7D6s4HAK6iSodG/j4txeDqyxJZ7CzoMKc9Za2HHQgM0uqJ+k0q+Dk+E9y9enjekGZq2wcOC4gYQ4lf4dnVzQp/TztOpuqPoUbUJtg2wOWLjJxMptJo5mKSgCUhu6GdrNQffWwc83UHessZKLB9hZs93Ad0tjKHAIbhheEKQTG9MN/LbOzJ6jnrq3bKByVk8nXVoW1j3fDt8tKWyzu6S66NHGxeY9Bn7808Leowomoyew7NI0OzHmwvf6r/RgU7foLzPZeQr1ElVGeANnVVWyaJOZpVtMHMr0tBeNUlT6d3Iy+FRH1FaNVJnRzSlQGPV8Eos2BfvWJ86MZ+ywAibckhv09zXbDdz6biK7DhUX+Ykvrdw/Mp+HLw294Uo/orB8S2EDe3Gag78yDP6Ag+lLLDw3Jg9z8XiaCuGc04K9AxlHDLjdpXck3G7Jy9/F8+5PcdgdxZXh8UlW7r4wnydH5yGAez8s3MQiJd7Nto+OBynRiq1G7vmg8JiOzVwkxQc3wq9Oj+OjX2MJ3BHy/V+gRxsnUx7OpmERV9TEmbG8Oj2OfHtxb0JSvMrTV+Zx/VnBbvw8Gzz4sZVvlsQgZXC93gZaN3Lx7m259OtUekBRIC9+E88b3xcGFyXFq8z+T2ax46YssgR5bHx8vSjG3zmb9bSLRikudh1SuPWdRNbsKK4cL0zzRL3+946TfqOxdZ8SdP+fGp3H9GVmNu/xnN+6katSjO78DSbu/l9C0DIwH098IbnuTBvPj83BYvLc97dnxvnfh0YpKoIc7v4gIchNBzDhhzi+eewkUkqueyuJ/ceDy3/j+zieHJ3H/aOCAw7Dfaez82Hc/xL56c+SvWaJcSrPj81lzJDCd8nhhEcnWZn0W3F9eudHz73/6O6cEj0aUkqe+Sqed34M1vmPfoWebZ18+1g2KdZCndequ+HqU0VRWhtkMAimLzXz5BdWDmcV153np8K5p9l5746TJHtftUDdqZuoklsguO8jq/++DOjkpGuqm6NZglvfTWThpuJzrM9PhYv62Zh4ay4JcZLMXBH0Ht0wPJ8Zyyy893Ns0P2e9Fss78xyMfPprFLf68/nef7WrZWTEb0dbNlr4JaJCfy9p4QGfwa0beziv3ee5LQoLHOtskCq936OLWZwfXwxPzbIHf3HXybO/09KiS8ngMMpePnbeMZPKWPoVISpi2IIfJFG9rcxsl+h0p3INTBnbeVNtnsiYwtfKrcqcKul96zu+TCBN76PL9Hg+s5/64d4Xv42jrZNVLq3LnzRM/MMrNoWXLc5a4MbsksHFp/T/ujXOIpswQzAup0mrngpCVdAu3X/x1bGT7GWaHABsvMUHvg4gVe+K3xmNgec90wy0/6ILdZo+dh1yMiFzyWycGP5/cWvF1mCDK7RoDLp/pN0bKaWcVbZbN2ncObjKSU2kD4W/2XmrCdSOHC85Dq8Nj3Wb3CBSlkC9u0SM5e/lFSiwQWPvnwyN5bRryQHPUcfh7MEN7ydWMzggudduXliAle8klzM4HoQPD81nnU7C38L951WVcmVrySVanABTuYr3P1+Il8t8BwjpWTsG4l8Pq9sfRr5XBJb9xWv19ItZt75sWSdX7vDxDNfFeqWVt2Nhj5Fi9LaoMkLLdw8MalEg+tj9moLY15PQpbgHsvMFTz0qTXovhgNnqV5w55IKdHg+pi5IobLX04sUSenLIjh3Z/iSrzf2w8YeeKL0FbbHMoUXPBscskG18uOg0ZGPpfM5j2Rv6xVNtJVVUGXVCdn9XBgdwpmLLNw4ERhhSbNj+GK0+3k5Avuet8aZFz6dnBw+qkODmcZmPZHjP+3iTPjuCTNEeSSKAkpJdMCXMv1k9z07+ikdSOVx7+Q/of49aKYSlunN3edhcCXu0kdd6mj7DXbDUxZGLg43s34q/NIbehm+RYTL0yL9xvst2fFc8f5BVySZmf9rsICf11rCupxzy3SwRg1wB7kEvUguaCPnY7NXWzdZ2TWykKZN6ab+GqBhevOsjN7tcnfkwTPMqzLB9lp3cjFul0mfllV2HC+8m08Q7o66NPexfNT49mYXihjHaubK063kRQPs1eb2bDb85vLrXDzO0msefs4caW8r0s3G4N6xQBv35rL6aeWPEK+bKCdLqkuFm4yM3t1oXyXptno3d5zTssGLq57K5msvMIGun0TFxf1t2F3Cr79I8Zv1A5mGrj7gwS+e/xksWsFBq0AmAyhjWB2HTTy/NTSO5bLtpSsMPuPCx76JCGocRrcxUFaZwf7jhuYtsjil2nRJjPv/hTLvSODR6VSChQhuXxQAakNVTalG4Pu0+7Dnqako3dqI88mmLY4JuBeCf+UjZZ3et9RwYp/Ch/20G52nrk6n8RYldmrzTw+yYpPF8dPtjJ6kJ0vF8R63ysP8TEql6TZqZeo8vOfFrbu98icU6Dw9JdW3rwlJ6jOqipolKIysr+NOItk4SYzawOM4zdLYnj5+lziLGjS3XiL5I7/JkasT9GipDbIpcIzXxZ2LhRF8tToPPp1dJJ+2MAzk+P9buRlm83M32DmzO7B75iqCtQi/VyTQfLAxwnsO1bY5qc2cHNhfxsul+D7ZTF+F+/KrWY+mRvD+X2DR+I2p0KdBJVLB9qwxkiWbjYFLY2atcLCVw9m0yXVxZy1Zn7fUKgLY4YU0CXVRb1Eybs/xnEip/AZjLsgn+vOKsDpErw9M87v6cq3K7z4TTxfPRjZM6gyo3tWdztTHs72uzjvOK+AHnfXweH0fF/nNRDfLrGw92ihmJem2fhg3EmEd57tkgF2Lnou2fur4LN5Mbx5U7BruijLtpjIOFr4sC/o65mTbFxHpW8Hp//lnrfOzNEsEdUIvrwCyAqYKj6abWDhRhMvfRMfdNyIMhJ0rN1poo610M3xxOg8f0KIvh1cbNlr5Fvv3IfDKVi1zcSo/jae/ire3/D+utrC+Ks9rrtdhxS2Hyi8x73aOmnVsPho8M2bcoKSQ0z6zcl9HxUatq8XxXDdWXbenhlsGD6//yTn+etTwFsz4nhuamF935oRx4fjcvgkwFAnxavMfynLP8/44MV5XPFKEvPXe16c4ycVvpgfw23nFh+R7zigMPb1RJyuwgbk4UvzuPKM0hMIDDrVyaBTneTZRJAxGXiKk7HDPNdYsMEUtH63V1snP43P9Ltj7zq/gDMeSfE3lL9vsASN7gIZO6yAq4fYqJ+k4g7RY5V+xBC0RjxUPp0bGzRCvfXcfF66rlAJRw+yce4zyfga3Imz4rjz/OJrzz+6+yQj+xfq5Q0TEvhheWHntWdbJz8H3I9zejkY9Xyy//eNu7W/0/USgvXxiSvy6OJNSnPbCBu/bzDz+0bPe5uVJ9h5SOG9n4I7frOezvIHRz50SR7DHk/xexzmbzSTU8TD3zjFzeJXM/1rVh+/PI/Bj9bxJ8dxOAWb9xjo0FTVpLuntHBr0qcW9bV7aiC8Nmj7Ac+1fe3NiN4O7rnIoxt9O7iwO4Ndvks2m4oZXYDm9V08OTqP7q09A6KcfMHPAZ3vNo1c/P5SFglxnnt970X59Hugjt8YfvpbbDGjWydBZdErJ/yxKwDDHi9MauNWBcnxkrN72TicpQQZ3WHdHVzUz6PLH80p1OH4GJVnxxTenAm35PDzKjO5Ns8zWbM9cpNZZUa3d3tn0Jxi4zoq7Zu4/QptdwhO5sOMFcHupMeuyPO/nOBpLFs3cvndVMv+Ln8SdurC4LW5FwWMZkf1t/uNrlsVfLs0hjvOi17mrItfSCn3mDoJKg9cXHoQ183n2Lj5nNKXNHVoFjzSP5at0KS7pH8nJ8s2e+q27YCRXYcUWjdSi7mWL0krueyio/6xwwp4+ds4v9tp/W4TGYcFf24rfAbdWjkDDK6H20bk897Psf4XasEmMz+tMgWNfMYMsQUF9iiK4PHL8/0NF8Cvay3FjK7NIbjm9SR/FCbA6NNtPHpZ5HOmM4ssL3vg4jx/AwlQL0ly24h8nplc2AjNWWuhX4fg+p97mq1YzEJFMivgHTIosljsQ9+OLob3cPhHhVl5Ciu3Fm8aBp0S3Jj2be8MMrqXpNmD7kef9sHHZ+Z4ftPyThddI/35bzG0bZzvb6S/eSx49LHrkBLkuh7a1RG0GsFiEowZYmP8lMJjDp4I9kC0a+oOShKhKIK0zo6gjHRHswzsPmzQpLs7Dgb3tkLVp5vPjqw9CqcNapgs2fHJiVKPK9rWnMgueTrpywdPBgVOBU4rAdwzsvBZgqfu5/W28eXvnuO27zdy/GRw2R2bu4IMLkC/Do6gjszxnPJnUK0xgfPyCp/Ps3DNUBsGg8BkhPTPjpdbRjhUefRyIPExwT04p0uwZU+hiEaDyoezi0+KF9gLFXXP0bJvcr4dZq4sbCjqJbkZ0MmBr5d/YT87j35eOP/w9UJLVI1ueTSt6+bLB4sHJZWEzQFz1ppZutnMrkMKJ/MVnC44khV8D3zxWJem2fxGFzwv8O0jCpizJjgZxKgQ87gKITg11cXh9R4D53QJVm4zEeii6tOheK831gI92zj5zdsIOZyCVduDO0tFG2zwLN+JNav+ZV5b9xVX3/QjwSPLVg1dvH1rTrHjtLBtf3DZfdoXn8YYUCRIZus+A/06BB/TpI42z0ndRJVebUoPINt50MDOInOkLhfsOlwod4dmrqDgHx8DOjmDXLEl3duixJazCrDo705vm6vlnb6gn50Xvon3ey++/D2O75bE0KeDi34dnZxxipM+HRz+KPqiz6pTCVNOt42wcduIQmO+P4Q50/giOQgcbo9BCCRU3S3qcg1Vnyqa0tqgZZuNzNtgZuteI5m5AptDkF8kpsRdynx20zrBld1SZG508SYzf2cE38fNReZYQ3k+pelcWVw60O5viwDu/ziRF76xktbJs5JmWDcH7ZtGb/lotTK6RXG6JCdyCm+0y63wweyyg6VsTo/hKS2H6KwVFr+rAKBHKxdrdwU/3PZN3P75nr/3mNiw20C3VhW3mloISafmLi4Z4ODGs/NJDCEe7I+/TNzx34RSAldK5sK+Dh7+VMXl9rz4v642MWawjeX/FNZ/0CnOkAy+j6S44GP3HQ2Wp35iya6wxnWC7+eB48EdhfqlpKFrXEdl1yHPsUV7viWx+7CRJX+bykyfGCpHAzoziiKpk1BcxsZFGpejIcgYKt1aOZn6aOnzSS9/G8er3wUr/tGTStBcbr1S7mujCpQ7EKcLTe90s7oqH407yR3/TfAH5xU4FBZtMrNok5lXvvV0sJ4cnc+oAXay84LlTyplKVE0OJKtTXeT46pWnwIpqw3ad0xw44REVm2PXmDp4SIDg++WxpRyZCG5toqp++WD7Gzem8fEmYXu9eMnFWatjGHWSngCGNDZwfPX5BZbGqWFam10PYQfsedWoTQnc9G0j/PWW5i3vuwu+9eLYujWKjprdj8Yl80pLTwPTgiIs0jqJ6nEhZE7ZOs+hctfSfK7tISQnNnNQdfWLhJjVZb8bS6xTnUSJEO7Fo5olv9j4ocVlqC5z0vSwkvob3cGP5+iGyKUFr2suoPPMxfpO+SXMqXtDjjPZAytc3D3Bwksef1EmeuCQ8EYIKOqCuxOGeQOBIpFnFtClLGiKBqkVVDK43UX6RtZNLQMJa3rLhlt7/SF/Rz0aJPJf3+O5ftlFo5mByvN7sNGbnw7keMnc6iXpBY5v+Keg7HIPQ5Vd6tKn8Jpg2wOuPj5ZHYcLFSIrqlOBnd1UCdBsv+44l3VUPEU1dFoMv6qfM7r7eB/P8cyZ425WNKkZZvNnD8+mZlPZUW8O161NromoyA5XvVH91nMkr/eOx6UwqwkStt+bt8xwR8hzPkW5bslMTw3Ji8qO3CkNlTp3CKyh/ZekbW5r92Qyw3DC91kblWU2pG4OM3uN7out8IL0wpfGJNRckHf8NJfHjsZ3Ci0bBBct/3HSza6u4uMiJsXOc8T1Rg8OnU4Yf+Jwus1TC75LWzfxEWnFi5mrojxymDgyc+tvHNHZPOoDVNUtu4PlrFN42AZMo4E1zccr0FFkGJVMRmlv2MVGC0aSEYRt3z9ZDeld121YzIS0TvdvL7KS9fl8eK1ufyzz8jSv018u8QSNAr7z9dWPr03K+j8I9kV55ZtVEQPQ9XdqtKncNqgmSssQQZ31AAbn9xTOF2zartRk9Et6nH55rEs+pUwFRVIZm7FLpnq3c5F73tzcLpg7Q4ji/4yM2WhhT3eoL98u8KzU6zMeiY7outU+w0PAudH7A7B7DVmrLEU+xzMVDAbKTUjDcC0xcUXrYfCiRyFucWWz1Qdm4pkV7l8UOiGcsRpdmLNhS/2kYC1d2d2t/sXt5dEQZEefHY+bAzY7jEl3pPpKXAEOnedmbwi4h3N8kRU+6if5GZ4j+AX7oflxTsNv603+13jgH8pTyB1ElRmPpPFmzfnUj+psGGZvCiWOWsjMyJFrzdzRXEZf1kd/LeSZKxMDAZBz4DEDwczDSUGSf26Oli/S5pfjBZa3uknv4jnoU+sPPSJlc/mxSCEoFNzNzedY2PO89lc0KdQyXJtAovJ47L1sXxL8Tq/MyuGRmPq+T+7D2kzzL2L3KtQdbcm6FPRtuayEtbva6FP++DGZPoSS4k64JaeaHRrLChRtFY+r8zeo4pfrx76xMqiTSZMRk9w4cOX5rPktUya1y98vmt3Rj7yqvZGt2jU4qOfWZm6yOJfhO10wfSlZs59OoXb/5tQ4uJsH9OKuJa/fyKTI5OPlvh55frg4JspC6tP7uiiyRRWbC00JrsPK3z5e3A9A2+JNRbO7lWy/+uStLLXJD/0SYK/t5lvh4c/SQhywwzt5iTWAhf2KfRhZucpPPxpAvneP53IEdz2XkKQS/vKM2ykdXLSrF6hkVy4ycwnc2L8z3PLXgOPfh682H10CfvmNkhSaZgsSbFKXr4ueErg3g8SIuotXz7ITmDygHd+jGNFwNrYH1ea+WRuYa8v1qxyYd/w3PUVwRWDggMBH/nUyr5jnvvgcsGzX8cFrTHt2dapKXAkVPeylnd68V+ee/vJ3FhemBrH4azg51i0s52cAGd1L9Tnv/eYePnbOH+Wt817DLz3cxwOp8DhFFiMkqZ1tXU0tOpuTdCnoq7zwLYmt8Cz3C+QUHXgkjQ75gDvxrQ/Yhk/Jc7fTgD8uc3Ihc8mc8mLyUFxAFooOl2yapvnD/Exkk/nxfh169XpcUGZAGNMwVNf0fB2Vmv3MnjW0A7u4vBnLcm3K9zx30Qe+NhK4zoqhzIV/7zhjGUxdEt1cfdFxaONV241BrlJ6iW5GXSKs9R8mhf1s/PYJCuqd05l3jozx0rZCLqyGXiKI2iR/lWvJpLW2YXTDX9uNQb1qIFiWYQuTbMHLfUAT+T4Ob3KfqHnrLXQ6TYzzeq6g+67B8ktIzz3/ZHL8vh1rZk8b+DD14ti+GG5mSZ1VPYeN/jXYoMnveC4CwowGuGZq3K5eWKS/7eHPk3gpW/iSIzzpO0MnAsc0tXOWT0cJWaq8TFqgJ1vl9j5dY2nw3Q4y8Cjn1n5YJy2aOZ2Tdxce6aNSb95GsLsPIUR45NpVs+N00WxjD0PXlxQLfYlvXKwjU/mxvoz7mxMN9F9XF1SG7g5dlIJ0g9FkTw3pmKXM2l5p285N5+73/fkBT6Ra2DQwymM7OegToLKpnQDs1cX6nNqAzenNHfyyGV5zN9g8r8Pr34XzzuzYqmXpLLvmCHI63XLuQWYTdreb626C2jSp+MnK68dGniKk4mzCr9PnBnP4k1m6iaqrN5uKhawlp0fmmxN6koeHJXHi98UdkYmzoznvR/jaF5P5WS+5zn7uO3dBN66RfsqhNaNgxuK//0Sz5e/xxEfo3L5QBvT/vA8g+VbzJzxaApndndgNMD89eagFQHn9Y6801PtR7pCCD659yT9OwWPwgocnnV4gQ1/h6YuRp9RsvsjcHMDgPP7lJ3AukGyZEDHQleOy63wbQgRdpXB3RcUkBowB+pye6I4l232uLASYovOMQU/5jO7O4rlVR5xmqPMYK46CSrJ8SoOpyh23wHuvijfv3NJ2yYqn9yTE+TGLnAo7DxkDDK4dRNVJj+U7TdMl6Q5eOSy4NHpiVyDdxlQ4XndWzv5METD+dqNOUH349slMfwcwV6aL12by5ndg1+8fccMxRrIMYMLuHdk9dgS0GISfPHgyaCtOVXV8xyLGty3bs6lfydtI76yvEyBaHmnxwyxc8PwwvXFx7INfDwnlle/iw8yuIlxKh/cfRJFEXRv7eatW3KD3MwFDoW9R41BBndoNzuPXBLZOm6tulvd9enM7k5GFDE063eZmL/eQnZe+W1NWTxwcT63nBt8392qIP2IIcjgJsap3D8ysmWbw3s4qVtkJUWuTVDgELx6Qx692ha29Zv3mJg4K543Z8T7M4mBJ9vas1dH/gyqvdEFSLFKZj6ZzavX59C2cfEGoWV9N09ckcvCV074dzsJxOYoPl8SmGe5NC4ukiTi64XVw+jWSZDMfi6TC/vaEKKwvgbFs+H6L89mEei2mlckxaPZBBcUeZGK1rUonZu7mPV0Fj3bBs8p1U1UefHaHMZfFfzyDO/pYMHLWVzQxxbkRgLPqPqqwQUsfPlEsUTzj1yazzePZdG7nSOoDuBJd/nIZXn8ND4r5BFk07qSp68MflHu+8iqebQQY4avH87mletzgjo+Pjo2c/H+XSeZeHtuUMKHqqZVQ5V5L2Rxx3n5pMQHy60okjO6OJj9nyyuGVox+0gXRcs7/fqNeUy6P9urg8HPP9ascsWgAha9khm0bd3Vg+388mwWg06xBxlf3zWeuyaXaY9kY4yCz0+L7tYEffr0npPcMzKvWB6Fvh2czH0+M0juTenGkHNECyF4+bo8pj2aTb+OjmLPJzleZeywAla+dSLkDU5KIyFOMvXhrGK6ZlQkCXGSX57NYvxVuSU+gwbJbu4flcfc5zOj4rny353X74xp+eB7tvQx5ybw2fjGERdckRw8obDvuIKqetaxRZoWrSaTmSvYtt+AEJ5t1soKhArk3g+tfDHf41JJiXfzz4cnQp6vSD+icPC4QlK8pENTV7lbXuXbYcdBA7n5gqR4SbsmpeeVDuT4SUHGEY87ul6SmzaN3dXKkIEnccPBEwqKAs3qqsXWVVZHVFWy/YCB4ycVYi2S1o3dES+nipRw3+njJwV7jirk2wUpVo9Olae/WXmw+5ARu0PQsI67xFSn0UKr7lZnfbI7JZv3GLE5BC0auItlg4oUz/MxYHMI6iVJUhuU/0zDRUrJ9gNGjmYL4mMk7Zu6i3n49hxVOJSpoLoj05Pe12Swfpudrh1ovXEru31/r/ZzuiXRuE71UsaqJMUq6dshPHfgsWzB9wGu8gv6OcJS7tQGKqn+NHflNyRxFkrdT7Us6iZK6iYG1q16GVyAFvVrXqdPUQQdmqlA9ZE73Hfaoxvh6VRyPCVu4VcRaNXd6qxPFpMISqUZbTzPp+LKB8/oun1TN+2bln5MRT+DGml0dbQxc4WZgycUJv0WG5SV68rTK8elqKOjo/NvRze6/yLuKWED8iFd7fTtWDm9fx0dHZ1/OzUikEqnYmjTKHqbAejo6OjolE+xkW7VryrUqSguTrOzZY+B+BhJWicX1w/PDznwSkdHR0cndNRS8n37ja7BpDgAdh+o2rR1OhXHmzdV3h6uOjo6Ov9mduzz2FJXHkHJmv3u5bjk/GyAv3aUnQpQR0dHR0dHp3S2ZjjIt0nqJRvk5n2cCPzNb3RvHU9+51Zmx8k8lcfePVr5Uuro6Ojo6NQC7n7tCAB9T7XsLvpbUCDV2f3j/gfw+peZ/Oej45UinI6Ojo6OTm0gK8fNdeMP8vsqT4a+Ib1ibit6TLEV21cOt67+em5uL4BWTUxcPNTKoB6xWGP1QGcdHR0dHZ2iHM1yM//PfGYsyOF4tiexxl2XJ73/7jfZt4dUwLjLE9+ul2xQ8QQz6x/9o3/0j/7RP/onhE/b5ibHQ2Pr3EQplJqb7IYLabJtb8xz+w+7B6n6el4dHR0dHZ1SMRmwt2lmmj5nef7TVS2Ljo6Ojo6Ojo6Ojo6Ojk7l8X/VmVTDhEJYDAAAAABJRU5ErkJggg==" alt="Skip School — The AI Playbook for Homeschool Parents" class="logo-img">
            </div>

            <div class="stars">
                <span class="star">★</span>
                <span class="star">★</span>
                <span class="star">★</span>
                <span class="star">★</span>
                <span class="star">★</span>
            </div>

            <h1>The Free Weekly Newsletter That Teaches You to <span class="highlight">Homeschool Smarter with AI</span></h1>

            <p class="description">
                Every week, get the exact AI tools, prompts, and strategies real homeschool parents are using right now. No jargon. No fluff. Just <u>practical stuff</u> you can try with your kids <strong>this week</strong>.
            </p>

            <p class="frequency">
                <strong>One email per week.</strong> Five minutes to read. Written by parents who actually use this stuff every day.
            </p>

            <div class="form-row">
                <input type="email" class="email-input" placeholder="Enter your email" aria-label="Email address">
                <button class="cta-btn">Subscribe Free</button>
            </div>

            <div class="social-proof">
                <div class="avatars">
                    <img class="avatar" src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAASABIAAD/4QCARXhpZgAATU0AKgAAAAgABQESAAMAAAABAAEAAAEaAAUAAAABAAAASgEbAAUAAAABAAAAUgEoAAMAAAABAAIAAIdpAAQAAAABAAAAWgAAAAAAAABIAAAAAQAAAEgAAAABAAKgAgAEAAAAAQAAAEigAwAEAAAAAQAAAEgAAAAA/+0AOFBob3Rvc2hvcCAzLjAAOEJJTQQEAAAAAAAAOEJJTQQlAAAAAAAQ1B2M2Y8AsgTpgAmY7PhCfv/iAqBJQ0NfUFJPRklMRQABAQAAApBsY21zBDAAAG1udHJSR0IgWFlaIAffAAgAEwASABYAMWFjc3BBUFBMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD21gABAAAAANMtbGNtcwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAC2Rlc2MAAAEIAAAAOGNwcnQAAAFAAAAATnd0cHQAAAGQAAAAFGNoYWQAAAGkAAAALHJYWVoAAAHQAAAAFGJYWVoAAAHkAAAAFGdYWVoAAAH4AAAAFHJUUkMAAAIMAAAAIGdUUkMAAAIsAAAAIGJUUkMAAAJMAAAAIGNocm0AAAJsAAAAJG1sdWMAAAAAAAAAAQAAAAxlblVTAAAAHAAAABwAcwBSAEcAQgAgAGIAdQBpAGwAdAAtAGkAbgAAbWx1YwAAAAAAAAABAAAADGVuVVMAAAAyAAAAHABOAG8AIABjAG8AcAB5AHIAaQBnAGgAdAAsACAAdQBzAGUAIABmAHIAZQBlAGwAeQAAAABYWVogAAAAAAAA9tYAAQAAAADTLXNmMzIAAAAAAAEMSgAABeP///MqAAAHmwAA/Yf///ui///9owAAA9gAAMCUWFlaIAAAAAAAAG+UAAA47gAAA5BYWVogAAAAAAAAJJ0AAA+DAAC2vlhZWiAAAAAAAABipQAAt5AAABjecGFyYQAAAAAAAwAAAAJmZgAA8qcAAA1ZAAAT0AAACltwYXJhAAAAAAADAAAAAmZmAADypwAADVkAABPQAAAKW3BhcmEAAAAAAAMAAAACZmYAAPKnAAANWQAAE9AAAApbY2hybQAAAAAAAwAAAACj1wAAVHsAAEzNAACZmgAAJmYAAA9c/8AAEQgASABIAwESAAIRAQMRAf/EAB8AAAEFAQEBAQEBAAAAAAAAAAABAgMEBQYHCAkKC//EALUQAAIBAwMCBAMFBQQEAAABfQECAwAEEQUSITFBBhNRYQcicRQygZGhCCNCscEVUtHwJDNicoIJChYXGBkaJSYnKCkqNDU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6g4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2drh4uPk5ebn6Onq8fLz9PX29/j5+v/EAB8BAAMBAQEBAQEBAQEAAAAAAAABAgMEBQYHCAkKC//EALURAAIBAgQEAwQHBQQEAAECdwABAgMRBAUhMQYSQVEHYXETIjKBCBRCkaGxwQkjM1LwFWJy0QoWJDThJfEXGBkaJicoKSo1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoKDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uLj5OXm5+jp6vLz9PX29/j5+v/bAEMACAYGBwYFCAcHBwkJCAoMFA0MCwsMGRITDxQdGh8eHRocHCAkLicgIiwjHBwoNyksMDE0NDQfJzk9ODI8LjM0Mv/bAEMBCQkJDAsMGA0NGDIhHCEyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMv/dAAQACf/aAAwDAQACEQMRAD8A9iFFUQOFApgKWVFLMQFAySe1cb4l1wyTmwtz+7Q4kYfxN6fhWU6qiaQpuRsXHiKIS+Xbpv8ARj3+grlbOdIvmyGk9Oy/4n2rF1mzVUUdFqms31tY+bCFEzf6uMJuZz6AZ/Wl02JpP3lwu5n7H09/8KaqMTp+RQ0XW/FM6LPfaZE1ux4EeRIR6hemPfIrtItvlgDk46CrU2iXBFaK8gmkMSyL5qjLRk4YfUVkX0dymtxXUSxmJF2lB95iSOSewAzxzk/Smqncl09DdzSBgwyDkHpWpmLSUxH/0PYaSqIFkfZGz/3QTVe/Yrpt0w6iFz+lDdkEVdnlFxcvNcsFJ3OxyR1JJrIu7u6WQw6eFN2yZUt0QdvxrzpPU9GMdNDp7W4t7SUIXj83pgtkj8K4m0ttQbUIxcpF5zOqh0Qqxyeh9aT0NIxvuesWOr2/nCKV0Gem+TGfwrmPF2l3em3NtJaWUUz+WOZF43e5waaumDjF7HqkFynkBg6lDxhDx+J7VkeFWnvNGQXNnawvgfNbSFlbjvkAg5+tbJ6HPKBfuLkPGPKAw467cevPsK5ew1sXmq6to7Exz2NwAv8AtRgqf8/Wghqx2CDy0CegxSM2W611Q2OWb1H7qjzVEn//0fXwaQGqMxXUSIyMMqwII9qBSHc8X1ewl0DxHcB1JU48tsdVyf8AEV6V4t0E65pRWED7XCd8RPf1X8a5qlHrE7KFe2kjy2z1Jf7dtrmZWMQkGBjgc96zfssUer+bcQSvFJw6K7KUYdcY6H1+lYJHeve9D1bxPqjXWmRXVhvYKf3isnDLjqDVX7AdV0RYtO86xibHzeazSPjtzwF9e/0qpJtakpKDOo8JXcV1oscseMOM8VHodgul6cLWE7SqkAkZwT3q6d7WMK7V7nOaDpkNx4w1LV7eZZoXkdXdSCpfIBGR1I24Ppiur03TLXSdPjs7SMJEmTwOWYnLMfUkkk/Wt40rO7OOpW5lZFjvTsVsc9gFGKAP/9L10His6/1i00/5ZXLS9RGgy3/1qJSjHdijCUtkaQNefeKviJLo2i3Fza2iLLjbEZTnLngcD86UakZO0SpUpRV2d/LPFbxNJNIkcajJd2CgD6mvk2bW9V8Q63ay6nez3sjSoMSNkYBHRRwOnpWslyxbZnFczSPXfE1/pUXiZ57JxPBKA8xTlQ/qv1GCfeuee1kacNtbBPcV5k6l3dI9WlFwVrnqvhrVLa+tljtgVUcF3GD+ArG8MQy27Iqr8vU1EZu5pOKauehrEqRkL3FRG5WOIM5xxk10J2ehyyTejFrwjxH431K48S3eoadez20K4iiWN8Aqp6kdDk5P5V6lLDTnDmloeXUqxjLlWp7vWD4R1WfVPC2n3l5IXnljy7kAbuTzxWE7QlyN6msFKceZI3TRkEZFJNPYbTW6P//TuW0z3LPPO5aRzuYnuaisv9TXmvXVnqRSWiOJ+Jd8HksLFPu5aVv5D+Z/Ks74hf8AIetf+uH9a78FFcrl1OLGPWxkeFRjxRpeTjM/X6ggUeGv+Rl0n/r4T+ddlaK9mzkoyfOj3m1tWRwWUEe4q+nQfWvEaPa6F61i2DKAD6VLb9KEZ3ZyXj/xNLo+mfY7ebbd3alFI6ovc/0+prlfir/yHtO/64v/AOhCvTwNGM53kcOMqyhD3ThpTgeWOgAGPpSS/wCtb/PrXuT00PIj3PbPA94YvBulKx4NupFVPCP/ACJ+j/8AXqn8q+axraxEj6GhFezR6PpTpcKQx61X0H71TS1ZNXRH/9k=" alt="">
                    <img class="avatar" src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAASABIAAD/4QCARXhpZgAATU0AKgAAAAgABQESAAMAAAABAAEAAAEaAAUAAAABAAAASgEbAAUAAAABAAAAUgEoAAMAAAABAAIAAIdpAAQAAAABAAAAWgAAAAAAAABIAAAAAQAAAEgAAAABAAKgAgAEAAAAAQAAAEigAwAEAAAAAQAAAEgAAAAA/+0AOFBob3Rvc2hvcCAzLjAAOEJJTQQEAAAAAAAAOEJJTQQlAAAAAAAQ1B2M2Y8AsgTpgAmY7PhCfv/iAqBJQ0NfUFJPRklMRQABAQAAApBsY21zBDAAAG1udHJSR0IgWFlaIAffAAEABwAOAAkAAmFjc3BBUFBMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD21gABAAAAANMtbGNtcwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAC2Rlc2MAAAEIAAAAOGNwcnQAAAFAAAAATnd0cHQAAAGQAAAAFGNoYWQAAAGkAAAALHJYWVoAAAHQAAAAFGJYWVoAAAHkAAAAFGdYWVoAAAH4AAAAFHJUUkMAAAIMAAAAIGdUUkMAAAIsAAAAIGJUUkMAAAJMAAAAIGNocm0AAAJsAAAAJG1sdWMAAAAAAAAAAQAAAAxlblVTAAAAHAAAABwAcwBSAEcAQgAgAGIAdQBpAGwAdAAtAGkAbgAAbWx1YwAAAAAAAAABAAAADGVuVVMAAAAyAAAAHABOAG8AIABjAG8AcAB5AHIAaQBnAGgAdAAsACAAdQBzAGUAIABmAHIAZQBlAGwAeQAAAABYWVogAAAAAAAA9tYAAQAAAADTLXNmMzIAAAAAAAEMSgAABeP///MqAAAHmwAA/Yf///ui///9owAAA9gAAMCUWFlaIAAAAAAAAG+UAAA47gAAA5BYWVogAAAAAAAAJJ0AAA+DAAC2vlhZWiAAAAAAAABipQAAt5AAABjecGFyYQAAAAAAAwAAAAJmZgAA8qcAAA1ZAAAT0AAACltwYXJhAAAAAAADAAAAAmZmAADypwAADVkAABPQAAAKW3BhcmEAAAAAAAMAAAACZmYAAPKnAAANWQAAE9AAAApbY2hybQAAAAAAAwAAAACj1wAAVHsAAEzNAACZmgAAJmYAAA9c/8AAEQgASABIAwESAAIRAQMRAf/EAB8AAAEFAQEBAQEBAAAAAAAAAAABAgMEBQYHCAkKC//EALUQAAIBAwMCBAMFBQQEAAABfQECAwAEEQUSITFBBhNRYQcicRQygZGhCCNCscEVUtHwJDNicoIJChYXGBkaJSYnKCkqNDU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6g4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2drh4uPk5ebn6Onq8fLz9PX29/j5+v/EAB8BAAMBAQEBAQEBAQEAAAAAAAABAgMEBQYHCAkKC//EALURAAIBAgQEAwQHBQQEAAECdwABAgMRBAUhMQYSQVEHYXETIjKBCBRCkaGxwQkjM1LwFWJy0QoWJDThJfEXGBkaJicoKSo1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoKDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uLj5OXm5+jp6vLz9PX29/j5+v/bAEMACAYGBwYFCAcHBwkJCAoMFA0MCwsMGRITDxQdGh8eHRocHCAkLicgIiwjHBwoNyksMDE0NDQfJzk9ODI8LjM0Mv/bAEMBCQkJDAsMGA0NGDIhHCEyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMv/dAAQACf/aAAwDAQACEQMRAD8A9H5oJrQAzThgigBMU9RyKQA0sdvC8srqkaDczscACuOuZZ/F3jlNEwRo1hF590o/5bsTtUH2JDcex9qlyLULk8vjG41FM+HrNruEtt8/y2IPuoA5Hvmu/hRIEWOKJI0UYCoMAD0Aqbtl8qR5ymt+Ii7GWxvkx1Xy1A98Z7V6BfoJ4G4AqXddSkk+hxB8RahbgC5ijBxuJbAwPfBrnvF2mzx3q3KTFR6E9R9O9TzsbgjstO1yz1iEG3bbIPvxnqP8a8xi1K50ua2nRV8suv76M5XGec46cZqlUfUhw7Hqrt15pVkhuIRLCwdGGQw71qZPQ//Q9Gwc8Um7FagTKvFIrZFAA7bEZj0ArN8RXLW2iTupIJGOKibsioq7OAsfEM9nqmpmw89Z1xJM8aK6tEmQARjcTlj09a2fh0dNXTNUuriPfMl1mU43FV2rjH5k/nXOjoSe502p6pqcWl2d5aSpEJoRM3mx7sLjPTIxWhb6xp2q3LLE6yxcoVI5XHqO1PR7MrVbowNP8bQXV0dLvZil+pwY5IfLJP8As44P0PNbstlodrN9qktYpLhQcSOMkfTNN2JVzifiLHKulCeMjGQCCM/jVnxBqlvqebFUVlYj6CsnJGvIzymO7ntrR5ZCWhl6h1xk4610XjOGLT/ClvbNGIrqeZdsQPIVWyWPcccfU1S1M5x5UeladEtvpttFHIrosKgMpyDx61wfgbWZlurbRy0jRPAXUSD7uB1Ht+lawmtjGUep/9H0TktQTWoyVSAKiD0tQM7Xx52lzr2Uce7HgCo9ZDyQSLHksqsyD1fHH9aznsXBanFeFLv7Br2rWMDJmeNvLEmduVbnp7N+lZVtdf2VevqIUPPb/Ogbof7w/EZH41zXudC0PTNKvbhCUew09gw2vJaysWVe2dyjP51zmnfErTdRuVsIbN4rqTIUMoAJAyQGHB/+tVpaDc4vQ39TiM2cSEL9ayJpru7YhjsB7LUPUuLsY9/cNpUqzWaJI8b7mD9G7Yz265z7VfvLe1hREmeAPteYCdyqsVGcEjkD35+lEIakzqNI891u9bUIUu7sqt35pLIh+VQB8qgnk45yfXmq9zas97JFaeUwmndhbxEt5YLEjBPt+grRmO50fgJnTWJZbokym3Kx7+qgkH8OgqSxgXSEwGk8+Zf4jkrUqVncbjdH/9L0HOablR3rQBc80m4ZoArXsgjTLdAQx9gD1qDWED2bjP3lxWdTRFwPM9YhZxIdg8uQkYBwTk54+lT6tdSXV4ixL9yMbtv8J9K5djoWpxF3L5cpngKwS2z7olU52kc9atx26S6sJWG+FJcy8cHJ6e9bRhKSujNyinqesJdk6fDc4AaSNXx6ZGaYJYbyyR7eVGQpsUA4K/Udqiaa3RrFrozkZ2vNWvrm52qyQqcA4zjpgZ6nk8DmtJRDYusTzNGFzhY+59z1zUxuErPcy7q0RLRZoCsdwjBmdeCCO1XAiTsFWHei/M2/pj61SjJk8yKWm8yhp38xmIY7egJPP4Cr10AFyi+URwrKvStFh5taIh1orQ//0+0Lg96i71oMnV/eo16UgIr1TOEiGMMTkn6fzp7/AOuh/wB6paGjz3WFtrKW+8p/MHmKxHbAIDD6VU1v/WX/ANZP/Qqx5VzWNeZqJTsbfcmR8mPQY5PJ/IYqzZf6k/739BXsUYRtscE5O5ceJIIFx80uQMY6Cnz/AOsb6j+VYzXtG+bobQ91aEc+zaCAJGQ/Oc/dPqRTP4tR/wCuhrGFNS3LbZcW4ZUERQMjKOVPIPvUMfX/AIEP61tRhFvYyqTZLKu+PZ5pVAc9OntSS/6t67LLY5vM/9k=" alt="">
                    <img class="avatar" src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAASABIAAD/4QCARXhpZgAATU0AKgAAAAgABQESAAMAAAABAAEAAAEaAAUAAAABAAAASgEbAAUAAAABAAAAUgEoAAMAAAABAAIAAIdpAAQAAAABAAAAWgAAAAAAAABIAAAAAQAAAEgAAAABAAKgAgAEAAAAAQAAAEigAwAEAAAAAQAAAEgAAAAA/+0AOFBob3Rvc2hvcCAzLjAAOEJJTQQEAAAAAAAAOEJJTQQlAAAAAAAQ1B2M2Y8AsgTpgAmY7PhCfv/iAqBJQ0NfUFJPRklMRQABAQAAApBsY21zBDAAAG1udHJSR0IgWFlaIAfeAAUAHQATABYANGFjc3BBUFBMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD21gABAAAAANMtbGNtcwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAC2Rlc2MAAAEIAAAAOGNwcnQAAAFAAAAATnd0cHQAAAGQAAAAFGNoYWQAAAGkAAAALHJYWVoAAAHQAAAAFGJYWVoAAAHkAAAAFGdYWVoAAAH4AAAAFHJUUkMAAAIMAAAAIGdUUkMAAAIsAAAAIGJUUkMAAAJMAAAAIGNocm0AAAJsAAAAJG1sdWMAAAAAAAAAAQAAAAxlblVTAAAAHAAAABwAcwBSAEcAQgAgAGIAdQBpAGwAdAAtAGkAbgAAbWx1YwAAAAAAAAABAAAADGVuVVMAAAAyAAAAHABOAG8AIABjAG8AcAB5AHIAaQBnAGgAdAAsACAAdQBzAGUAIABmAHIAZQBlAGwAeQAAAABYWVogAAAAAAAA9tYAAQAAAADTLXNmMzIAAAAAAAEMSgAABeP///MqAAAHmwAA/Yf///ui///9owAAA9gAAMCUWFlaIAAAAAAAAG+UAAA47gAAA5BYWVogAAAAAAAAJJ0AAA+DAAC2vlhZWiAAAAAAAABipQAAt5AAABjecGFyYQAAAAAAAwAAAAJmZgAA8qcAAA1ZAAAT0AAACltwYXJhAAAAAAADAAAAAmZmAADypwAADVkAABPQAAAKW3BhcmEAAAAAAAMAAAACZmYAAPKnAAANWQAAE9AAAApbY2hybQAAAAAAAwAAAACj1wAAVHsAAEzNAACZmgAAJmYAAA9c/8AAEQgASABIAwESAAIRAQMRAf/EAB8AAAEFAQEBAQEBAAAAAAAAAAABAgMEBQYHCAkKC//EALUQAAIBAwMCBAMFBQQEAAABfQECAwAEEQUSITFBBhNRYQcicRQygZGhCCNCscEVUtHwJDNicoIJChYXGBkaJSYnKCkqNDU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6g4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2drh4uPk5ebn6Onq8fLz9PX29/j5+v/EAB8BAAMBAQEBAQEBAQEAAAAAAAABAgMEBQYHCAkKC//EALURAAIBAgQEAwQHBQQEAAECdwABAgMRBAUhMQYSQVEHYXETIjKBCBRCkaGxwQkjM1LwFWJy0QoWJDThJfEXGBkaJicoKSo1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoKDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uLj5OXm5+jp6vLz9PX29/j5+v/bAEMABQMEBAQDBQQEBAUFBQYHDAgHBwcHDwsLCQwRDxISEQ8RERMWHBcTFBoVEREYIRgaHR0fHx8TFyIkIh4kHB4fHv/bAEMBBQUFBwYHDggIDh4UERQeHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHv/dAAQACf/aAAwDAQACEQMRAD8A8THwZ+Jq/Ne6VBpsABZpb3U7aELj2Ds36VpX0kttYz3UtoIfk2hnZC248fwj+tbyqNdRQpuTNH4U+FI7veRK81pbN8z9POl7t9Ow9q9R+F+n29j4M05cqslwvnFScE56fpXBWryloj1MPh4x3M3WfCWm3EAV7cDaOCBXcXloWiPHFcylLudXJHsfL3j/AMNHSNRLxKfs8pyh/unuK9S+KcOmJpslvd3EcchG5A3XNdNOtLqc9WhF6o8BMYGcj5O/tVu8ja0uT8pKHr7iujnvscrp2M5o2R/Lx7qfWtB7dHURschuY2/pS5iHAqwM0mNjlZR0OOvsamitpVuQ5XDKQG9CPWhtAos6Hwxq4eaKyvSYiGOwkZGcen9Kgk0t5G27SrD51Yeh7j/PakppbDnTvudKy3EN0XZcwZ+5GeSPQE/196saW9w9mI7tczJxu9a6Y1Lo5J03Fn//0PEPF2qI5NnGSUhbc/PVhXN6/NsurpydzB3Y++Mmp3Z2QtGKPdobzwbZ22kx3N8kOopDFMsr3BDDKg4GTjHtV6y+E23w6kO5Xnvra3N08i7nVkUcKx6L7YrG0He7OnmqK3LE9Aa9SfQPtiOrDnkHg/SsldBj8P8AhHT9Et5HYRAn5zk8nOPp6VzSsnZHTBSa1OG8WT6fCV1K+t3nl+5GqRGRz9AAfrntXUxaLM873NrM8E7QNAXB52N95eemfatocvUxqe0+yj5617U9L1m+c2atFIf4HXbu9xXpOp/CSCN1nFxJiM7vmxkn69a0coLYzUasviR5HFEUUxOpKjp7fSt3X9NfTr94gMqDwp7j2pKdwlS5TOtSBKocB16Bv8aZC8SzA5MZ6FW705PTQhLU77SYYJ7OFwAdvyfUHtWZok00T7oiHjkGHTPDe4PY1klYuSOum0hDbI0Z5UgKR/d/xFc5Z6tdrrYtWaRVbgNgjBxkZ9K3gmtUc84pn//R+ctehFjN9rnGSZFkK/7AYE/njFXjcQeJmS3mtfs7fdQb8lh3B/ClNct7nRSnzbbn2wLqwh06CaWdFRkU7icADHUn0rgPAVzJrXhLR/tci/uGFvcsemYzg59iAD+NeXOdpWPcilKNzT8eapo0Moc6rbx4wQ8h2p+dP1NPBkl615HrFnH8u1lDfKx9QMc/hVblRi2thmhahYNKYZSnPKshDKw9QazJhoXl7bK+tQ+SVw+059s4pNtFcqW5v63HbvasIwCDzWJHPcz2e5WDpyNw9qXMX7p5N8WdKD2rXMHyyRHIK11Hju1A0K4kk67CTWtKWpzYhK2h4BFe3H2dWuIUlDHbycH8aZpwVvPLrujBxj2NdrSR5SbZoaXrEVuweGC7ideqpIOKjt9PSS4L4beOpBIJ+vr9aLRC01sb8uo3N9ewzQq28gKCQAT9ccfjVrSfLsWhmliVxkKcjJUCqUkthOL6n//S8B8KWY8/7VJnyYG34X7zt0Cj/PStS/sLjSrGOLTI5ADJkM2W5Pck9gBRiHK9ka4ZRtzM9M/Z88RJF4guPDGqMQ2sI9xAjdEkUfc5/iZOcf7NeSvba9pOs2mo29xNDcrcJNBM3P7xWBUsfTPBHpkVx1KClHszthiuSVlsfV194y1jw1q0nh7/AIR6x1GxitzJZTb9kgTZtZCu0hiM9QRwenGa1Fgm8V+HNO8RaZFD5skf72J4hJ5UoGHA7g9Rx1FRSrRaPTUcNVs5aM838Q33jPxdHHpsn2PR7WQncbaD51QhR1bOCdueADXbwaHqqTiS6jcuP9gIi/QDvWkqsUtC3Tw0dY6lax0a00Pwxb6VYRhIIgEjBOSAAP14o8Ralb6bakyyg+UCfqxrktzO7MZz7HmHxx1eHTdD+yCQLLP+7UE9Tjn8hzXFfFLRdW8QzDV8v+7UrHF2AJzn68V0UVFbs5avM9EebQXaW18lvGu9SuGz0Ynr/wDWpohuLa7Sa7RRj92zEcHjrXXdNHFZpnSWF4GgHl7Mrxz1HsayLO3DuZQ/mL3dcg4/GoaibKbO20u/sZJUOoQDIG3KN8pz1yO1chJHHJIbJ3IdCCkqc8cHBHpTSRLl2P/Tg8TaXq9hcQyLY2k9mFDx3UQLIPfg+5Hoc12etf8AJPbT/rzT+ledQxdSpO0h1IKGiPFtW0q21GKazulLPOreW6fL5bAZG0dB04FaEn/ISh/66H/0Fq7nFPVmKnKK0Zr+HPivqXgZnlWyFzZTsq3tmjbSj8ATRZ9ejKfY545878Z/duP98fzFcLoQpT93qelRrzejPoO3+It/4tt9mlWYh8xd2ZTyR7AVxfwU/wCXX/rmazrPk2PTpa7m5c+GNRvrlZtQaSRVOcEELmvQpv8Aj2b8ayU20buCPOtU0nzYzaQwkgDk44FdCf8AXy01NmbSPCfHngmaSB1h2o5bK545r0Dxl95f97+hrSVWUI3RzzijwS00u/spZor+REj2bWZTkAHsPc4rf8U/cn/66w/+zVpSqynucvKkYllZrDi7l27pMZY+vH5CrV3/AMgpf94fyFdlPV2ZNVcsbo//2Q==" alt="">
                    <img class="avatar" src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAASABIAAD/4QCARXhpZgAATU0AKgAAAAgABQESAAMAAAABAAEAAAEaAAUAAAABAAAASgEbAAUAAAABAAAAUgEoAAMAAAABAAIAAIdpAAQAAAABAAAAWgAAAAAAAABIAAAAAQAAAEgAAAABAAKgAgAEAAAAAQAAAEigAwAEAAAAAQAAAEgAAAAA/+0AOFBob3Rvc2hvcCAzLjAAOEJJTQQEAAAAAAAAOEJJTQQlAAAAAAAQ1B2M2Y8AsgTpgAmY7PhCfv/iAqBJQ0NfUFJPRklMRQABAQAAApBsY21zBDAAAG1udHJSR0IgWFlaIAfdAAwABAABABAALmFjc3BBUFBMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD21gABAAAAANMtbGNtcwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAC2Rlc2MAAAEIAAAAOGNwcnQAAAFAAAAATnd0cHQAAAGQAAAAFGNoYWQAAAGkAAAALHJYWVoAAAHQAAAAFGJYWVoAAAHkAAAAFGdYWVoAAAH4AAAAFHJUUkMAAAIMAAAAIGdUUkMAAAIsAAAAIGJUUkMAAAJMAAAAIGNocm0AAAJsAAAAJG1sdWMAAAAAAAAAAQAAAAxlblVTAAAAHAAAABwAcwBSAEcAQgAgAGIAdQBpAGwAdAAtAGkAbgAAbWx1YwAAAAAAAAABAAAADGVuVVMAAAAyAAAAHABOAG8AIABjAG8AcAB5AHIAaQBnAGgAdAAsACAAdQBzAGUAIABmAHIAZQBlAGwAeQAAAABYWVogAAAAAAAA9tYAAQAAAADTLXNmMzIAAAAAAAEMSgAABeP///MqAAAHmwAA/Yf///ui///9owAAA9gAAMCUWFlaIAAAAAAAAG+UAAA47gAAA5BYWVogAAAAAAAAJJ0AAA+DAAC2vlhZWiAAAAAAAABipQAAt5AAABjecGFyYQAAAAAAAwAAAAJmZgAA8qcAAA1ZAAAT0AAACltwYXJhAAAAAAADAAAAAmZmAADypwAADVkAABPQAAAKW3BhcmEAAAAAAAMAAAACZmYAAPKnAAANWQAAE9AAAApbY2hybQAAAAAAAwAAAACj1wAAVHsAAEzNAACZmgAAJmYAAA9c/8AAEQgASABIAwESAAIRAQMRAf/EAB8AAAEFAQEBAQEBAAAAAAAAAAABAgMEBQYHCAkKC//EALUQAAIBAwMCBAMFBQQEAAABfQECAwAEEQUSITFBBhNRYQcicRQygZGhCCNCscEVUtHwJDNicoIJChYXGBkaJSYnKCkqNDU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6g4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2drh4uPk5ebn6Onq8fLz9PX29/j5+v/EAB8BAAMBAQEBAQEBAQEAAAAAAAABAgMEBQYHCAkKC//EALURAAIBAgQEAwQHBQQEAAECdwABAgMRBAUhMQYSQVEHYXETIjKBCBRCkaGxwQkjM1LwFWJy0QoWJDThJfEXGBkaJicoKSo1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoKDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uLj5OXm5+jp6vLz9PX29/j5+v/bAEMABQMEBAQDBQQEBAUFBQYHDAgHBwcHDwsLCQwRDxISEQ8RERMWHBcTFBoVEREYIRgaHR0fHx8TFyIkIh4kHB4fHv/bAEMBBQUFBwYHDggIDh4UERQeHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHv/dAAQACf/aAAwDAQACEQMRAD8A+hNZ060fxIytGqpKRvCjHarGsL5uskK2CSRkdq8VvVnqxV4pGnpF/psQWwtRt2ZVEA4NczpaSWGvorSeYivjP1rWErK5Eoamr478bWnhDTRc6lZs8kxKwQpOhaRvfONq+p6V81/ErWG8ffEubToWkmZbloY1JysKRkg5HTqOvrWnN1Kp4dt6nWa18T9Ymb/Qmt9OtmyzKHJCf7uev6V5/wCMfAetxl5bJ/NG3AUnqB2FT7WOzZ1LC9UTt4mlj1F7v+1buW5b53kaVlPH0PA4rhYtB8UW0hMvmKCfmSMYz+PU1bnTtoy1hZvdH0F4M+M2oWwSDWrZbiAEhXQ4kYevPFfPp0vVEnhdfNCq24AjIY/7VTeMluRPCtaWPuIDR/FWmrc2lxHNjhZ4TyhxnFfO/wADfEGqWXi6007T4/Nt5blFnO/GYjkNgE4IBO714+uS1tTlnScNj17VrK70mYJdLhCfklH3W/wNdJ4huRq1lPp1ham8IXdIw6KB3+tJSb21IStvoczDdlcAkVJa+G9YuFH2bT5Qh6FztH61SUn0ByS6n//Q+grnfaTtIX3YDOCeetYOkaubzw2byUZEcRX3IFeT7JwumeoqsZ2aJ7O4ZryObO8lwxz35pG8uHwk2roAzJl1QdSKz5nGOuxrCHtJcsdzzDwzpVrD8U/EN9EqnE8u3C4C5c5GPzrT0knSn8SavNCC8t6Qi7scbQ55PuxpN6Xb0O1U5Rly9TYvgz5zjpXl83xH1Q619mbRgYSeW3OpGTx1WspN2v0O6ENbLc6++hRryJdgJwxOOwqPV9TOnaMdXmtmMe0MwBGalT5ti/Z626lm3srRmAWGNnY+nI9/auV8M/Ec6lqEcS6NIsRk2Eeau8fh39cV10046s5K2zt0NHwdpMmiePNduo8NbxEvbr93a7AZGfTk10y6fc3fiLUI7Qw4kZCBKT02Anj8a750XP3VueLOta8pbIfpviDxRbmS4t3aCVl5SLlD6DnrWj/YviFFCqLIqOgDEVMcLXh8KOZ4ihLd3Mtfi78R9PXbdaELkZ+9sU/yNXJtH8RHO61tmBH8Mv8A9an7DELZfiHtcM+v4H//0fR/C8g/4V2r9CyN/wChGsjQ9Vs7DwFBbX04gnK8xuDuHzdx2rknFyudsI2sRSeJb21ZdONq5tWYRlwuRgnmkTxp4flgitVtLS6+bYssUwBY/j39qhU5cnKy3Ocaimr6G1o8Mcceo2jgMUuQ+Tzncg5/Q1l2+qWVtq91bqRF9phimUGTdyMg8/lXHKCpKzPWpVvbS52rD7nTLGe9Xz0BZjx61yGreMoLe+uPs8T3FxFwhVgAvbNcSq80ttD1FRdrx6nfalp1rc2MljKo8lYwCPTFebaX8SL6e8WK/wBPkhST93I4U88dQCORXZSlBXuY16NSMVbc7LRvD2n2krBbeNt7BtzKDz2P196saHqdrNp73EcoZI1O0n1HQV0UXzOyOLEzUE2x93IDq8lzGXUBmSNgcbhtVSfzWsW91WCzs7WXVZZLdFBjYxrzxXbCnNSc1ujyMTioOiqK+F6s3kn1GaICO7cY6nfg1SuvE/hnSNPE8mnXE6uBhmbk56Vqq9f+ZHn+zo9mbek6jcRSFLi4mchcdc96n8K634EuoRcXNrdRAQBnJLcHPtWkKmI3uTKlR7H/0vMm8QwyhvOjj8wna4wOT6/jXn0t0+/fk/MNrD0I/wA/pUWZ7PtEuhs6vfCCRlhx5BYSKuMY5+b6Vz91KXTcex9fXihXQpTT1R6bptvqdx8Jj4i06Vze297LKy5yzwD5WUfQjcB7Yq/8DNbhuPC0+hsw8+0mdtp7o53A+4ySPwrzMdWlTmm1dHdhYKtG6eqN74earp+r+FWafT4Znjb5sYO4+tch4i8M67oGpTXvhDElnM+97JX2ujHrszwV9sjH8uFUoTfNSkl5M7YV6tJ2qJ+qO50ddFvriUTaRLCkROCzfKMenOBXn2kL45vA8cmlnTLRATPc3cgCIo+8QASW4ycdD61006NZ6OwVsxi1ZNl/xv4wSzluNE0RmSzOC0m7u2cgflXlAuzNNO6yO8YkHlswAJXnBPuRg4969Wjh401pueJUxLqPU9J0Xxjf2oVftc0kKD5onfcp6Do2fWuBjuCIplyckBQfqRW6utiXKDWqPo/w/dnxTpypaRW4kRFd0Ze3YivPPhpqs0WqrDFJtM37keg+XP8AICrqT9lBzgtTnnhoVZX2PVpLLVtPLGV40DqF+5xj0qH7fqUdiJTIruTjGSBivI/tWTXNKOnyNHl6T5eb8z//0/mG4lIOSc9CfcjvUV393/PvQds20yZyWicDnrSL/q5PoaYX0F0TVr3RtYj1CxlMcqnnHRgeoPsaoN/rPy/lU1KcZq0tQhUlTknFnrtt8UbOWAC8tZkfHO0dDXlB+9XGsvoOWx3rMq9jt/HPjy91nRJ9Ns1ktrNxtlZmzJKM/dPovt3rjbn/AI8ZP94fzrup4enTj7qOOrialX4mJb8PNnuwI/M0kf3m+q/zpszg7IlWQAnP94foKibq3++P5UIfMd78MJ3Gt28zH5YTuY+54H6Z/Sovht/x8P8A7y/yrqp04yi0yk+p7fdXCxWduCRuY9M1R1XrafWvj8TFQg0u56cNZ38j/9k=" alt="">
                    <img class="avatar" src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAASABIAAD/4QCARXhpZgAATU0AKgAAAAgABQESAAMAAAABAAEAAAEaAAUAAAABAAAASgEbAAUAAAABAAAAUgEoAAMAAAABAAIAAIdpAAQAAAABAAAAWgAAAAAAAABIAAAAAQAAAEgAAAABAAKgAgAEAAAAAQAAAEigAwAEAAAAAQAAAEgAAAAA/+0AOFBob3Rvc2hvcCAzLjAAOEJJTQQEAAAAAAAAOEJJTQQlAAAAAAAQ1B2M2Y8AsgTpgAmY7PhCfv/iAqBJQ0NfUFJPRklMRQABAQAAApBsY21zBDAAAG1udHJSR0IgWFlaIAffAAYAEAARABUAGGFjc3BBUFBMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD21gABAAAAANMtbGNtcwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAC2Rlc2MAAAEIAAAAOGNwcnQAAAFAAAAATnd0cHQAAAGQAAAAFGNoYWQAAAGkAAAALHJYWVoAAAHQAAAAFGJYWVoAAAHkAAAAFGdYWVoAAAH4AAAAFHJUUkMAAAIMAAAAIGdUUkMAAAIsAAAAIGJUUkMAAAJMAAAAIGNocm0AAAJsAAAAJG1sdWMAAAAAAAAAAQAAAAxlblVTAAAAHAAAABwAcwBSAEcAQgAgAGIAdQBpAGwAdAAtAGkAbgAAbWx1YwAAAAAAAAABAAAADGVuVVMAAAAyAAAAHABOAG8AIABjAG8AcAB5AHIAaQBnAGgAdAAsACAAdQBzAGUAIABmAHIAZQBlAGwAeQAAAABYWVogAAAAAAAA9tYAAQAAAADTLXNmMzIAAAAAAAEMSgAABeP///MqAAAHmwAA/Yf///ui///9owAAA9gAAMCUWFlaIAAAAAAAAG+UAAA47gAAA5BYWVogAAAAAAAAJJ0AAA+DAAC2vlhZWiAAAAAAAABipQAAt5AAABjecGFyYQAAAAAAAwAAAAJmZgAA8qcAAA1ZAAAT0AAACltwYXJhAAAAAAADAAAAAmZmAADypwAADVkAABPQAAAKW3BhcmEAAAAAAAMAAAACZmYAAPKnAAANWQAAE9AAAApbY2hybQAAAAAAAwAAAACj1wAAVHsAAEzNAACZmgAAJmYAAA9c/8AAEQgASABIAwESAAIRAQMRAf/EAB8AAAEFAQEBAQEBAAAAAAAAAAABAgMEBQYHCAkKC//EALUQAAIBAwMCBAMFBQQEAAABfQECAwAEEQUSITFBBhNRYQcicRQygZGhCCNCscEVUtHwJDNicoIJChYXGBkaJSYnKCkqNDU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6g4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2drh4uPk5ebn6Onq8fLz9PX29/j5+v/EAB8BAAMBAQEBAQEBAQEAAAAAAAABAgMEBQYHCAkKC//EALURAAIBAgQEAwQHBQQEAAECdwABAgMRBAUhMQYSQVEHYXETIjKBCBRCkaGxwQkjM1LwFWJy0QoWJDThJfEXGBkaJicoKSo1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoKDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uLj5OXm5+jp6vLz9PX29/j5+v/bAEMACAYGBwYFCAcHBwkJCAoMFA0MCwsMGRITDxQdGh8eHRocHCAkLicgIiwjHBwoNyksMDE0NDQfJzk9ODI8LjM0Mv/bAEMBCQkJDAsMGA0NGDIhHCEyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMv/dAAQACf/aAAwDAQACEQMRAD8A831GdBC0bfxDFYsheeTBf8Ca0UUK4/dub5TjPTB5+uafCgL7F6Z4Hr/nmqskG4qRBoHd5MFTwD1P/wBai5bzJBAATt+UAHrUuVyrWGPKC0TwogKjDbuQSfUeldP4d8NeepbyywyOD0H+NTKSW5pGnKT0ObgtZ3BkMDeWTu27eD+FespoRih4TtzxWXtrG6wt+p5I/wC+nKzeYctkjOADjqa7bWtDXJcLtYcgqMUKqmRLDyWxxzqrWzFI4hGR85RQ21u2QMGnKstuzmIByv31/qK0vdaGVmtGQypDOEMC+W5X5lzkcVHcxpGVeOQsZckjsBmgRQugQACMY9RVplWZNsnBC4yeCKCWj//Q8hUhUIyMDoakhiDOA33EGWrZsSQ9P3SZOd7jgY6CnH52Mr8KOgzwTUFlvRdKm1TWILRAwUfNKR6D6V23w0sZXt7q/RBu3lNx9qiTsb0afM7s7bSdGbSrRXbT5o4P4pQu/n3A5FZ+oSeJNN0s6la6xcs/2gItt5aNCIyQCxIG4EZJOeCBxRFKW7NJSlF2ijrbq3jk08yRNHIm37yVFo13HqHh97wqqSFT5u3hdw6kVnNLobQbe5xOtQ5jbK9qZr2sRTQuLSSAIPl3yHjNYqDZrOUUjyrVC8WpK0WQ27t3qfVMvdx7mgfcesTGuiCtozhq66ohlTzIHngOyQr8/A55wTTImMU4c/6tQeD0AqzEp7Fk5LfNGDhjxnFSvEDIeXD8GLHAJPNAmj//0fKFCjCsflzlv8KVIyqCSTAHUDPWrGNmcBdxwEUfdxgg+hqJszyhAcgHJyepp2C57t8HLeNvCcYfjzHkY/i5rI+FGqiTRJ7aKTE9nK3ynujfMv8AUfhWM7qR20bOFludrqdlHBcGORwIWPQjNSaZPFcXJmu4pDdnJQOvygeq/wD1+ahx10OhT0sUtZeLTtAvFicKGjIQL05qLxpqFrc6HPEYtrRtgY4LVEkUnfoee6FaJe6DeWroXSYlX+YjP410HhW202Lw/cmKf98JC5DkZHFPncVoSoRfxI8s1q1msNQ/0iUMC5ZVAHGak8UTi+14iLO2I5JAyM1pTcnqzkrxhF2iUgNlyp52DDBvUDnpTokDHJX5lj/hB4P/ANetTAhmQNO3cKvQAURsWlcKx9sDJxSA/9LyOeYyHgDGelKV5yegOCR39K6LIm45VMVox3D5gQPf1qSSJntItvDNweMd6VijofB2qN4dv9NmVQVvDi445MZztx9Ov51ksUXyVZ1QxiNgd2NuOc/h1o9nzJlRnys+mUigntI5M4wu5HQ4PTtXnfgrxVq1zYzWlzYXF1FbkgXVvEWCZ5CuPXBB4ycHpWEqc46nZCtF6XJfHD30tvtRYmJOBIsYDEe5/wDrVkeLPE0ISaC0ffMpKFsfKp749fwrK029jolWgo2Rzn9qppWjvZpiS8k+8fSsGK3IBlkYGUsOSvvWih3OR1X0KYiKFsPmRjlmz1B6inXYPAK4IydwqzFhBKJUkwzIE5xSWQzBOfmXKbRgcHn+tAlqV7ctseRgDu7HuKkUFYR6g9/WkFj/0/KZYizgbOQOeeoqwf8Aj4P+5XSQgX506/JEmPqfWmwf8e830P8AKrS0E2d1BqOp+HvA2hS6W4gm1UTzTXyQq77UfEcOWBAGCSR7H3qS7/5JV4K/35//AGapjFOTuNvQTw14g1m48aaRFDMLGFZDJPa2p8u3WLBaV2TpzySTnBIANUfCv/I6XX/YJu//AEAU5pJBFlDXXhu9ZvJ4PkgkuJJEA4IUtnP156VVm++fp/hXOzpRXlbaxO7hcgBh0pl11l+v9KkGVI4WuZgOSBx7Ee9WtL+8v40yOo8wmOCdYyCN2CrKcZx2P4VYb/j3uf8Arp/Q1N9S7aGHG4YSKTxnI4qOPv8AQfyNNmdz/9k=" alt="">
                </div>
                <span class="social-proof-text">Join <strong>500+</strong> homeschool parents already reading</span>
            </div>
        </div>

        <!-- RIGHT COLUMN — PHONE MOCKUP -->
        <div class="phone-col">
            <div class="phone-frame">
                <div class="phone-notch"></div>
                <div class="phone-screen">
                    <div class="nl-preview">

                        <div class="nl-header">
                            <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAd0AAACXCAYAAABQiYHQAABn6klEQVR4nO2dZ5QUxRaAv+pJG2YTObPkoGSJC0pQVExgREXMWcw54jNnRH3PrKggqIhgQEAkSJQMCpJ3yXl32TSx6/2YsDMbZ3pmo/2dMwdmp7v6VvftulW3bt0CHR0dHR0dHR0dHR0dHZ3ahKiQUlv3SkqQMY2kVBuB0khCYwViVeQhKcUhUA8J4TqYl77qUIVcX0cnCkgpk4BGAZ/GQCxwKOBzUAhRLfVYShmPR+bAOiQCRwiWf3+VCfkvJUTdOiSEOFhlQoZAbalHZRIVo5vQtE9d1Wg4WxHiLCk5SwjRNJTzpJQFCP6Qkrm45dy8fcs3RSpLXMu0cxUh+0ZaDkBu+rLxWs6Lbz5guDAwIBoyqKq6RlGUXtEoy6UqX9j2LNkV+Ddry36dEMoV0Si/GFK4ERwVqIdcKIekdB62Zfy5u0KuFQWklHWBs4GzvJ+Q9BgoAP4A5gJzhRAR67EWpJQJwJkUyt82xFOdwAo88s8DVgkh1CjIczvQMNJygD1CiE9DvGZT4OYoXBNgoxDi+0gL8T6XvkU+DUI83QGsB1b6PkKIHZHKpIXqWA8pZSzwSKTleFkshPg9SmWVSkRGNz51wPWKFHcgOK3ob4oiaZyikhAribVIDArYHIICOxzKUsizKcXKk5JjAvVLaTe+lHvoj6NaZLKmDnhbIO7Wcm5RctKXaro/1pZp+4WgScQCSDKlKu8QBvF1xGUBqsrwvD1L5wX+zdoy7WIhmB6N8kNGyp0SsRIpV7oV8WdBeuZa2OyoVBmCxJHXA3dAcT12u90cPHyMnNx88gtsuFWV2BgLsTEWGjWoizU+rqQijwFfAi8JITTpcThIKS8B7gZOL/qbqqocPnqC7JM5FNjsOF1uYixmYmMs1K+XQnJiQklFngSmAy9G0jBKKTcCXbSeH8AyIURaiNfsg6dRjwZThBBXaz1ZStkYeBa4HjAW/V2jboHHeD0mhPhVq2zhUJ3rIaWsAxzXen4RXhRCPBGlskql2A0sn8HGhBaO6xHiUaC1z2x3SXUytLuD09q66JLqomkdNwZD6TYrM1ewbZ+BNTtNLN1sZMEGMzanUg+U+4hRb7emDvhQlfaX8zPWaHJLxMeonNrSHfZ5J3IE2w9ouC1eElr2vwGvwe3T3oEQ4dnto9mCXYe81xe8hiL8xqh3OweKEl55Tjes3WEq9XeBKkHRXH5ZSCmxOwUFdsGJPMGxbAUQIEQbAW0Q4iojkJCakiPlgIm5UnmDPUsyoyZA2bIZ8TQiHj32snHzdn5btIJV6zez8e9t7D94FFUtfdCXnJhAx3ap9OrWiYH9ejB0UB9iYyz1gPuA26WUHwIvR9u9JqVUgCuBx4BTfH/fvmsPcxYsZ/X6v1m/aSt79h/C5Sr9PbDGx9GudQt6du1I/95dGT6kP8mJCYl47s21UsrvgOc1jt4lwIFDR8nYG371W6c2pWH9uv5ywrkmwPq/tlJQYA/7up06tPJ1RsK5bqEAUibjeS7j8LhaAVi36R/mL/6T1Rs2s2nz9pB0q0PblvTs1okBvbsx7PQ+PgPWHZgtpVwKPCCEiFYnoybWw/+M/tm+m8ysnLAL6N6lA7ExlqCyKpKwWti45mlNFEX+JIToAZAcrzL2zAKuO9NGaoPIvFH5dpi1wsL7v8SyMd1jJKSU+SrisvyMpb+EWo5vpNu9tZPfX8oKW47vl1m46e1EQNtIN6HlgO0I0fas7namPXYy7Otf/VoCs1fHAGTl5NLCGs9ZvpHo3klHiY8Jr7wjWYKOt9YDyh/paik/HBxO2HNUYVO6iXU7jfy23sw/+wI7ODJbIt/OpeAt0tdnVZQcUsomwE9AD4DM7Bw+/3omn06eSca+yGxjbIyFi84dzJ03XkG3U9r7/pwPXCaECFmPy8LrBp8FnimM3Lx8Jn83m4+/msHWHekRlW0wGDjrjL7cdt1lDB3U239J4CkhxAthyrkR6PL2h1N46qX/hi3LW88/yI1XjwSNI91ew65i+649YV93+uevc9YZ/UDDSFdK2QP4Fa/b9fDR43wy+Qe+mPYTBw5F5vQwm02cM3QAt113KQP79gj86TkhxNMRFV6EmlKPwJHuZTc8xJwFy8OWZ/Vvk2nfpiVU0ki3uI+3FOJa9O2lKKwWQvQwGlTuPD+f9e8eZ/xV+REbXIA4C4w+w87CV7L4/L5smtd3IYSIMwh+Tkjt/2jIBcloBof1Kn2IWALW1AGjEaItwP2j8sO+2qYMI7NXWwCQyLc5tjT8bls1xmyCtk1URg2w859r8lj2Riar3z7O3RfmUcfqBkSSQHnaKuP+im/Wt2tFyCCl7AWsBno4nS4mfvQ1pw68hGdeeT9igwtQYLMzdcYcBp1/A2Nuf4I9+w8BxAE/SylD1+NSkFJ2AdYAA1RV5dMpP3DqoMt4aPxbERtc8LgKf/19GSPH3sewi29lzYYt4OmcPy+lnCalrMBuWc1GSnkVsBZokJObz/hXP+DUQZfx8tufRWyoABwOJ7N+XcSI0eM4+/I7WLfpH99PT0kpZ0gpS/XjhkNtqUd1JSSja20x4FKDYlwtBI2b13fx63+yee6aPBIr6NZc2M/B0tcyGTXA5hPzJWvLtK9COllE00WwxhnW4VI8CTCgs4O+HV1hX+2N6bGAAEleLvkTwOf+jRbuYmVFt/zwad1IZfzV+ax7J5N7L8rHbJIIIZoKg2F5QuqAi6J5LSnlpXgMbuM9+w9x1qW38eSL75GTG34HKRRm/bqIvsOvYfpP831/eklKGZoel4CU8gJgOdDy0JFjjLhyHPc+8TonMrOjIW4xVq37m6GjbuGFtz72uQ8vB5Z4PQUhiRwlUTS5lyvzulLKV4HJACvX/kW/c67hzf99id1eMaEKy1dtZPBFN/PCWx/jdrsBRgLLpJTNIym3BtajSp53JJRrdK2p/QYLRXwLnnnb31/Momfb8A1KuFhj4ZN7cnjg4jwAhODq+JZpH5d7YhWNdBOap10ohGdu7YGR4Tfi/+xTmLUyYJTrda9KojjJShmT7FVMQpzk6avymPdCFu2aeLwcIH6Ibzng/miUL6UcDHwLnnnb0y+4kbUb/yn7pCiQl1/A9eOe4dV3Pvf96WopZfl6XAQpZRoel3L8lm27GXj+DSz7c0MUJS31urwy8XOuvOUx7A4HQC9gXogj3mjpWzjlRFPHQypLSvk88BDA5OmzOefyO9m7/3AUxSj1urwy8XMuveEh8gtsAN2ABd4oYy3l1cR6VPrzjpSyjW6LgSlg+BqgYzMXM57Mpm5i5Q6Mnrgin3tGegyvIrgxrkW/CypVgBCRinwGoHtrJ0O6hTdABnhjejwgkFIW5Ir816ItX2lE16hHTpeWLua9kEnfDp6etSLEG3EtB5wXSZlSyhTga4At23ZzwVV3V9josDSef/Nj3vzfl76vN3pHrSHhDWiZCrB1Rzrnjr6LI0dPRF/IMpg9fymjb37UF5TVGZhQqQJUU7yduccBPpsyk9sffME3Yqs05i/+k5Fj76fAZgdoA0wKt4zaUo+aQJlGN0GoXwpolBin8sUD2dRJqBpP5NOj8xjewxOFaBCGSXEtezWuEkFKIb5F/2FCiJ4AD1wc/ih3+wGF75d7RrkC8W5FBhHVBBLjYPoT2fRs6+m8GBBfxqf2bhRBkV8CjbJzcrnq1sfIzK6aqfLxr37Ar78v832d5F2KEQqTgWaZ2TlccdMjld5h8DF/8Z88+txE39dbpZQRdYZqOlLKhsB3gPht8Urue+qNKpNlxeqN3PbgC0gpAUZJKe8I9dzaUo+aQqlG17P0RZwH8OJ1ubRtEnmwlFaEELx3R44n2EaQoghLVNatRgshxOPg8QaMOC38JQpvzYhHSs8oF6ft1agLWAOJs8CXD5ykQbLnmQtM0wgj8M+HlPIG4DyAR559m53p+6Italjc9uALPqPpH32XhZTyNmAEwP1Pvc6ujKpNHvXhF9P55bclvq9fSikj6QzVWLxLtmYAdY8cO8FN9zxb5rKZymDGz7/z0Zf+XB5vSSm7l3dObalHTaKURqyXSaK8AtCvo4OrzgjfkESbuomS8WO887uIM+Japp1bxSIBENeyX08hxFCAe0fmh70ud/dhhW+XeEa5CPFBzoE1x6IuZA2lcR2V12/0jEoF4vT4lv1Hh3O+lNIEvAKw7M8NTJk+O/pChsmJzOzA5TNnSClL1WMppQWv/L8tXsn0H+eXdmilcv9Tb5CXXwCejsNzVSxOVXEl0B/ggaff5ERW+MsDK4JnXnnfNw9rBt4M4ZTaUo8aQ4lG19oy5gIhqAfwxBV5lStRGVx5uo3WjTxBXEr0Ur1FhAHlWYDUBm4u8Udbh85bM+JwqwKJdKhSH+UW5fw+Ts7u6en0CSEeCvP0C8Cjx8+9+VGUJdPO5OmzA0fcZenxaDy5khn/yvsVLVbIHDh0lI++nOH7eqU3x/O/jTsAVq3/m5mzF1axKIXk5Rfw8tv+jJlDpJTlpQKtLfWoMZRodAXyBoBebZ2kda74SOVQMRgEd53vmTMVglHWRoPqV6U81hZppyDE+QB3X5hXZgaukthzVGHqYu8oV4qPtGbfqu08fKnfw9Hd2nxAsVSHZXADeBqUpSvXV4Bk2lBVlbc/nOL7OkpKWZoe3wwwd+EKNm7eXimyhcrEj6bgcDgB4oExVSxOpSKl7IY3McnLEz6rYmmKM+X7XwPXnI8r7bjaUo+aRjGjG9eyV2MJ5wJcPaSg8iUqh1FpdixmT0CXiHHfUKXCKPIpgEYpKlcODn+UO2FmHC63gpS4VGxhZfv5N9GjjZu0U7zrBA3cF8o53iClcwG++jYqiaCiyvc/zcdWuPaxmB57e/ZpAF9M+7ESJQuNY8ezmD1/qe/rnVUpSxVwJ8De/Yf5bXGFZGCMCLfbzRfTfvJ9vamMZBO1pR41imJJhg3EnIdAURTJhX0jWxB9NEswb4OZzRlGsnMF1jhJuyZuhnZ3aM5ilRQHw7vb+fHPGJDiArxzXpWNpVnfdkguQ8BdF+RjMYU3yj1wXDB5gXepo5Cf5qfro9yyGH26jaV/m0FyIamDY0hfWF4v5zxAcbvd/PBzZBuH1KubzPDB/TmlYxuSkxLIyc1j+849/LZopeYsVidz8pjz+zIuOncweNzgRfX4ct9xAcZNE8mJCQw9vTfdT+1I3ZRE8vJt7Nl3kN+XrGLz1l3lF1AKU3+Y45O/i5SyuRBib0SC1hxGAUyd8asvylYzPbp05IwBPWnWpCExFgvHTmSyev0WFixZ5Zs318SU6bN56oGbwZMN7SxgZgmH1ZZ61CiKGV2J7CsQ9Gjt0rxESFUlL30bz7s/xWF3FDdGiiK56gwbL1+fS5wl/PKHdHXw458xSGRPPKP1Sg+3MxsMjyKEUsfq5tph4SvV27PicLoEUuJyOcPLaRtNAjc80MLJfHh8krXE3xQg2Spp28TN0G52mtXT/mKf38fOPR9IVFUo8aptYB78Vs4pfQHWbvpH8xIhIQRP3Hcjd99yFTEWc7Hf3W43k7+bzUPj3/KtLQyL+X/86TNaPaWUSpHt9PoDLF6+BqdT2xSPEIL7bx/D/bdfQ4K15EHC/MV/Mu6xV9h3IPwkCIuWrsHlcmM0GgD6AbXe6EopO+CNE5hTuPwrbDq0TeWdlx+hX6+SN2E6kZnN829+zMdfzSjx9/LYf/AIf/+zk1M6tgGPxyTIWNWWetREim+nI0RvgIGnah/l3vHfBL75w78pBVLKfUKIfSAbgUhVVcFXC2LZfsDIT89khj0XOvAUp1dUERufOqBrXvqy9ZqF1YDHBS/GCuC2EQVhbxJwOEvwxe+e+yOQX9oOLAs/K3uUkChhxlsHY3MIpiyMLfc4g2Ll6iE2XrxWW0crKQ56tHaxZocJIQynU77R7Q3wx/K14V/MywdvPMnoUWcH/mmf99MISDUYDIy94nzatW7BuaPvCnupRYBssUBXPFud+egLsHDpGm3CAx+++RRXjBwe+KeDwG6gPtAOYNjpfVg86xOGjLw57FF7bl4+azZuoW/PU33yfqtZ2JpDP/B4IFZ78lKHTbdT2vPL1HcDO0L5QAaQjWfHqwZ1UpJ487kHSG3RhCdffE/TdX5fsspnrPqX8HNtqUeNI3iI06x/LJ6E6nTVsC0ewC+rzIUGV8plTiFTczOWNc9JX9o/J31ZK5zOesCPACu3mnh/dvhu+jaN3cTHeBo4oco+mgSNAIWYx4XAmBCrctM54Y9y35nl8QBIKVWnU4yPvoShE83cyxI2SuQi3wfJUukd/bhVwRfzYxn9chKqxksO6OT0CT2oTDk8G1t3Adjwt7YApBFnDQw0uMuAVCFEcyFEfyFEKzyjhB8B+vfuyh3XXxb2NXam7yM3z59Mxa/HUsrWeAwjG/7aqkn+K0YODzS4fwBthBBNhBBpQoj2eJZiPAs469VN5sM3n9J0nQD5+mkqoOaRBrDh762a1rMqisKnE8f7DFUenn2QrUKIzl7daoinA7YJ4O6br2RwWrFtnkNiXWGa077e5XO1sR41jiCjm6AovYQQCkCnFuGnMgT4ZK532CfliRy3PNO2e1lG4O85+/88npO+9EIp+Rvgs3nhb1oihKBjM0+nQAqlUo1uQpNe9RDyFoAbzi4gOczFEseyhb/OAqbYDiytslFutJGq+4Hc9GWDfZ+cjKUDc9OXtpA2pYEv3/CSzWam/aFto5pOzf1u1vIa+F54dVvrnOXNYy72/fcEcKYQIkiPhRDHhRAXgkePbxwzStN1tmzf7ftvoB739f1n8zZt8t954xW+/+4RQpwuhAgqSAjhFEKMB14AT8ehZ9eOYV/nr392+v7bU5OgNY/+AJu27NB08tlD+tOudQvf13uFEO8IIYJ6od69iwcCJyHoWYZFgIwmij+f2lKPGkeQ0VVR/Zt5t6wffu/H6YI//vZ0RFQpPmDf8lKHgQLeAth1yMjuw+HPKbZs4PaWI1uFfXIEqGbLgwJhjjGp3HFu+KPcd3+OpcChIKVUHW75bAWIGBaVsaFC7qE/juZmLLsZ2AoweaE2o9vRa3QFxFia9mlfxqF+Pc7YeyDs6xiNBk7v73+3PxBClPWg3wJok9qM1Oahbr5TSMDm7oF63AY8EcJadkBqWL8u3U/t4Pta3trviUABwNlDB4R9rfQ9/vsbK6VsGXYBNY92ALs1ZgY7p/AeHwS+KO04IcRJ4H8AQwf2xmQqPhNYHunBut+uyM+1pR41jiBrJwQJAIlxKrEa5t227jPgcnuKFIp7blnHupwO/+9/ZxjCvlbDZK/R9cpcKaR2T1akuBPgmmE26ieH5yY9kSP4ZI7X9S741r5vubZuZrWl+NaBgUipvgOwdrtRk4u5aZ3CjqBiUlLKODQBIDsnN3BZTsh0aJsa2DiUqceBv5/aKfz1+4eOHPf9N1CPEwEOHtGWnKz7qUH9kZ/LOlYIkQmsAM8cXbgcPBwkY+W9i1WAN2WiBeDAIW3PplthZ2iuEKI85fwFwGQy0rl963IOLY7d7gjM053o+09tqUdNpYjRFVaAeonagoEPZRUW53SqZQ4xCg6oh6Q3Tv1wZvhGt36Sp9GWlfiiW2X8OARWo0Fl3AXhj0D+90sseTYFKaVEdf+nAkSsYsqOiFMR6QA2p0LG0fCfeb0kFYPiXaMtDXXLONQKnpGiFho3rBf4tbyh8iG8+3A2alCWSCVz9Him77+BepwAcKzwt7Bo3Cgo10YoyaYPQLF6h8TRYBlrfINYDv4HfFTjs2nSyH+PQxli+nVPy7OBIDkDn01tqUeNJMjoSul52WPM2gJdcgsK21y73VROKOQaJ0IcA8i1he/h9MsoK8noNusfKwT3A4weFP7yl6w8+OhXX5SvmJG7Z+XmaItY3ZFuedT3/6zc8J+5EIKkOG8AnZR1yjg0AcCmYRkPgDU+KLivTD0WQjiBYwDWUpbllEWAjMVGulqWIQEkWv2BBseEEKGsN9oPkJhQ8tKvsihyj2v1SJeABr+gIPxkOAAJhc8mlHkPfxyBlmcD+PanBUgK+HNtqUeNJHgy1euqNYfvdi9Ooq3ciVohyQWwObUb3cpyL8cbxB1AshCSuy8Kf5T74ew4TuZ7b4l0aQsVrQCiGb1crnvZKI/4/p+noaMFYPHGLgpPsv3SSACwO7QFAxYhlICDXKDEtbzlEeD+LmZ0HRrlN5v9AZ6hKmo2RCw/1IJRSDn4G3ytumUx++9xuc/G26FzAlg0PBsAm83/fAKfTW2pR40k2L0MNgCtyUkS4gpPtDotzUM4RXODb/DH/4hKeAidzQLxKMCo/vawtznMyRe8/4t/LeuP1WmUW5mb2Ctug//NcauRGV0QZRldG4CisWo5uUGbfFSoHns3hYfgxkQBcEW+iXiocmmWv8hyEw2RIDUK/5xIFDZ4D/WeR7RExuX2OzoCn01tqUeNJDh6WXrcvfklZJEKhQYBgUWqQiiRjBE3+BIZWa7KELCmptzg23XpnpHhRyx/PCeWrDzPrXZL9ZnoSledCDPLiQYU75wuilrWpPAxgLhYbVHSh4+eCPxaKXoMBOpxtO5jqOVU9vVqKtGsX6hlRcVdU+R6taUeNZKi7uUjAPkaXX/tmzj9gS6KEKGMEGoAg40C+SjAOb3sdGkZXkq+PBu897N/lPtrfsbydVEWUKc4R0C70d22MyNwBFpL9FhHR6c6UGT2Vj0ECsdyFKSUYW/IbjEJuqS6WL/LBMizgfI2AZUAs1aY2b4/vGjW3Yc9xwuEtkmCEIlv4bgSREvwbFIfLp/OjeFEjqdv45KyFkYsV0sOAdSrW5YHunQcDicbN2/3JYsIWY9HnjuE9m3CW6raqkVT338rVI91dHSqB0FGV6rqMRQFu0NwKNNA4zrhLx26oI/DY3QlF8W0GNjatmdJWSl1BMCWvSa27NXm8q9Y9/Iap6IMeApg0Cl2+rQPb5RbYId3f/JEtEop5xdkLFsefRl1SuAYeAKDGjWoxyEN611n/brIZ3QvklK2LprRqQgCoHOH1nTuEP46RC8VPk2io6NT9QQbXTeHfQ7n9MOKJqN7yUAbL34Th1sVwoj6AGXstSmRK4AI0yCWuzBbM9YWaZfjzYBy/6jw53InzY/haLZ3BC/kc9GUTadM/FvmtGrZRJPR/XbWXJ68/yaMRoMAytRjPMklIk3nqRtdHZ1/AUFGt2D/yv3W1LSjAuqv322if6fwtxRrUV9l9CAbkxfFAuLW2Gb9JxXsW/5nScfmZiy7SpvYZSCiuM2fwuMAPds6OaNLeHEAdqdk4izPWjaJ/CM3ffmiqMmlUx77gaNA/R5dOrJ81cawC9i7/zBfz/iVay47D+BWKeUkIUSJeiyEiLYeR2sZV4VHL1dQOTo6tZaiaxClgNkAy7doj/B+9Io8EuNUhMBgNIjJ0Lny5qtkBJvDFkFAN4AHNMzlfvV7LIcyPaJIVdXncisRb+L12QADenfTXM4Lb35Mdk4ueJZYTJZSVpYe69HLOjq1lOKb2KvyR6GIscu2mHC7Zdh73QI0rSt5fmwud7+fCEK0TUhNfi4nnUeiInEl06m5k3NOsxNOe+J0wYSZ/rncdXl7VpS396tO9PkRGJvWpxuKomjavuzAoaM89p+J/Pe1xwHaAs9BjdLjsEaeCdZ4HrxzbKVdT0fn30gxo5trtM+zumPcJ3IUw8K/zAzrpm151Zghdn5cYWfeegtS8lB8av/f89KXz4lY4krmvlH5YUdxT1kYw/7jnrlcFfFERcilUy7zAHfdOsmGIQNPY/7iEj3D5fLVd79w0YghnD2kP8BDUsrfhRA1RY/DUtzEhHiefvCWSruejs6/keKu2F1rshFyCcA3i7Wtc/Qx4dZcGiS7EUIIRSrfWVv07RxRgZVMq4YuRvULL/+tywUTfigc5eZnLJ1dEbLplI0QIhtYAjB61DkRlTXu0Vc4fPQ4eIzKd1LKGqXHOjo61YcS5z8lYibADyss7D2qfYq0cR2Vrx/OJs6igsCKYvw1oUkvbdtMVAH3XFQQtnt92hKLfwcdoYrxFSCWTujMBBg1YgjNmjTUXMihI8e47IaHycsvAM8ORr9KKWuMHpeHEOJFER2+rOq66OhUd0q0qHl5mR8BWU6X4I0Z4e+cEkiPNm4+uvskiiIR0FyaYhbSYqC2rAWVSJM6bkafHt4OHG63ZMIM3yiXzTl7l86qCNn+zfgSRQnvxuvl8BGQZTabePiuayO67vq/tnLD3eN9uWqbAwullNVej3V0dKoXJQ9jj27ORfIawOQFMew6FFlA8LmnOXn1+lwAhOAUq5B/VPcR77gL8jGHGcA9fVkMOw/5psnl01EXqobjli7/fmAxJm0xN74dqSSUuxGoECIXPHo85rLzaNWiiaZr+pg9fykPPvOW7+spwB+1acSro6NT8ZRqTXPyMydKyTG3Knjtu8hGuwA3DLfx8nU5gMfwYo5ZEt+qr3afXwVSN1HlmmHhjXJVVfLm94Wj3NyMZd9XhGw1GbNi9D/v+BiNRte3GYeqhLr79kTgmNFo4NF7btB0zUA+mfwDD40PMrxLpJTVUo+rAdGKZj5VSrkwlA/wvyhdE/RobJ0KoPQh7NHNuRL5EsA3S2JYtzPyTXZvOdfGGzfl4NXlDopqWBKT2i814oKjzB0jCogLcwOpmSti2HbAe4882af0F7YIUhQap0Yp4S/hsTulf09iKWVWKOd4R7svAVwxcjg9unQM+7pF+WDSdO598nWkZw/MDngMb2rEBdc+ohXNnAicEeKnZ5SuCXo0tk4FUKYlzcvIetfaMuVGEJ1vfSeBha9khm2MinL9WTYMCtz3kRWJaGtEWRnfrP+ZefuWb4qsZC8iMmOXGKdyw9nhRSxLKXljhmcnIYn8Jzd92dRIZKjFnA1QP8lNvaTwH9PhrMJNMUJxLwfwLnCjoiidP57wNAPPu54CW3jPuCifTv4Bl8vFxBcfRlGUtsBKKeWZQojo6LEOf6xYG7jbU9hkncyJVAS946wTdcoZvm52qLLvWIMwrt5x0Mjjk6xMuCU34ouOHWYjMU7l1ncTcbpEA2EUS62p/S7MTV+xMOLCI3xRhnZ1hL35+c+rzGze45kAliovRHL9ykagyrIcHuHhLvXex7Qa0FJIcTPA2T20pRnOOFxodPOFsiPU84QQDinlWGB1u9YtePmpu7nnidc0yRDIF9N+4mROHh+/9TRms6kBsFRKeaEQYmHEhevw/U+/8/1Pv1elCPpIVyfqlNva5u9ZuUZK+QLAF/Njmb0qOpnwRvZ3MPXhbOJjVIAEUObGtRxwXlQKj4BwDS5AxpGAvovirFHZpyQaKhwqzfrHxrfod6Y1Ne0tkxTpAAZFcuM54W8eAbB5j9foSrmDPUvCGekihFgDng7R9VddxIgzB2qSoSg//LKAy258mNy8fIAEYK6Ussr1WEdHp3oS0hAnN8M8Xko2A4x738qOA9EZGQ3p5uSHJ7OoY3UjECYF8UNCy/6jIiy20nuno0+3YTJ6BnkKxusq+/qR4BnpRgdFMcxLSE2T/o9RyVcUwzwB9wIIIXlhbC7dWmlzGW7K8HRuJCVvPBAC48Gjx/999THapDbTWEwwC5as4oKr7+FEZjaACfhBShmpHuvo6NRCQrSeC10q6hiAE7kGLn8pmSNZ0bFtvdq5mfl0NvWT3AiBEaF8H98y7WrNBcrKN7p1EyXn9fbNEYrbqEFuqQod6XoxGlQGd3Hw0zNZ3HJueFHhgSz+y+NlkYJVWs4XQriAMQB1UpL4ftKb1K8XnaW2azZsYcSV4zhy7AR4pm2+l1Jq12MdHZ1aScghyfkZy9dZW6ZdIgTT048YuOLlJH58JgtrbORCnNLSzU/jsxn5nyQOZhpQBF9ZW6YV5GYsrTHLbsYOLeCH5TGAaBnfov/QvD3L51e1TKEQ6ZxuilXy4zMle3oVAYlxklaN3BEH4G3dp7DvmDeftZQrtZYjhFgnpbwEmN6qRRO++/Q1Rowe58s2FRGbt+7i3Cvu4sfJb9OkUX2Ar6SUBUKIGqPHOjo6FUtYrW1uxtLvpVTvAtiw28S1bybi0LYfQjHaNXHz07NZNK/v3cNXyK8TWqRFZ+KtEjiji5PUBh63qVCUiLLGVyaRjnRNRkjr7Crx07+Ti1NaRm5wAb5dEuOVVx4uyFim2egCeI3gXQA9unTkq/+9gMkU+ZI4gO279nDO5XeyZ/8h35++llLWGD3W0dGpWMIe4uRmLH8P5KsACzZaGPN6IjZtwajFaNVQLXQ1I8wo/GJtPuDU6JResQghGDPUN1qSo6p7xq2ahNMFUxd5N9+Q4j0g/EW+RRBCvAe8CjDs9D58/eHLWCzRCRJM33uA80b7Xc1m4BcpZY3QYx0dnYpFk18xJ33ZI1LyLsBv6y1c8XIiedqn6oJIbaAy9ZGAqGYDv1XHBBolcdVgGwZFIhAm1WSJLNmvjp+pi2M4cMKAlLik4vowWuUKIR7Bs4aX4YP78d2nrxEXG9nOWj4y9h3k0usfCoxq/k1PoKGjo6N5Mi83Y+k4n+H9428Ll76YxMn86AjVo42bz+8/6TNgDY0os6BzdIYhFUijFMnwnp6AKkVwaxWLUyvIs8Fr031pSOW3ebtXHo5m+UKIcXgN7xkDevHDF2+SYI087Sl4Nkm45o4nfQkeGgKzpJTVXo91dHQqjojW/uRmLB2H5HWAlVvNXPSfZI5GKap5WDcnb93izdWM6GJNTX41pBMjzEgVKdcM9Q35RbuaMCcdzSVDFcHzU+PZd8yAlLLAheuJiriG1/C+DtDvtK78/PU71KubHJWy5y/+k3se96tuF7wu7X8J1Vq3QqCmy69TDYl4wW1OxtKHJPJZ8ARXjXgmmT0R7MEbyJghdq490zNPKhD3xDcfMLzck6pgyVAgZ3V30KSOb/85We0DqipjyZBWflxp5oPZ3vSaQj5my/hzd0VdSwjxEPAsQPdTOzD32//RvGl09jH48tuf+XTKD76v90gpy9fj2kG11a0Qqeny61RDomIdc9OXjZeScVJKufOQkXOfSmbLXkP5J4bAy9flcEoLT4i0MIivrI0G1Y9KwRWEwSC4arBntCuFuJzWvZKqWKQayYotJm5/LwEQIFmal758YkVfUwgxHhgHyLatmjPvu/fp2K5VVMp++Nm3+WuLP3PlV1LKaq3HOjo6FUN01kkAuRlL37WmDjgmJV8ezDQYz38mie+fytacfciHxSR4944cznw8Bbcq6kuL+wWgWo8gxwy18caMOJDCYnVZxubCO1UtU01izloTN7yVSIFDQYLNpcirqSRXnxDiXSnlMeDLJo3qG3/95j0uvPoeNm7eHlG5DoeT2x58gYUzP8ZoNNTHk5KyWutxFIjomT1451hGjhii+fyrbn2MPfsOlX9g6ejuZZ2oEzWjC5CbvmxqfGr/TFB+yMwzxIx6LpnpT2TRo01khrdbKzd3XpDPxJnxCCFujknt96ItfUV6iQdX8ZwuQIv6KkO6Ovh9gwUEt1CNjW50NzyIDJsDXvomnnd+jMXr2csSbi607V2WUZlyCCGmSikzgR/qJCfG/DhlIheNuZf1f22NqNyNm7fzzsdfc99tYwBullK+KIQnJ3UtJSL3bNPGDejauZ3m8y3miGPWdPeyTtSJqtEFyEtfPie2Zf9hRpQ5WXmK9eIXkpn+eDY927oiKveBkQVMWRjDsWwDJqk8ZYMboyRymbjdEoMh/Hdv7FAbv2+wIIQ4NbZZ/z4F+5ZrzRdc63G6YPpSCy9+E+/POgVsdbjlefa9y3ZWhUxCiDlSymHAnJSkBOusyRMYec19rN34T0TlvvbuF4y59Dxf+smnKFmPo9VxDKkcKWULoHUUrrdFCBHV6HIve4FPQzy2KXBTlK5b5R14ndpH1I0uQEHG8mVxzQcMNRj4LTtPSbz4hSRmPZNF11TtI96EOMkjl+Tz0KcJSMTYmCZpz9oOLN0TRbFL5LN5sfTu4AzbTX7uaQ7qJbk5lm3AYBA3A9XS6EoUURXdeSkla3cY+XlVDFMWWTgStFeuXJR70n0hJ1aerALR/AghlkkphwK/JScmJM78agIjRt/Fps0h7ypYjNy8fF56+1PefO4BgLFSymeFEEX1OFqPJNRyxkBUtqQcC3wZhXKKstc7314uUso+RM/o6iNdnahTYX7F/L3LVrmlOgRk9sl8hcteTGLnwcguN2ZoAQ2TPRsjmMz8p8SDohi9nGeD12fEMXlB+AmmTUa46gxPQJVAXEnDrvHRkiuaRLpkyO2WbD9gKPGzdZ/CxnQDf24zMmetic9/szB+ShyXvphIu5vqctaTdZgwM85vcCVskKq8LDd92eCqNrg+hBCrgCFAdlKClRmT3qR1y6YRlfnFNz9x6Mgx8HR6S9ZjHR2dWkmFjHR95GesWGtN7X8RMO9otsF01WtJzH0+kySNuQcsJsEd5+XzzOQEpGQMTXrdwYE1UUrJUZwPZsdyJMvAd0ssPHdNDhZTePZ8zBAbE2fFgyDeaom/Oheilk2punA8R6HvfXUiKkNKFqjwWn7G0tlREiuqCCHWSikvAuY1qFfH9M0nrzJ01C2czMnTVJ7D4eTdj6fx/ON3AoyRUt4hhKgwPQ6Vw0ePc/oF4c/abF3xQ/SF0dGppVR4BE1u+vJFEnktwPb9Rm57JzGi8q4eYsdklAiBwWo0V9hm4SdyBBNneXoHWXkKP68KPz1g2yYqaad4ElMLodwcVQGjRFWs05VS/iVhgltyXk5BjjU3Y+nQ6mpwfQghFgHXArRv05KP3no6ovK+/OYnHJ7dQgxAtdj03uVyc/DwsbA/Ojo6oVMpYat56cu/Bh4HmLPWwoeztee3rZMgOauHz5CJC6MiYAm8PTOOk/mFt2fyAm1b5Yz1bYIgOC2+Wf8u0ZAtmkQzI5Uq5YMS95DCjzrY7aY3qJ1cTlfzHPJSctKXityMZV1y05fel5+x9BcOb9Q2XKwChBB+PT53WBq3XnuJ5rIys3OYu3C572tF6XFlBwLpgUc6OuUQ5F62thzwBAJTJAVKRFZe+tIJRf+ek770JWvLAcOEEMPGT47nrJ4OWjXUtlnMyP42flllAUTxEYKIfAeaA8cFH/3q29VGHkeIugs3mdl7VKF5/fCKv7CvnUc/dZOZZ0AYxG3AnZHKF02iGkglxcbcjBULo1WcZjGkfAIi02MgSwgxoegfhRAveaOah/3n0TuY8/ty0vce0HSB73/6nfOHnw4VN9KtbC+GHniko1MORed0nxCISLel3wNMKOkHl1RuMQq52eZULA9+bGX6E9piZdI6+fbcJSWhRdrAnD1Ll/h/lCiRvvqvTo/H5vQkZkC6TxfC+LeUgqmLYnjo0vCm3iwmweWn2/lgdhwCcS1t297Pjh32yCTUKYcngArTYzxJLTbHxlgsbz3/IKOuvV/TBZasXO/7b4qUcqAQYkkZh+vo6NQCihpdCdCyvpv6yeGN6A4cVzhwwoBAlupisu1ZssuaOuAlEOMXbLSwdLORtM7hr99tXEelVUMXuw8bURV5PlDYWEWYHGPnQYXJCzyjXCF5J2fPys3W1LRvBVw2ZWEMD16ShwhzbDh2mI0PZseBID7eUf+KPHZ8EYmMOuUiwbOv7ZFjmWGd2LRRfZo2buAvoySEELuklC8B44ed3oe0vt1ZWmhAQ+bQkWPsytjvi4YO1mMdHZ1aSVGjKwDuGZnHdWeGNxh74/tYXphmRVK2RcotyH09ISbhIQTxE2bGkdZZ22i3cws3uw8bEdCjyE8RGd0Nu024VW8VXM5XPAWqnwiUyzKOGvjjbzOnn+oMq8xOzd2c1s7J6u0mX0CVbnQrFgHw1vuT+WzKzLBOfPDOsTz94C3+MsrgdeAhIP7+28doMroAf/+zw2d0i+qxjo5OLaTy8/8d3pgnkV8ALNho5vhJbb7g1IbeZBVS1A36QUavTjn73ScB8tKXz5WSA4B/FBwuY4d5d0sSDLQ066s9t51OtUAIkYe38zR0YG/qpGjb12L3Hv98cN2yjtPR0akdFDVQEUcfluVeLryKeA9AVQVz12nLj9qyvtt7PSJbJBoaEuSnALP+tJClId52VH87CbEel73JaKhWwVS1kGhE0YZSxnsABoOBs4f013SRjL0Hff+tDD3W0dGpYooa3YijD8tzLwPk7ln6t5QcA9iUri0/R3KCd85ZyEoZIbiE+omUUtodghnLwh/txsfAxWkel72A66BXpNG1OqUTjSjacssQQvwNHj3uekp7TRfJzPJPr+gjXR2dfwFVtr2MEHI3wD97tRndeP8AWSRSCfXw7GokFgJ8pdXF7Fuzi0iKb2m+LDqS6VQxuwE6adx3N7/A5vtvopSyemz3pKOjU2EEveQCoQJIqX2gEJJ7GZCwCyAzV9u14mIKL2NtNKhSRgkSPgFYt9PE3xmG8g4vRo82brqmeoKwqmuGqlqCCoQdZV6EUF3UuwDqpGjLtJaXXxD41afH0ZAfQq9DtJJaRLxGvppTWL/IfSmh3vOIPGIBOhT4bGpLPWokQUZXCnIAXBFsfxuKexlAQAZAToG2p64G3Ppch6NS1r3mCdN0kNkAkxdqDajybYLA4JhWA1pGTzqdAHIAjIbwO0YBhKqYGQAJVm37WShK0Cvo0+NoyA+h10Fz02s0BsmYo7WcGoK/fpX4bCLCaPR7EgOfTW2pR42kyEiXbPBsJh4ucV4bJGRoASESYgAsJm2dbJt31Y6UUlbajjTpC21SMgXgmz9icIS3cgiASwfaiDV7A6okd0RVPh0f2QAxlvCD9ALcvaEGNsUA2O0aXhqCZJRCCJ8eZwNYNMgPmupQF4qNukMixhKUHjUr7AJqFlm+/xSpd8jkFfjvcbnPRkqZ4D8vX9t+GLExfjkDF6xn+f5Tw+tRIyk6h5QJkO8If2rJF5mLwBpakJBo7DlPm9HNtwvv5TihqQCNqNL9CcCJHIVf14TfKCbGwagBngGNlOIGPaCqQsgEiIsL3xuRU7hzkFVKGcqzaQxwMldbCukAGQP1OBMgXoP8EEEdNOyaVOQeV+q7WAUc9f0nPl5bwrOAZ9MkhMP9e0jm5GgzVnGx/udzPODPtaUeNZJg6yo9L/uRrPA9BqkNCn3SluaWFuUdL6TnYbVqqM2XfSTb7xap1J5P/p6VayRsBO1rdq8Z6nUxC+pZW1guip50Ol4yARrUC38Vzu7gPMrl6jHeRmd3xv6wrwXQsL4/HCFQjzXLDxHUYU/4dWhYP0jGGj8KKQshhArkQbF6h0xAnu7GIRzuN2hang1Aowb1fP/1d4hqSz1qKsFzusgsgEOZ4fv5u7ZyIYRn1GpUGFnWsfGt+jaUQvYB6N46/DSQAIdOeEUXVfAQVPkJwPyNZg4cD7+D0reDiw5NvfVW0AOqok8WQJOG9cM+ccNfW1ELAwZGlnWslLIh0Adg3aZ/wr4WlNqYZAE01iA/aKpDX4B1G8OvQ+NC+aEWNIghcAK06RbA2sJ7fLaUsrxAgFEAObn57EzfF/a1rPFxJFj9m5cXfTa1pR41juCRrmAbwM4D4RvdxDgY7t1yT0E8YW00qNSnqaiG1wTCZFAkF/bTNhe246BXdOmRuTLJNdonSaRTVQXTFmtzz4w90zvvJjlLD6iKOtsA2rRqFvaJObn5zFng33LvCSllWa3Sa4DJ5XLzwy8Lw74WQLvWzX3/DdTjbQCJCfHUq5scdplh1uElIMbtdjPjlwVhX6tta/9A+oAQIvxJ4ZrHVvDsqayFGT//7vtvHeCZ0o6TUrYH7vKdI0NbFBJE+zZBTo6tRX6uLfWocRQd6a4A2HHIoCmY6oGL8zAoEgQpxKh/x7foP9aX8jCueVqThOZpg6ypaQsQ4hqAa88soHEdbRHgmzNMQTJXKrvWZIOYATB5obZAhCsG2TCbJEIIYVS5Kary6awAaNuquaZgpNfenYTLE8KfAvwtpRwrpWwHIKVsIqUcJKVcAFwD8NnXMzl0RNtm7qd0bBMks5eVvv+c2rGtpnJLqMM13gYQKWVjKeUAKeXvwPUAX0z7if0Hj0Qi/zJNgtY8lgOc2knbc1mzYQvzF//p+/qQlPIHKWUfKaVnlw0pO0kp7wPWANjsDiZ+9LWmawXIeEAIkVHk59pSj2ju4fy4rDgu9V0kyOjmqYaV4EnPuGF3+EkrTmvnZsKtOZiMEgH1FUWZZDYatyWkpkmDgf0YWCxgMMBZ3e28MDZX0505li3IOOoRXZVq5RtdQLo9LuZdh4ws2xz+vaqTILmgt2+FiLiRKkxUUgtZCZ70jN01ZIpavX4z4x57GYcnPL0+MAnYJj3d9P3AYrx6PGfBch57/h1NQtatk0zLZv4pMb8ee0eMGwBO695ZU9kl1OELYKu3DgeApcAQgN8Wr+SR/7yt6TqndfPLVyXvYRWwFODUTm0CI2rD4pYHnuOf7bt9Xy/Co6+Hvc9mM/AmYHU6Xdzx0Its21nUzoRGnx6nBslchNpSj5qyh7NfzmBrsWdJJqlp24D2izaZ6dsh/PnWqwfb6ZLq4rXv4pm33ozDGXxPOjZzcduIAq4ZWqB58f+iv0x403C48vfEbtBUSITk7V02z9oy7YAQNJm8MJYBncNfPnbNMBvTl8UgBI3jWvQ7L3/Pih8rQNR/HUKITCnlNqD94IGnsXLtX2GXMfm72WzcvJ1H776e4UP6YzEHj5i3bNvNe59O44tpP2mWc3BaL9874MJrZANYCXQbMvA0Xn9P26ZUk7+bzYa/C+tQdAnVP9t389/PvmXS1B81uf0a1q9Lp/b+TFwryzq2FrEcwGI2M7BvD+YtCr+vcfRYJkNG3sIjd1/PjVePDJyv9LN4+Vqefvm/gXOnYTN0UO8gmYtQW+oRMc+98RGJCdaol2syGZnw/IO+r/4XrKQh2gqg/Zy1Zh4Oc8N2H11T3Xz54ElsDth2wEBWrkKsRdKivpuGyb5ra++gzF1r8ZWwEhZqi8SKHIlQPwbl6R+Wm3n5OkFCXHgN16BTHLRu5GLXISMGxXAzoBvd6LECaH/O0DRemfi5pgI2bd7B1bc9gcVipn2bFqQkJVJgs5Ox7yBHjkYez3HO0DTff1cKIYrq8Qrglr49u5CcmEDWSW05Af7asoMxt1dMHc4e6t/kQQVWR1RYDUEIcVJK+Rdw6nnDB2oyVuBZE/30y//luTc+pFe3zjRv0hCL2cTxzGxWb9jM0TD3gS5Kl85tadakoe9rsRFibalHNJg5e2FFFIvZbAo0uqWMdAG36v7OoBjGrttpYtt+A+2bak9PFWP2GGCIIMVVEXIL4Kc/PT12VfBd1ArWgOpWPlAU+VSBQxEzllv82aZCRQjBmCE2/vO1FSnleXEtezXOz1hzsPwzdULgO2Bsr26daNemBdt37tFckN3uYNPmHdGTDIiPi+WCs0/3fS1Jj2cCdrPZZLnkgmF8MvmHiK5XEXW46uJzff/9UQgRnvLXbL4BTr3kgjN59D8TsWlMjALgdLpYsXpj1H3z11x2vu+/uym9Q1Qb6hHNOd2KxC9nsXnE/D0rfkTKnQCTftPm669IvvkjhgKHApK8vFxPLuSqIn/v0gMg5gNMXqDtXl052IZBkQghFIUYPaAqSgghfgR2Alx/ZfVbCj161Nm+Bf95UFyPhRAnwJP97Pqrqp/8Hdqm0r93V9/Xt6pSlirgv4AtKcHK5SOHV7UsxUiwxjH64rN9Xyd41+WWRG2oR42b0y0xeEcV8h2Az3+L5Vh29amT0wUTZnrmDSTyU44trfI8nFKonwKs2m5m677wY6EaJkvO6eXpYQohb6TmKFFN4B2AG666iLp1kqtYlEKMRgP3336N7+unQojS9Ph1gK6d23HO0AGVIluoPDzuWt989BYhxKKqlqcyEUIcxxOYxkN3XVs0/3SVc+eNV5CcmACePMUflXZcbalHTaNEK5F3Uv1MSplf4FB44Rttidwrgg9mx7DvmAEppXRJZUJVywOQh2WGbxOEKQs1rtn1u6VFy/jU/tWvy1lz+QzIj4uN4akHqo8T4fbrLqN504bgcTlNKO04IcRmYBHAs4/cXm0axV7dOnHJ+cN8X9+oSlmqkAmAbNmsMXfdNLqqZfHTrElDxt10pe/r+yGsnZ5A7ahHjaHkodmJlSeRPAow6bcYVmyp+vTAuw8rvOTrAAgm2vYs2VW1EnlJX2iTUnwFMHWxBZeGsK5h3ew0q+eZ9xZS6BmqooR3A4FHweNi7nda13LOqHhSmzfhifv9HYCJQojy9Ph+gE7tW/HAHdeUc2jFYzIZeeelR3y7I60WQlTpFE9VIYTYgsc9y+P33qg5yUS0eeelR3xRxIeAF8s7vrbUoyZRqj80d8+ydyRyLghufDuBwxryMUeLfDtc92YiBQ4FKeVfuelZD1eZMCWgon4CcDTbwNx14SdjUBTB1UO8o13BhQlNetUr+wydUBFCvAPMFULw+TvP0kBjrtloEBtj4av3X/DN5f4FlKvHQoi1eDsOj959PYPTTqtYIcvh9fH3+ZIV5AGXV6kwVc+DwM4Yi5mvP3zJ5wqtMp564GaGnd7H93W0ECIrxFNrSz1qBGVPQtoMY5BkHsw0cOUrSWRp20glIhxOuHliIpvSTUikw+lyXQKbtYfZVQD5GcvX+TdB0LjP7tWDCxBCIhAmzJYboyqgzhggs0mj+nzz8askJUZ/TV55mExGPpv4LF07twNwAJcIIULV41eBRQaDgUnvPUeXztqyCEXKfbePCQzqulcIsbus42s73ojtKwC1XesWTPv4FazxxdeqVgY3jRnFQ3dd6/v6Xjjz7LWlHjWFMo1u7qE/jrqR1wCs32Vi1HPJmnYg0kpuAVzzeiKzV/sig8U99v1/Vnqu5ZCQnon+uWvNmrwCzepJzuzmb4Nvj6Jk/3qEEEfxpmzs2bUjs76aQP16KZV2/fi4WKZ88BIjzhro+9M9QoiQ9Vh4dhK5GjiWkpTAT1PeoW/PU8s7Lao8du8NPPvwbb6v3wkhPq5UAaopQog1wH8A+vfuyk9TJla6N+XBO8fy5nMP+L7uwjNyDYvaUo+aQLnhtvkZy352S3m+lLJgw24Tpz+SwqJNFT/HuynDyLDHU5i33mtwVXlLbvrS98s9UURz3daakLepzxV5XwG4VcG0xdpGu/5NEBAtran9zwAQqFGsj7tYWRVdfnVBCPEzcD5Q0KNLR5b98jlnDOhV4dc9tVNbFv/4CWcP8SeSuEUIUb4eF0EIsR/PbkDbUpIS+GXqu9x14xWas7qFSp2UJKZ9/AqP3XOD70+ThBCXhXh6tPQhnHKiqYMhlSWEeBbP5hf07NqR5b9M4swz+kZRjJKpWyeZaR+/wtMP3uL701/AYK1rpmtoPaptm1OE0tfplkR+xrKfpWCAhENHsgyMej6Zm95OIP1I9NMFH8sWPPJZPEMeTWb7ASNAjuqWZ+fsWRZayLiM5pKbMDaYT1+fJaX8GrS7mM/u4aBBsjeRiBS3AkiUKNbHUKysii6/OuE1vAOAQw3r1+XHyW/z6cTxgfmPo0bdOsm8+sy9/PHjJ7Tz7MSTA5wthNC89MEbdNUP+MNkMvLik+NYNOtj0vp2j47QAZjNJm677lLWLZjKucP8mbOeFEJcF0Yx0dKHcMqJpg6GXJYQ4mHgOoD69VL4/vM3mPLBi7QL3iEnKsRYzIy7aTTrFwY9m1+A/kKIvZGUXQPrUa3bnABKz0hVGnnpy9bHNut/msGgzBWCzt8vi+GHFRZGnObg6iEFDO7iwGLSVn+3W7Jyq4mpi2L4dlkMdoenHCnlfqR7eN7elZtDLkygbduiEgl9pOvlY+DK7fuNrNxqDDt3tdEIV51hZ8LMOIQQV9Ks/11hXl+nHIQQ66WUpwFzgc6XXnAmo0YM4ed5S/jym59YsHS1b5OAsFEUhX6ndeHqS87lsouGB+Y63g8M9y4BilT+TCnlMDzrK0d3P7UDs6e+y5oNW/h08g/8PO8PTmSd1Fx+h7apXHbhmdxw1cjAbQUdwJVCiO8jlb82I4SYJKXcDswC6p4//HTOO2sQ8xat5ItpP/LbopXkF2hP3NW1czsuvfAsxl5xPnWSEwN/egt4sIwkGGFRW+pRXdFgJTubE1qmjEXwEODfwiU+RmVARyc927k4taWLZvXcNElRscZKYswSIQQ2B+TbBQdPKOw9pvDPXiNrd5pYttnIidzCNYhSckDChLz8zP9xdHNYWxFZUwdMEIh7wq9XcXLSl4Z9fxJSB+wGkRqN66uo9wqp7BWC6VEpT2V43p6l8wL/Zm2ZdnFFll9dkVKagbEQrMe5efks/XMDazZsZtOWHezdd4gDh4+Sm5vvT5NnsZiJj42hUcN6tGjaiE4dWtOraycG9u1OnZSkwMscwLMO8n9CCG1bapVdh7PwRDYP9f3N7Xazat3frFq/mQ1/bSN9z372HTxCVnYONrsDVVUxGg3ExcZQv24KzZo0pH2blvTo2pEBvbvRumXTwEvk48mW9aoQIuzdx6WUG4EuEVYTYJkQIq38w0BK2Yfobb4wRQhxdbgnSSmTgQeAcYBfIWx2B8tXbWDNhi1s3LydPfsOsv/gUU7m5GKzO5BSYjIZiY+NpUH9OjRv2pAObVPp6X02ATmIffwCPCOEqJC81zWhHlLKOsBx7bWsNC4XQnwLkQ3NhbVl2igh5CMg+pR/uAzlcluRvJ6TYZukYZQJgLXlgIlCiHFazi1KTrrNHK4c1tQBzwjE+GhcH+R2KcWjutGtOKSUAhgFPAKUq8dSylDmUbfiySY1SQihbdgcBlLKHsATeOpR5pxPiPKfAN7Fk3pPc8b6f6vRDZAlAY/Bug8odxlgiM9GAjOA8UKITVplC4fqXI9/m9H1E9u0bzNhULorCr0FSg+k7IQQ5axrkBkgtqiwXki52qmy3r532c5IZbE069/WZJTNIi0HIDd9xcKwT0rtnmwlpns0rg8gHM6/pNkUlVDVXNW4gT1LghrRhCa96lVk+TUJKWUzoDvQG+gBdALKW5+TAWwB1uNJyL5eCBGxHmtBSpkI9PJ+euKRvyNQVpDBETydhI3AWmCdEGJdlOQ5DYjG+qzsUGXyGohoRcgd9iaPiAgppRHP80gDBuKJK2gU4ul2PHq11PtZ4s3LXelU13pIKQdHo5wK5m/vKoqKnYS2NOvf1ihEa6GI9hJpkYgtBqHuyklfrn1zRR2dSkZK2RZojccNbcFjZHcJIWqEHkspm+DpPLTDM1LZjWcziH+EEFWw+l5HSpmEx2A1Ahp7/43Fk4HpAJ7O0EEhxKEqEzIEaks9dHR0dHR0dHR0dHR0dHR0dHR0dHR0dHR0dHR0dHR0dHR0dHR0dHR0dHR0dHRqH6UuGbrjiqRbt+x03nXwmLP5P+nOpNKO09HR0dHR+TcTFyNkm2amE03qG3ee1tbywAtfZi4Jq4BLh8WvwpMxRP/oH/2jf/SP/tE/IX5iLELedXnSe5RCsZHu5Wda13zzW25PgDfvq8/ZA+Jp38Jc/EwdHR0dHR0d8m0qO/c5+eLnk0yYkgnAnZclffjet9m3Fj02yOjee2XiGxO+Pnl/rEXw+/vNOa2zti3qdHR0dHR0/o1Mm3uSMU95EnC9fFfKiEffzZwd+HtQcvSflxaMA/jk6Ua6wdXR0dHR0QmTK4Yncv/VKQD8sd5ezM3sN7ofPELS9j1OU5P6Ri47M6ESRdTR0dHR0ak9+Izu0vW2VkV/8xtdu4xNAOjSVp+/1dHR0dHR0UrDukbqJCpk5ar0aEv9wN/8RteRJw0A9ZMNRc/X0dHR0dHRCYMWjUwAuA3B21uWueG1jo6Ojo6OTvTQja6Ojo6Ojk4loRtdHR0dHR2dSsJYWRfatt/A/A2FQVp92jno1c5dWZevsUxbbOFEbmHf6Jaz8zEYSs3eGVV+WG7mYGbhHP/1ZxYQU83i7KSUvD87zv+9jlXlitPtEZfrdkt+WW1h4SYThzINWEyS009xcN1ZkZetUz3JLYAvF8T6vzer6+aCvo4qlKhkbA747LdCORsmq1w8QNfLmkLIRvfvDAPrd2u30SdzBU98WTif/PjlufRqV6C5vGihqpJpf8SgSs/3OvGSc3uX/qJt2G3gr4zC+9C9lYtTWpbeeZi3zsyR7JKNpBCQEq/SKEVyaksXphJu79sz4/hnX+EP159ZgKGSYt0+mB3Lyq2FVvbygTZizLJyLh4ibrfgiUmFetWxmStio3skS3Dlq8ms22kK/nu2UqlG91CmCOqoNklRGdLNWerxG9MNbEov1JUuqS66puod21DJzg/WpdNPdVRLo5tnC5azV1tnmUY30jZIJ7qEfIvnrTPzn6+t5R9YCreem6f53Ipk8V8m7vxvov+7QZH8/b/jNEgu2bj8uNLCmzPi/d+fvjKXU1qW3nl4c0aw4SqN5HiVi/rbefKKPOomVi/D9m/jlncSixlcAGMlT8b8s9fAuP8V6ubQbvYyje4vqyy8+l2hbj58aR5dU/MrVEad6o/eBlUv/vVzulMXB2fecquCb/6wVLocWXkKk36Lpd8DdVi7Q+9uVhWbMows/quwgRJCMvp0Gy9cm8tVg21VKJmOTsVSm9ugN76PJfX6uv7P7FVVN08W8p1Ntqq0augq9vdjJxVyCgptd70kNwkxxXtJlmrmlgTPHM6PK4sb2KmLY7jrgoppYJvUcWMxFd6LgycUbM7C+3f8pMKY15NY9PIJ6pcy2tapONZuD34lxgwp4O1bq6eXRkdHC//GNqjAITiZX1hHRxXOuoRsdK870851ZxafN7j7fStfBQQfPHNVHlcPLn7ctMWVP3osjx9WWChwFB/sb95jYt1OAz3aRP/JfHb/SXq3K+y8uN2SX9dauPt/VjLzPJO1hzIVPpoTy+NX6K7ByiY7L3juq0eb4h1NHZ2ajN4GVS1V7kOYu9bMgo0msvMUGqS4Obeng74dS27oVFUyf4OFVduMHDihEGOWdGrm5tzT7DSpG36P7OtFha7llHg3mXkKvo2Xpi6OoUebih/hGAyC83o7yMnP446AueXvl1lCUvjjJwVz1pn5O93AiRyF2Bjo1MzFiN52mnrvyfYDCsu3FLpTGtdROatHcICIywVfL45BBtxGWcIt3ZhuYOZyCwdPGEi2qgzq7OTsXnYUpeRAjZP5MHNFDNv3Gzh2UiEpXqV7axfnnGYnKa7EUwDIOKLw058WMo4YyLMJGqS46d/BxbBu9rCit6WUfLfUQoG9sHPVrJ6boUXmRldsMbHtgIHVO4LncldtM6MIz/WG97TTKKXwpqzebmDhRjP7jhuQUtKivsqQrk56tg3W34MnFOatK7z/Azo5aFxHZfKCGDbtNtK6scp9oyqncXO5YO46M+t2GTl4QsFiknRo6ubsXg5aNlCDjv11jYkjWZ5GOCle5aJ+Do5lC2Yst/D3HiOqCu2burh8kN0fA5FbALP+tLBuh4k8m6BpPTcX9LWXGtCl5Z3+K93Ab+vN7D6s4HAK6iSodG/j4txeDqyxJZ7CzoMKc9Za2HHQgM0uqJ+k0q+Dk+E9y9enjekGZq2wcOC4gYQ4lf4dnVzQp/TztOpuqPoUbUJtg2wOWLjJxMptJo5mKSgCUhu6GdrNQffWwc83UHessZKLB9hZs93Ad0tjKHAIbhheEKQTG9MN/LbOzJ6jnrq3bKByVk8nXVoW1j3fDt8tKWyzu6S66NHGxeY9Bn7808Leowomoyew7NI0OzHmwvf6r/RgU7foLzPZeQr1ElVGeANnVVWyaJOZpVtMHMr0tBeNUlT6d3Iy+FRH1FaNVJnRzSlQGPV8Eos2BfvWJ86MZ+ywAibckhv09zXbDdz6biK7DhUX+Ykvrdw/Mp+HLw294Uo/orB8S2EDe3Gag78yDP6Ag+lLLDw3Jg9z8XiaCuGc04K9AxlHDLjdpXck3G7Jy9/F8+5PcdgdxZXh8UlW7r4wnydH5yGAez8s3MQiJd7Nto+OBynRiq1G7vmg8JiOzVwkxQc3wq9Oj+OjX2MJ3BHy/V+gRxsnUx7OpmERV9TEmbG8Oj2OfHtxb0JSvMrTV+Zx/VnBbvw8Gzz4sZVvlsQgZXC93gZaN3Lx7m259OtUekBRIC9+E88b3xcGFyXFq8z+T2ax46YssgR5bHx8vSjG3zmb9bSLRikudh1SuPWdRNbsKK4cL0zzRL3+946TfqOxdZ8SdP+fGp3H9GVmNu/xnN+6katSjO78DSbu/l9C0DIwH098IbnuTBvPj83BYvLc97dnxvnfh0YpKoIc7v4gIchNBzDhhzi+eewkUkqueyuJ/ceDy3/j+zieHJ3H/aOCAw7Dfaez82Hc/xL56c+SvWaJcSrPj81lzJDCd8nhhEcnWZn0W3F9eudHz73/6O6cEj0aUkqe+Sqed34M1vmPfoWebZ18+1g2KdZCndequ+HqU0VRWhtkMAimLzXz5BdWDmcV153np8K5p9l5746TJHtftUDdqZuoklsguO8jq/++DOjkpGuqm6NZglvfTWThpuJzrM9PhYv62Zh4ay4JcZLMXBH0Ht0wPJ8Zyyy893Ns0P2e9Fss78xyMfPprFLf68/nef7WrZWTEb0dbNlr4JaJCfy9p4QGfwa0beziv3ee5LQoLHOtskCq936OLWZwfXwxPzbIHf3HXybO/09KiS8ngMMpePnbeMZPKWPoVISpi2IIfJFG9rcxsl+h0p3INTBnbeVNtnsiYwtfKrcqcKul96zu+TCBN76PL9Hg+s5/64d4Xv42jrZNVLq3LnzRM/MMrNoWXLc5a4MbsksHFp/T/ujXOIpswQzAup0mrngpCVdAu3X/x1bGT7GWaHABsvMUHvg4gVe+K3xmNgec90wy0/6ILdZo+dh1yMiFzyWycGP5/cWvF1mCDK7RoDLp/pN0bKaWcVbZbN2ncObjKSU2kD4W/2XmrCdSOHC85Dq8Nj3Wb3CBSlkC9u0SM5e/lFSiwQWPvnwyN5bRryQHPUcfh7MEN7ydWMzggudduXliAle8klzM4HoQPD81nnU7C38L951WVcmVrySVanABTuYr3P1+Il8t8BwjpWTsG4l8Pq9sfRr5XBJb9xWv19ItZt75sWSdX7vDxDNfFeqWVt2Nhj5Fi9LaoMkLLdw8MalEg+tj9moLY15PQpbgHsvMFTz0qTXovhgNnqV5w55IKdHg+pi5IobLX04sUSenLIjh3Z/iSrzf2w8YeeKL0FbbHMoUXPBscskG18uOg0ZGPpfM5j2Rv6xVNtJVVUGXVCdn9XBgdwpmLLNw4ERhhSbNj+GK0+3k5Avuet8aZFz6dnBw+qkODmcZmPZHjP+3iTPjuCTNEeSSKAkpJdMCXMv1k9z07+ikdSOVx7+Q/of49aKYSlunN3edhcCXu0kdd6mj7DXbDUxZGLg43s34q/NIbehm+RYTL0yL9xvst2fFc8f5BVySZmf9rsICf11rCupxzy3SwRg1wB7kEvUguaCPnY7NXWzdZ2TWykKZN6ab+GqBhevOsjN7tcnfkwTPMqzLB9lp3cjFul0mfllV2HC+8m08Q7o66NPexfNT49mYXihjHaubK063kRQPs1eb2bDb85vLrXDzO0msefs4caW8r0s3G4N6xQBv35rL6aeWPEK+bKCdLqkuFm4yM3t1oXyXptno3d5zTssGLq57K5msvMIGun0TFxf1t2F3Cr79I8Zv1A5mGrj7gwS+e/xksWsFBq0AmAyhjWB2HTTy/NTSO5bLtpSsMPuPCx76JCGocRrcxUFaZwf7jhuYtsjil2nRJjPv/hTLvSODR6VSChQhuXxQAakNVTalG4Pu0+7Dnqako3dqI88mmLY4JuBeCf+UjZZ3et9RwYp/Ch/20G52nrk6n8RYldmrzTw+yYpPF8dPtjJ6kJ0vF8R63ysP8TEql6TZqZeo8vOfFrbu98icU6Dw9JdW3rwlJ6jOqipolKIysr+NOItk4SYzawOM4zdLYnj5+lziLGjS3XiL5I7/JkasT9GipDbIpcIzXxZ2LhRF8tToPPp1dJJ+2MAzk+P9buRlm83M32DmzO7B75iqCtQi/VyTQfLAxwnsO1bY5qc2cHNhfxsul+D7ZTF+F+/KrWY+mRvD+X2DR+I2p0KdBJVLB9qwxkiWbjYFLY2atcLCVw9m0yXVxZy1Zn7fUKgLY4YU0CXVRb1Eybs/xnEip/AZjLsgn+vOKsDpErw9M87v6cq3K7z4TTxfPRjZM6gyo3tWdztTHs72uzjvOK+AHnfXweH0fF/nNRDfLrGw92ihmJem2fhg3EmEd57tkgF2Lnou2fur4LN5Mbx5U7BruijLtpjIOFr4sC/o65mTbFxHpW8Hp//lnrfOzNEsEdUIvrwCyAqYKj6abWDhRhMvfRMfdNyIMhJ0rN1poo610M3xxOg8f0KIvh1cbNlr5Fvv3IfDKVi1zcSo/jae/ire3/D+utrC+Ks9rrtdhxS2Hyi8x73aOmnVsPho8M2bcoKSQ0z6zcl9HxUatq8XxXDdWXbenhlsGD6//yTn+etTwFsz4nhuamF935oRx4fjcvgkwFAnxavMfynLP8/44MV5XPFKEvPXe16c4ycVvpgfw23nFh+R7zigMPb1RJyuwgbk4UvzuPKM0hMIDDrVyaBTneTZRJAxGXiKk7HDPNdYsMEUtH63V1snP43P9Ltj7zq/gDMeSfE3lL9vsASN7gIZO6yAq4fYqJ+k4g7RY5V+xBC0RjxUPp0bGzRCvfXcfF66rlAJRw+yce4zyfga3Imz4rjz/OJrzz+6+yQj+xfq5Q0TEvhheWHntWdbJz8H3I9zejkY9Xyy//eNu7W/0/USgvXxiSvy6OJNSnPbCBu/bzDz+0bPe5uVJ9h5SOG9n4I7frOezvIHRz50SR7DHk/xexzmbzSTU8TD3zjFzeJXM/1rVh+/PI/Bj9bxJ8dxOAWb9xjo0FTVpLuntHBr0qcW9bV7aiC8Nmj7Ac+1fe3NiN4O7rnIoxt9O7iwO4Ndvks2m4oZXYDm9V08OTqP7q09A6KcfMHPAZ3vNo1c/P5SFglxnnt970X59Hugjt8YfvpbbDGjWydBZdErJ/yxKwDDHi9MauNWBcnxkrN72TicpQQZ3WHdHVzUz6PLH80p1OH4GJVnxxTenAm35PDzKjO5Ns8zWbM9cpNZZUa3d3tn0Jxi4zoq7Zu4/QptdwhO5sOMFcHupMeuyPO/nOBpLFs3cvndVMv+Ln8SdurC4LW5FwWMZkf1t/uNrlsVfLs0hjvOi17mrItfSCn3mDoJKg9cXHoQ183n2Lj5nNKXNHVoFjzSP5at0KS7pH8nJ8s2e+q27YCRXYcUWjdSi7mWL0krueyio/6xwwp4+ds4v9tp/W4TGYcFf24rfAbdWjkDDK6H20bk897Psf4XasEmMz+tMgWNfMYMsQUF9iiK4PHL8/0NF8Cvay3FjK7NIbjm9SR/FCbA6NNtPHpZ5HOmM4ssL3vg4jx/AwlQL0ly24h8nplc2AjNWWuhX4fg+p97mq1YzEJFMivgHTIosljsQ9+OLob3cPhHhVl5Ciu3Fm8aBp0S3Jj2be8MMrqXpNmD7kef9sHHZ+Z4ftPyThddI/35bzG0bZzvb6S/eSx49LHrkBLkuh7a1RG0GsFiEowZYmP8lMJjDp4I9kC0a+oOShKhKIK0zo6gjHRHswzsPmzQpLs7Dgb3tkLVp5vPjqw9CqcNapgs2fHJiVKPK9rWnMgueTrpywdPBgVOBU4rAdwzsvBZgqfu5/W28eXvnuO27zdy/GRw2R2bu4IMLkC/Do6gjszxnPJnUK0xgfPyCp/Ps3DNUBsGg8BkhPTPjpdbRjhUefRyIPExwT04p0uwZU+hiEaDyoezi0+KF9gLFXXP0bJvcr4dZq4sbCjqJbkZ0MmBr5d/YT87j35eOP/w9UJLVI1ueTSt6+bLB4sHJZWEzQFz1ppZutnMrkMKJ/MVnC44khV8D3zxWJem2fxGFzwv8O0jCpizJjgZxKgQ87gKITg11cXh9R4D53QJVm4zEeii6tOheK831gI92zj5zdsIOZyCVduDO0tFG2zwLN+JNav+ZV5b9xVX3/QjwSPLVg1dvH1rTrHjtLBtf3DZfdoXn8YYUCRIZus+A/06BB/TpI42z0ndRJVebUoPINt50MDOInOkLhfsOlwod4dmrqDgHx8DOjmDXLEl3duixJazCrDo705vm6vlnb6gn50Xvon3ey++/D2O75bE0KeDi34dnZxxipM+HRz+KPqiz6pTCVNOt42wcduIQmO+P4Q50/giOQgcbo9BCCRU3S3qcg1Vnyqa0tqgZZuNzNtgZuteI5m5AptDkF8kpsRdynx20zrBld1SZG508SYzf2cE38fNReZYQ3k+pelcWVw60O5viwDu/ziRF76xktbJs5JmWDcH7ZtGb/lotTK6RXG6JCdyCm+0y63wweyyg6VsTo/hKS2H6KwVFr+rAKBHKxdrdwU/3PZN3P75nr/3mNiw20C3VhW3mloISafmLi4Z4ODGs/NJDCEe7I+/TNzx34RSAldK5sK+Dh7+VMXl9rz4v642MWawjeX/FNZ/0CnOkAy+j6S44GP3HQ2Wp35iya6wxnWC7+eB48EdhfqlpKFrXEdl1yHPsUV7viWx+7CRJX+bykyfGCpHAzoziiKpk1BcxsZFGpejIcgYKt1aOZn6aOnzSS9/G8er3wUr/tGTStBcbr1S7mujCpQ7EKcLTe90s7oqH407yR3/TfAH5xU4FBZtMrNok5lXvvV0sJ4cnc+oAXay84LlTyplKVE0OJKtTXeT46pWnwIpqw3ad0xw44REVm2PXmDp4SIDg++WxpRyZCG5toqp++WD7Gzem8fEmYXu9eMnFWatjGHWSngCGNDZwfPX5BZbGqWFam10PYQfsedWoTQnc9G0j/PWW5i3vuwu+9eLYujWKjprdj8Yl80pLTwPTgiIs0jqJ6nEhZE7ZOs+hctfSfK7tISQnNnNQdfWLhJjVZb8bS6xTnUSJEO7Fo5olv9j4ocVlqC5z0vSwkvob3cGP5+iGyKUFr2suoPPMxfpO+SXMqXtDjjPZAytc3D3Bwksef1EmeuCQ8EYIKOqCuxOGeQOBIpFnFtClLGiKBqkVVDK43UX6RtZNLQMJa3rLhlt7/SF/Rz0aJPJf3+O5ftlFo5mByvN7sNGbnw7keMnc6iXpBY5v+Keg7HIPQ5Vd6tKn8Jpg2wOuPj5ZHYcLFSIrqlOBnd1UCdBsv+44l3VUPEU1dFoMv6qfM7r7eB/P8cyZ425WNKkZZvNnD8+mZlPZUW8O161NromoyA5XvVH91nMkr/eOx6UwqwkStt+bt8xwR8hzPkW5bslMTw3Ji8qO3CkNlTp3CKyh/ZekbW5r92Qyw3DC91kblWU2pG4OM3uN7out8IL0wpfGJNRckHf8NJfHjsZ3Ci0bBBct/3HSza6u4uMiJsXOc8T1Rg8OnU4Yf+Jwus1TC75LWzfxEWnFi5mrojxymDgyc+tvHNHZPOoDVNUtu4PlrFN42AZMo4E1zccr0FFkGJVMRmlv2MVGC0aSEYRt3z9ZDeld121YzIS0TvdvL7KS9fl8eK1ufyzz8jSv018u8QSNAr7z9dWPr03K+j8I9kV55ZtVEQPQ9XdqtKncNqgmSssQQZ31AAbn9xTOF2zartRk9Et6nH55rEs+pUwFRVIZm7FLpnq3c5F73tzcLpg7Q4ji/4yM2WhhT3eoL98u8KzU6zMeiY7outU+w0PAudH7A7B7DVmrLEU+xzMVDAbKTUjDcC0xcUXrYfCiRyFucWWz1Qdm4pkV7l8UOiGcsRpdmLNhS/2kYC1d2d2t/sXt5dEQZEefHY+bAzY7jEl3pPpKXAEOnedmbwi4h3N8kRU+6if5GZ4j+AX7oflxTsNv603+13jgH8pTyB1ElRmPpPFmzfnUj+psGGZvCiWOWsjMyJFrzdzRXEZf1kd/LeSZKxMDAZBz4DEDwczDSUGSf26Oli/S5pfjBZa3uknv4jnoU+sPPSJlc/mxSCEoFNzNzedY2PO89lc0KdQyXJtAovJ47L1sXxL8Tq/MyuGRmPq+T+7D2kzzL2L3KtQdbcm6FPRtuayEtbva6FP++DGZPoSS4k64JaeaHRrLChRtFY+r8zeo4pfrx76xMqiTSZMRk9w4cOX5rPktUya1y98vmt3Rj7yqvZGt2jU4qOfWZm6yOJfhO10wfSlZs59OoXb/5tQ4uJsH9OKuJa/fyKTI5OPlvh55frg4JspC6tP7uiiyRRWbC00JrsPK3z5e3A9A2+JNRbO7lWy/+uStLLXJD/0SYK/t5lvh4c/SQhywwzt5iTWAhf2KfRhZucpPPxpAvneP53IEdz2XkKQS/vKM2ykdXLSrF6hkVy4ycwnc2L8z3PLXgOPfh682H10CfvmNkhSaZgsSbFKXr4ueErg3g8SIuotXz7ITmDygHd+jGNFwNrYH1ea+WRuYa8v1qxyYd/w3PUVwRWDggMBH/nUyr5jnvvgcsGzX8cFrTHt2dapKXAkVPeylnd68V+ee/vJ3FhemBrH4azg51i0s52cAGd1L9Tnv/eYePnbOH+Wt817DLz3cxwOp8DhFFiMkqZ1tXU0tOpuTdCnoq7zwLYmt8Cz3C+QUHXgkjQ75gDvxrQ/Yhk/Jc7fTgD8uc3Ihc8mc8mLyUFxAFooOl2yapvnD/Exkk/nxfh169XpcUGZAGNMwVNf0fB2Vmv3MnjW0A7u4vBnLcm3K9zx30Qe+NhK4zoqhzIV/7zhjGUxdEt1cfdFxaONV241BrlJ6iW5GXSKs9R8mhf1s/PYJCuqd05l3jozx0rZCLqyGXiKI2iR/lWvJpLW2YXTDX9uNQb1qIFiWYQuTbMHLfUAT+T4Ob3KfqHnrLXQ6TYzzeq6g+67B8ktIzz3/ZHL8vh1rZk8b+DD14ti+GG5mSZ1VPYeN/jXYoMnveC4CwowGuGZq3K5eWKS/7eHPk3gpW/iSIzzpO0MnAsc0tXOWT0cJWaq8TFqgJ1vl9j5dY2nw3Q4y8Cjn1n5YJy2aOZ2Tdxce6aNSb95GsLsPIUR45NpVs+N00WxjD0PXlxQLfYlvXKwjU/mxvoz7mxMN9F9XF1SG7g5dlIJ0g9FkTw3pmKXM2l5p285N5+73/fkBT6Ra2DQwymM7OegToLKpnQDs1cX6nNqAzenNHfyyGV5zN9g8r8Pr34XzzuzYqmXpLLvmCHI63XLuQWYTdreb626C2jSp+MnK68dGniKk4mzCr9PnBnP4k1m6iaqrN5uKhawlp0fmmxN6koeHJXHi98UdkYmzoznvR/jaF5P5WS+5zn7uO3dBN66RfsqhNaNgxuK//0Sz5e/xxEfo3L5QBvT/vA8g+VbzJzxaApndndgNMD89eagFQHn9Y6801PtR7pCCD659yT9OwWPwgocnnV4gQ1/h6YuRp9RsvsjcHMDgPP7lJ3AukGyZEDHQleOy63wbQgRdpXB3RcUkBowB+pye6I4l232uLASYovOMQU/5jO7O4rlVR5xmqPMYK46CSrJ8SoOpyh23wHuvijfv3NJ2yYqn9yTE+TGLnAo7DxkDDK4dRNVJj+U7TdMl6Q5eOSy4NHpiVyDdxlQ4XndWzv5METD+dqNOUH349slMfwcwV6aL12by5ndg1+8fccMxRrIMYMLuHdk9dgS0GISfPHgyaCtOVXV8xyLGty3bs6lfydtI76yvEyBaHmnxwyxc8PwwvXFx7INfDwnlle/iw8yuIlxKh/cfRJFEXRv7eatW3KD3MwFDoW9R41BBndoNzuPXBLZOm6tulvd9enM7k5GFDE063eZmL/eQnZe+W1NWTxwcT63nBt8392qIP2IIcjgJsap3D8ysmWbw3s4qVtkJUWuTVDgELx6Qx692ha29Zv3mJg4K543Z8T7M4mBJ9vas1dH/gyqvdEFSLFKZj6ZzavX59C2cfEGoWV9N09ckcvCV074dzsJxOYoPl8SmGe5NC4ukiTi64XVw+jWSZDMfi6TC/vaEKKwvgbFs+H6L89mEei2mlckxaPZBBcUeZGK1rUonZu7mPV0Fj3bBs8p1U1UefHaHMZfFfzyDO/pYMHLWVzQxxbkRgLPqPqqwQUsfPlEsUTzj1yazzePZdG7nSOoDuBJd/nIZXn8ND4r5BFk07qSp68MflHu+8iqebQQY4avH87mletzgjo+Pjo2c/H+XSeZeHtuUMKHqqZVQ5V5L2Rxx3n5pMQHy60okjO6OJj9nyyuGVox+0gXRcs7/fqNeUy6P9urg8HPP9ascsWgAha9khm0bd3Vg+388mwWg06xBxlf3zWeuyaXaY9kY4yCz0+L7tYEffr0npPcMzKvWB6Fvh2czH0+M0juTenGkHNECyF4+bo8pj2aTb+OjmLPJzleZeywAla+dSLkDU5KIyFOMvXhrGK6ZlQkCXGSX57NYvxVuSU+gwbJbu4flcfc5zOj4rny353X74xp+eB7tvQx5ybw2fjGERdckRw8obDvuIKqetaxRZoWrSaTmSvYtt+AEJ5t1soKhArk3g+tfDHf41JJiXfzz4cnQp6vSD+icPC4QlK8pENTV7lbXuXbYcdBA7n5gqR4SbsmpeeVDuT4SUHGEY87ul6SmzaN3dXKkIEnccPBEwqKAs3qqsXWVVZHVFWy/YCB4ycVYi2S1o3dES+nipRw3+njJwV7jirk2wUpVo9Olae/WXmw+5ARu0PQsI67xFSn0UKr7lZnfbI7JZv3GLE5BC0auItlg4oUz/MxYHMI6iVJUhuU/0zDRUrJ9gNGjmYL4mMk7Zu6i3n49hxVOJSpoLoj05Pe12Swfpudrh1ovXEru31/r/ZzuiXRuE71UsaqJMUq6dshPHfgsWzB9wGu8gv6OcJS7tQGKqn+NHflNyRxFkrdT7Us6iZK6iYG1q16GVyAFvVrXqdPUQQdmqlA9ZE73Hfaoxvh6VRyPCVu4VcRaNXd6qxPFpMISqUZbTzPp+LKB8/oun1TN+2bln5MRT+DGml0dbQxc4WZgycUJv0WG5SV68rTK8elqKOjo/NvRze6/yLuKWED8iFd7fTtWDm9fx0dHZ1/OzUikEqnYmjTKHqbAejo6OjolE+xkW7VryrUqSguTrOzZY+B+BhJWicX1w/PDznwSkdHR0cndNRS8n37ja7BpDgAdh+o2rR1OhXHmzdV3h6uOjo6Ov9mduzz2FJXHkHJmv3u5bjk/GyAv3aUnQpQR0dHR0dHp3S2ZjjIt0nqJRvk5n2cCPzNb3RvHU9+51Zmx8k8lcfePVr5Uuro6Ojo6NQC7n7tCAB9T7XsLvpbUCDV2f3j/gfw+peZ/Oej45UinI6Ojo6OTm0gK8fNdeMP8vsqT4a+Ib1ibit6TLEV21cOt67+em5uL4BWTUxcPNTKoB6xWGP1QGcdHR0dHZ2iHM1yM//PfGYsyOF4tiexxl2XJ73/7jfZt4dUwLjLE9+ul2xQ8QQz6x/9o3/0j/7RP/onhE/b5ibHQ2Pr3EQplJqb7IYLabJtb8xz+w+7B6n6el4dHR0dHZ1SMRmwt2lmmj5nef7TVS2Ljo6Ojo6Ojo6Ojo6Ojk7l8X/VmVTDhEJYDAAAAABJRU5ErkJggg==" alt="Skip School" class="nl-logo-img">
                        </div>

                        <p class="nl-greeting">Hey friend 👋<br>This week I let <strong>Claude build my 7-year-old's entire spelling curriculum.</strong> Here's what happened.</p>

                        <div class="nl-article">
                            <div class="nl-article-label">This Week's Deep Dive</div>
                            <div class="nl-article-title">I Replaced Our $200 Spelling Program with One AI Prompt</div>
                            <div class="nl-article-desc">The exact prompt I used, what Claude gave me, and the one thing I had to fix before my kid could use it.</div>
                        </div>

                        <div class="nl-prompt-box">
                            <div class="nl-prompt-label">✨ Prompt of the Week</div>
                            <div class="nl-prompt-text">"Create a 20-word spelling list for a 2nd grader based on the Magic Tree House books we're reading..."</div>
                        </div>

                        <div class="nl-quick-hits">
                            <div class="nl-quick-hit">
                                <div class="nl-qh-emoji">🔧</div>
                                <div class="nl-qh-text">3 New AI Tools</div>
                            </div>
                            <div class="nl-quick-hit">
                                <div class="nl-qh-emoji">💰</div>
                                <div class="nl-qh-text">ESA Update</div>
                            </div>
                            <div class="nl-quick-hit">
                                <div class="nl-qh-emoji">📚</div>
                                <div class="nl-qh-text">Free Resources</div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

</body>

<script>
(function() {
    const form = document.querySelector('.form-row');
    const emailInput = document.querySelector('.email-input');
    const submitBtn = document.querySelector('.cta-btn');
    const originalBtnText = submitBtn.textContent;

    // Get UTM params from URL if present (from Meta ads)
    const urlParams = new URLSearchParams(window.location.search);
    const utmSource = urlParams.get('utm_source') || 'skipschool.ai';
    const utmMedium = urlParams.get('utm_medium') || 'website';
    const utmCampaign = urlParams.get('utm_campaign') || 'subscribe_page';

    submitBtn.addEventListener('click', async function(e) {
        e.preventDefault();

        const email = emailInput.value.trim();

        // Basic validation
        if (!email || !email.includes('@') || !email.includes('.')) {
            emailInput.style.borderColor = '#e53e3e';
            emailInput.focus();
            return;
        }

        // Loading state
        submitBtn.disabled = true;
        submitBtn.textContent = 'Subscribing...';
        submitBtn.style.opacity = '0.7';
        emailInput.style.borderColor = '#e2e8f0';

        try {
            const response = await fetch('/api/subscribe', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    email: email,
                    utm_source: utmSource,
                    utm_medium: utmMedium,
                    utm_campaign: utmCampaign,
                }),
            });

            const data = await response.json();

            if (data.success && data.redirect) {
                // Redirect to survey
                window.location.href = data.redirect;
            } else {
                // Show error but stay on page
                submitBtn.textContent = 'Try Again';
                submitBtn.style.opacity = '1';
                submitBtn.disabled = false;
                setTimeout(() => { submitBtn.textContent = originalBtnText; }, 3000);
            }
        } catch (err) {
            submitBtn.textContent = 'Try Again';
            submitBtn.style.opacity = '1';
            submitBtn.disabled = false;
            setTimeout(() => { submitBtn.textContent = originalBtnText; }, 3000);
        }
    });

    // Allow Enter key to submit
    emailInput.addEventListener('keydown', function(e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            submitBtn.click();
        }
    });

    // Reset border on focus
    emailInput.addEventListener('focus', function() {
        this.style.borderColor = '#fbc926';
    });
})();
</script>
</html>
`;
  
  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  res.write(html);
  res.end();
  
  return { props: {} };
}
