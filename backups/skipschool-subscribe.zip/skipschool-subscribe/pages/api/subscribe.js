export default async function handler(req, res) {
  if (req.method === 'OPTIONS') {
    res.status(200).end();
    return;
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { email, utm_source, utm_medium, utm_campaign } = req.body;

  if (!email || !email.includes('@') || !email.includes('.')) {
    return res.status(400).json({ error: 'Valid email is required' });
  }

  const apiKey = process.env.BEEHIIV_API_KEY;
  const publicationId = process.env.BEEHIIV_PUBLICATION_ID;
  const surveyRedirectUrl = process.env.SURVEY_REDIRECT_URL || 'https://skipschool.ai';

  if (!apiKey || !publicationId) {
    console.error('Missing BEEHIIV_API_KEY or BEEHIIV_PUBLICATION_ID env vars');
    return res.status(500).json({ error: 'Server configuration error' });
  }

  try {
    const response = await fetch(
      `https://api.beehiiv.com/v2/publications/${publicationId}/subscriptions`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          email: email,
          reactivate_existing: true,
          send_welcome_email: true,
          utm_source: utm_source || 'skipschool.ai',
          utm_medium: utm_medium || 'website',
          utm_campaign: utm_campaign || 'subscribe_page',
          referring_site: 'https://skipschool.ai/subscribe',
        }),
      }
    );

    const data = await response.json();

    if (response.ok) {
      return res.status(200).json({
        success: true,
        redirect: surveyRedirectUrl,
      });
    } else {
      console.error('Beehiiv API error:', JSON.stringify(data));
      return res.status(response.status).json({
        error: 'Subscription failed. Please try again.',
      });
    }
  } catch (error) {
    console.error('Subscription error:', error);
    return res.status(500).json({ error: 'Something went wrong. Please try again.' });
  }
}
